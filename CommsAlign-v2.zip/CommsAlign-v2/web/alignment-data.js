/** Pure state helpers. Authored scenario data comes from one canonical JSON fixture. */
export const STAGES = Object.freeze(['expectations', 'investigate', 'coach', 'evaluate']);
export const PERSPECTIVES = Object.freeze(['manager', 'team', 'stakeholder']);
export const DETAILS = Object.freeze(['deliverable', 'deadline', 'purpose', 'checkin']);
export const DETAIL_LABELS = Object.freeze({deliverable: 'Deliverable', deadline: 'Deadline', purpose: 'Purpose', checkin: 'Check-in'});
export let SCENARIO = null;

function deepFreeze(value) {
  if (value && typeof value === 'object') {
    Object.values(value).forEach(deepFreeze);
    Object.freeze(value);
  }
  return value;
}
export function configureScenario(value) {
  if (!value || typeof value !== 'object' || typeof value.originalMessage !== 'string' || typeof value.completedBrief !== 'string') throw new TypeError('A complete authored scenario is required.');
  for (const role of PERSPECTIVES) {
    if (!value.perspectives?.[role] || typeof value.perspectives[role].label !== 'string') throw new TypeError('The scenario needs three labeled perspectives.');
    for (const field of DETAILS) if (typeof value.perspectives[role][field] !== 'string') throw new TypeError('Every perspective needs all four authored assumptions.');
  }
  for (const field of DETAILS) if (typeof value.confirmed?.[field] !== 'string') throw new TypeError('Every confirmed scenario fact is required.');
  if (!value.diagnostic || !Array.isArray(value.evaluation)) throw new TypeError('The scenario needs its authored investigation and proposed evaluation.');
  SCENARIO = deepFreeze(JSON.parse(JSON.stringify(value)));
  return SCENARIO;
}
export function initialState() {
  return {stage: 'expectations', perspective: 'manager', confirmedDetails: [], discussionFindingOpen: false};
}
export function normalizeState(value) {
  if (!value || typeof value !== 'object' || !STAGES.includes(value.stage) || !PERSPECTIVES.includes(value.perspective) || !Array.isArray(value.confirmedDetails) || value.confirmedDetails.some(field => !DETAILS.includes(field)) || typeof value.discussionFindingOpen !== 'boolean') return initialState();
  return {stage:value.stage, perspective:value.perspective, confirmedDetails:DETAILS.filter(field => value.confirmedDetails.includes(field)), discussionFindingOpen:value.discussionFindingOpen};
}
function scenarioOrThrow(scenario) {
  if (!scenario) throw new TypeError('Configure the authored scenario before deriving its text.');
  return scenario;
}
export function interpretation(value, perspective = value?.perspective, scenario = SCENARIO) {
  const state = normalizeState(value);
  const data = scenarioOrThrow(scenario);
  const role = PERSPECTIVES.includes(perspective) ? perspective : state.perspective;
  return DETAILS.map(detail => ({detail, label:DETAIL_LABELS[detail], value:state.confirmedDetails.includes(detail) ? data.confirmed[detail] : data.perspectives[role][detail], confirmed:state.confirmedDetails.includes(detail), basis:state.confirmedDetails.includes(detail) ? 'Confirmed in this example' : 'Assumed'}));
}
export function deriveBrief(value, scenario = SCENARIO) {
  const state = normalizeState(value);
  const data = scenarioOrThrow(scenario);
  const has = detail => state.confirmedDetails.includes(detail);
  const deliverable = has('deliverable') ? `the ${data.confirmed.deliverable}` : '[deliverable to confirm]';
  const purpose = has('purpose') ? data.confirmed.purpose : '[purpose to confirm]';
  const deadline = has('deadline') ? data.confirmed.deadline : '[deadline to confirm]';
  const checkin = has('checkin') ? data.confirmed.checkin : '[check-in to confirm].';
  return `Please prepare ${deliverable} for ${purpose} by ${deadline}. ${checkin}`;
}
export function transition(value, action) {
  const state = normalizeState(value);
  if (!action || typeof action !== 'object') return state;
  switch (action.type) {
    case 'reset': return initialState();
    case 'stage': return STAGES.includes(action.value) ? {...state, stage:action.value} : state;
    case 'perspective': return PERSPECTIVES.includes(action.value) ? {...state, perspective:action.value} : state;
    case 'finding': return {...state, discussionFindingOpen:typeof action.open === 'boolean' ? action.open : !state.discussionFindingOpen};
    case 'confirm': {
      if (!DETAILS.includes(action.detail) || typeof action.confirmed !== 'boolean') return state;
      const selected = new Set(state.confirmedDetails);
      action.confirmed ? selected.add(action.detail) : selected.delete(action.detail);
      return {...state, confirmedDetails:DETAILS.filter(detail => selected.has(detail))};
    }
    default: return state;
  }
}
