import { validatePilot } from './pilot-form.js';

const menu = document.getElementById('marketing-nav');
const toggle = document.getElementById('marketing-menu-toggle');
if (menu && toggle) {
  document.body.dataset.navReady = 'true';
  const setMenu = open => {
    menu.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  };
  toggle.addEventListener('click', () => setMenu(toggle.getAttribute('aria-expanded') !== 'true'));
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && toggle.getAttribute('aria-expanded') === 'true') {
      setMenu(false);
      toggle.focus();
    }
  });
}

const form = document.getElementById('pilot-form');
if (form) {
  const summary = document.getElementById('pilot-errors');
  const result = document.getElementById('pilot-result');
  const submit = form.querySelector('[data-pilot-submit]');
  const labels = {name:'Name',email:'Work email',organization:'Organization',role:'Role',team_size:'Team size',challenge:'Communication challenge'};
  if (submit && summary && result) {
    submit.disabled = false;
    form.noValidate = true;
    const clearErrors = () => {
      summary.hidden = true;
      summary.replaceChildren();
      for (const name of Object.keys(labels)) {
        const field = form.elements.namedItem(name);
        field?.removeAttribute('aria-invalid');
        const error = document.getElementById(`pilot-error-${name}`);
        if (error) { error.textContent = ''; error.hidden = true; }
      }
    };
    form.addEventListener('input', () => { result.hidden = true; });
    form.addEventListener('change', () => { result.hidden = true; });
    form.addEventListener('submit', event => {
      event.preventDefault();
      clearErrors();
      result.hidden = true;
      const { errors, valid } = validatePilot(Object.fromEntries(new FormData(form).entries()));
      if (!valid) {
        const heading = document.createElement('p');
        heading.textContent = 'Check the following fields before previewing your request:';
        const list = document.createElement('ul');
        for (const [name, message] of Object.entries(errors)) {
          const field = form.elements.namedItem(name);
          field?.setAttribute('aria-invalid', 'true');
          const error = document.getElementById(`pilot-error-${name}`);
          if (error) { error.textContent = message; error.hidden = false; }
          const item = document.createElement('li');
          const link = document.createElement('a');
          link.href = `#pilot-${name}`;
          link.textContent = `${labels[name]}: ${message}`;
          link.addEventListener('click', click => { click.preventDefault(); field?.focus(); });
          item.append(link); list.append(item);
        }
        summary.append(heading, list);
        summary.hidden = false;
        summary.focus();
        return;
      }
      // An unconfigured form must never imitate a delivered lead or contact an API.
      result.textContent = 'Preview only. Nothing was sent or saved.';
      result.hidden = false;
      result.focus();
    });
  }
}
