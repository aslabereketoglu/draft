import { escapeHtml as e, icon, request, api, download, notify, sourceLink } from './helpers.js';
import { coachView, mountCoach, getCoachSessionSummary } from './coach.js';

const view = document.getElementById('route-view');
const state = {teams:[], team:null, period:null, threshold:5, report:null, tab:'overview', selectedSignal:null, savedNotes:new Map(), draftNotes:new Map()};
let renderVersion = 0;
const teamName = value => String(value || '').replace(/^SYNTHETIC_/, '');
const titleCase = value => String(value || '').replace(/_/g, ' ').replace(/\b\w/g, c=>c.toUpperCase());
const statusLabel = value => ['needs_review','provisional_needs_evidence_review'].includes(value) ? 'Further validation needed' : titleCase(value);
const number = value => Number.isFinite(value) ? value.toFixed(2) : 'Unavailable';
const profile = scores => Object.entries(scores || {}).map(([name,score]) => `<div class="profile-row"><div class="profile-label"><span>${e(name)}</span><strong>${number(score)}</strong></div>${Number.isFinite(score) ? `<div class="profile-track" role="meter" aria-label="${e(name)}" aria-valuemin="1" aria-valuemax="5" aria-valuenow="${score}"><span class="profile-fill" style="width:${Math.max(0,Math.min(100,(score-1)*25))}%"></span></div>` : ''}</div>`).join('');
const errorView = message => `<div class="page-heading"><div><h1>Let’s reconnect.</h1><p>Your workspace couldn’t load this time.</p></div></div><div class="notice notice-error" role="alert">${icon('info')}<span>${e(message)}</span></div><button class="button button-secondary" id="retry-load">${icon('refresh')}Try again</button>`;
const noteKey = (report,item) => JSON.stringify([report.team_id,report.period,item]);
const options = (items,value) => items.map(item=>`<option ${item===value?'selected':''} value="${e(item)}">${e(item)}</option>`).join('');
const outcomes = ['Not assessed','Supports the hypothesis','Mixed or unclear','Suggests another explanation'];
const decisions = ['Investigate further','Agree on an action','No action for now'];

function closeMenu() {
  document.getElementById('sidebar').classList.remove('is-open');
  document.getElementById('sidebar-backdrop').classList.add('hidden');
  document.getElementById('menu-toggle').setAttribute('aria-expanded','false');
  document.body.classList.remove('menu-open');
}
function navigate(path) {
  if (location.pathname !== path) history.pushState({},'',path);
  closeMenu(); renderRoute(); window.scrollTo({top:0,behavior:'instant'});
}
document.addEventListener('click', event => {
  const link = event.target.closest('a[data-route]');
  if (!link || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || event.button!==0) return;
  event.preventDefault(); navigate(new URL(link.href).pathname);
});
document.getElementById('menu-toggle').addEventListener('click', () => {
  const open = document.getElementById('sidebar').classList.toggle('is-open');
  document.getElementById('sidebar-backdrop').classList.toggle('hidden',!open);
  document.getElementById('menu-toggle').setAttribute('aria-expanded',String(open));
  document.body.classList.toggle('menu-open',open);
  if (open) document.querySelector('.sidebar .nav-link').focus();
});
document.getElementById('sidebar-backdrop').addEventListener('click',closeMenu);
document.getElementById('sidebar-close').addEventListener('click',()=>{closeMenu();document.getElementById('menu-toggle').focus();});
document.addEventListener('keydown',event=>{
  if(event.key!=='Tab'||!document.body.classList.contains('menu-open'))return;
  const controls=[...document.getElementById('sidebar').querySelectorAll('a[href],button')].filter(x=>x.getClientRects().length);
  const first=controls[0],last=controls.at(-1);
  if(event.shiftKey && (document.activeElement===first || !document.getElementById('sidebar').contains(document.activeElement))){event.preventDefault();last.focus();}
  else if(!event.shiftKey && document.activeElement===last){event.preventDefault();first.focus();}
});
document.addEventListener('keydown', event => {if(event.key==='Escape' && document.body.classList.contains('menu-open')){closeMenu();document.getElementById('menu-toggle').focus();}});
window.addEventListener('popstate',()=>{closeMenu();renderRoute();});

function teamOptions() {
  return state.teams.map((team,index)=>`<option value="${index}" ${team.team_id===state.team && team.period===state.period?'selected':''}>${e(teamName(team.team_id))} team${state.teams.filter(x=>x.team_id===team.team_id).length>1?' · '+e(team.period):''}</option>`).join('');
}
async function loadData() {
  const requestedThreshold = state.threshold;
  if (!state.teams.length) {
    const listing = await request(`/api/teams?minimum_responses=${state.threshold}`);
    if (state.threshold !== requestedThreshold) return;
    state.teams = listing.teams;
    if (!state.teams.length) throw new Error('No demonstration teams are available. Check the bundled survey data.');
    const chosen = state.teams.find(t=>t.team_id===state.team && t.period===state.period) || state.teams[0];
    state.team=chosen.team_id; state.period=chosen.period;
    for (const blocked of state.teams.filter(t=>t.suppressed)) {
      for (const map of [state.savedNotes,state.draftNotes]) for (const key of map.keys()) {
        const [team,period] = JSON.parse(key); if(team===blocked.team_id && period===blocked.period) map.delete(key);
      }
    }
  }
  if (!state.report) {
    const requestedTeam = state.team, requestedPeriod = state.period;
    const params = new URLSearchParams({team_id:state.team,minimum_responses:String(state.threshold)});
    if (state.period) params.set('period',state.period);
    const report = await request('/api/diagnostic?'+params);
    if (state.threshold !== requestedThreshold || state.team !== requestedTeam || state.period !== requestedPeriod) return;
    state.report = report;
    if (!state.report.communication_signals?.some(s=>s.source_q12_item===state.selectedSignal)) state.selectedSignal=state.report.communication_signals?.[0]?.source_q12_item || null;
  }
}
async function selectTeam(index) {
  const team = state.teams[Number(index)]; if(!team)return;
  state.team=team.team_id;state.period=team.period;state.report=null;await renderRoute();
}
function overviewView() {
  const r=state.report, coach=getCoachSessionSummary();
  return `<div class="page-heading"><div><h1>Your communication workspace</h1><p>A little perspective for your next message. A clearer starting point for your team.</p></div></div>
  <div class="tool-grid">
    <section class="tool-panel tool-panel-primary"><h2>${icon('pencil')}Message Coach</h2><p class="tool-body">Get a second perspective on a draft, with rubric-based feedback and a revision you can make your own.</p><div class="tool-meta">Task instructions <span aria-hidden="true">·</span> Performance feedback</div><div class="tool-actions"><a data-route class="button button-primary" href="/workspace/message-coach">Review a message ${icon('arrow')}</a><span>GW Azure connection required</span></div></section>
    <section class="tool-panel"><h2>${icon('chart')}Team Diagnostic</h2><p class="tool-body">Explore survey patterns and turn a team signal into a thoughtful, structured conversation.</p><div class="tool-meta">Synthetic demonstration <span aria-hidden="true">·</span> Ready to explore</div><div class="tool-actions"><a data-route class="button button-secondary" href="/workspace/team-diagnostic">Explore team signals ${icon('arrow')}</a><span>No model connection needed</span></div></section>
  </div>
  <section class="snapshot panel"><div class="panel-header"><div><h2>Inside the demo</h2><p>Explore a real view of the bundled synthetic data.</p></div><div class="field"><label class="sr-only" for="overview-team">Demo team</label><select id="overview-team">${teamOptions()}</select></div></div>
  ${r.suppressed?`<div class="panel-body"><div class="notice notice-info">${icon('shield')}<span>This team does not meet your reporting threshold. Scores and signals are hidden.</span></div><a data-route class="button button-secondary" href="/workspace/team-diagnostic">Review reporting settings ${icon('arrow')}</a></div>`:
  `<div class="snapshot-grid panel-body"><div><div class="profile-heading"><h3>Hierarchy profile</h3><span>Mean score · 1–5</span></div>${profile(r.hierarchy_scores)}<p class="field-help">Bars run from 1 to 5. Fictional team scores, not benchmarks.</p></div><div class="discussion-prompt"><h3>${e(titleCase(r.communication_signals?.[0]?.signal_name || r.hierarchy_opportunities?.[0] || 'Team patterns'))}</h3><p>${e(r.communication_signals?.[0]?.manager_questions?.[0] || 'What do these relative patterns tell you about the team’s experience?')}</p><p class="field-help">Treat this as a question to explore, rather than a conclusion.</p><a data-route class="button button-ghost" href="/workspace/team-diagnostic">Open ${e(teamName(r.team_id))}’s report ${icon('arrow')}</a></div></div>`}</section>
  <div class="context-grid"><section><h2>Your session</h2>${coach.hasReview?`<div class="session-empty"><strong>Your ${e(titleCase(coach.kind))} review is ready.</strong><p>Return to the draft and feedback from this session.</p><a data-route href="/workspace/message-coach">Revisit your review ${icon('arrow')}</a></div>`:state.savedNotes.size?`<div class="session-empty"><strong>You have saved discussion notes.</strong><p>Your notes are available in this session.</p><a data-route href="/workspace/team-diagnostic">Return to team discussions ${icon('arrow')}</a></div>`:`<div class="session-empty">${icon('file')}<div><strong>A fresh place to start.</strong><p>No reviews or discussion notes yet. Choose a tool above to begin.</p></div></div>`}</section><section><h2>Built for reflection</h2><p>Ratings and survey interpretations are provisional. Team signals help guide a conversation; they don’t establish causes.</p><p class="field-help">Fictional teams. Nothing is automatically sent to employees or between tools.</p></section></div>`;
}
function filtersView() {
  return `<form id="report-filters" class="report-filters"><div class="field"><label for="diagnostic-team">Demo team</label><select id="diagnostic-team">${teamOptions()}</select></div><div class="field"><label for="minimum-responses">Minimum responses per item</label><div class="input-action"><input id="minimum-responses" type="number" min="1" max="10000" step="1" value="${state.threshold}" required><button class="button button-secondary" type="submit">Apply</button></div></div><p class="field-help">If any supplied item is below this threshold, the entire team/period report is hidden. This does not guarantee anonymity.</p></form>`;
}
function stat(label,value,note) {return `<div class="summary-stat"><span class="stat-label">${e(label)}</span><strong class="stat-value">${e(value)}</strong><span class="stat-note">${e(note)}</span></div>`;}
function signalCard(record,stronger) {
  const r=state.report;
  return `<article class="signal-card"><div class="signal-card-label"><span class="tag ${stronger?'tag-positive':'tag-warning'}">${stronger?'Stronger signal':'Area to explore'}</span><span>${e(record.item_id)}</span></div><h3>${e(r.item_labels[record.item_id] || record.item_id)}</h3><div class="signal-score">${number(record.mean_score)}<span> / 5</span></div><p class="field-help">${record.respondent_count} responses</p><p>${stronger?'A relatively stronger signal concerning':'A relatively lower-scoring signal concerning'} ${e(r.item_topics[record.item_id] || r.item_labels[record.item_id])} within this team and period.</p></article>`;
}
function diagnosticOverview(r) {
  return `<section class="panel"><div class="panel-header"><div><h2>${e(teamName(r.team_id))} at a glance</h2><p>Synthetic demonstration · ${e((r.period || 'Period not supplied').replace(/^SYNTHETIC_/, '').replace(/_/g,' ').toLowerCase())}</p></div><span class="tag">Team-level signals</span></div><div class="summary-grid">${stat('Mean score',number(r.grand_mean)+' / 5','Average of available items')}${stat('Strongest area',(r.hierarchy_strengths || []).join(', '),'Relative within this team')}${stat('Area to explore',(r.hierarchy_opportunities || []).join(', '),'A starting point for discussion')}${stat('Selected team',teamName(r.team_id),'Fictional demonstration team')}</div><div class="panel-body"><p>${e(r.executive_narrative)}</p><p class="field-help">All tied hierarchy areas are listed. These patterns do not explain their causes.</p></div></section>
  <section class="section"><div class="section-heading"><h2>Hierarchy profile</h2><p>Available item means on the full 1–5 scale.</p></div><div class="hierarchy-grid">${Object.entries(r.hierarchy_scores || {}).map(([area,score])=>`<article class="hierarchy-card"><h3>${e(area)}</h3><div class="signal-score">${number(score)}<span> / 5</span></div>${profile({[area]:score})}<div class="scale"><span>1</span><span>Mean score</span><span>5</span></div><span class="tag">${r.hierarchy_opportunities.includes(area)?'Area to explore':r.hierarchy_strengths.includes(area)?'Stronger area':'Hierarchy area'}</span></article>`).join('')}</div><p class="field-help">Missing areas are unavailable and are not imputed. Synthetic demonstration data.</p></section>
  ${r.tie_notice?`<details class="method-note"><summary>How ties are shown</summary><p>${e(r.tie_notice)}</p></details>`:''}
  <section class="section"><div class="section-heading"><h2>Stronger signals</h2><p>Relative strengths to build a conversation around.</p></div><div class="signal-grid">${(r.strengths||[]).map(x=>signalCard(x,true)).join('')}</div></section>
  <section class="section"><div class="section-heading"><h2>Areas to explore</h2><p>Lower-scoring items to understand with your team.</p></div><div class="signal-grid">${(r.opportunities||[]).map(x=>signalCard(x,false)).join('')}</div></section>`;
}
function evidenceFor(item) {return (state.report.evidence||[]).find(x=>x.source_item===item);}
function signalsView(r) {
  return `<section class="section"><div class="section-heading"><h2>Signals worth a conversation</h2><p>Provisional associations, with the evidence and limits kept in view.</p></div>${(r.communication_signals||[]).map(signal=>{
    const validation=evidenceFor(signal.source_q12_item);
    return `<details class="signal-detail"><summary><span><strong>${e(titleCase(signal.signal_name))}</strong><span class="field-help">${e(signal.source_q12_item)} · ${number(signal.observed_score)} / 5</span></span><span class="tag">${e(signal.relationship_type)} conceptual link</span></summary><div class="detail-body"><p>${e(signal.interpretation)}</p><p class="notice notice-warning">${e(signal.caution)}</p><h3>Questions to ask</h3><ul>${signal.manager_questions.map(q=>`<li>${e(q)}</li>`).join('')}</ul>${validation?`<h3>Evidence context</h3><p>${e(validation.allowed_language)}</p><p class="field-help">${e(statusLabel(validation.validation_status))} · ${e(validation.review_notes)}</p>${sourceLink(validation.external_source_reference)}`:''}<p class="field-help">Evidence: ${e(statusLabel(signal.evidence_status))}. No numerical confidence is estimated.</p></div></details>`;
  }).join('') || '<div class="empty-state"><h3>No mapped signals selected</h3><p>There are no mapped items in the lower-scoring selection for this team.</p></div>'}</section>
  <section class="section"><h2>Conversation priorities</h2><ol class="priority-list">${(r.priorities||[]).map(p=>`<li>${e(p)}</li>`).join('')}</ol><p class="field-help">Discussion topics, not prescriptions. Validate hypotheses with employees before taking action.</p></section>
  ${notesView(r)}`;
}
function notesView(r) {
  if (!r.communication_signals?.length) return '';
  const signal=r.communication_signals.find(x=>x.source_q12_item===state.selectedSignal) || r.communication_signals[0];
  state.selectedSignal=signal.source_q12_item;
  const key=noteKey(r,signal.source_q12_item), saved=state.savedNotes.get(key), notes=state.draftNotes.get(key)||saved||{};
  return `<section class="panel notes-workspace"><div class="panel-header"><div><h2>Plan the next conversation</h2><p>Save a non-identifying summary of what you learn.</p></div><span class="tag">Session only</span></div><div class="panel-body"><div class="field"><label for="discussion-signal">Signal to discuss</label><select id="discussion-signal">${r.communication_signals.map(s=>`<option value="${e(s.source_q12_item)}" ${s.source_q12_item===state.selectedSignal?'selected':''}>${e(s.source_q12_item)} — ${e(titleCase(s.signal_name))}</option>`).join('')}</select></div><div class="discussion-prompt"><h3>Discussion guide</h3><p>${e(evidenceFor(signal.source_q12_item)?.allowed_language || signal.interpretation)}</p><ul>${signal.manager_questions.map(q=>`<li>${e(q)}</li>`).join('')}</ul></div>
  <form id="discussion-form"><div class="field"><label for="notes-observations">Employee observations</label><textarea id="notes-observations" name="observations" rows="3" maxlength="5000" placeholder="A non-identifying summary of what the team shared…">${e(notes.observations)}</textarea></div><div class="notes-grid"><div class="field"><label for="notes-outcome">How do observations relate to the hypothesis?</label><select id="notes-outcome" name="outcome">${options(outcomes,notes.outcome||outcomes[0])}</select></div><div class="field"><label for="notes-decision">Next-step decision</label><select id="notes-decision" name="decision">${options(decisions,notes.decision||decisions[0])}</select></div></div><div class="field"><label for="notes-reflection">Manager reflection and alternative explanations</label><textarea id="notes-reflection" name="reflection" rows="3" maxlength="5000">${e(notes.reflection)}</textarea></div><div class="field"><label for="notes-action">Agreed next step, or reason for no action</label><textarea id="notes-action" name="action" rows="3" maxlength="5000">${e(notes.action)}</textarea></div><div class="notes-grid"><div class="field"><label for="notes-owner">Responsible role</label><input id="notes-owner" name="owner" maxlength="5000" value="${e(notes.owner)}" placeholder="Use a role rather than a name"></div><div class="field"><label for="notes-follow-up">Follow-up date or timing</label><input id="notes-follow-up" name="follow_up" maxlength="5000" value="${e(notes.follow_up)}" placeholder="For example, the next team meeting"></div></div><div class="form-actions"><button class="button button-primary" type="submit">${icon('check')}Save notes in this session</button><button class="button button-ghost" id="clear-notes" type="button">Clear notes for this signal</button></div></form><div class="notes-export"><button class="button button-secondary" id="download-discussion">${icon('download')}Download discussion summary</button><p class="field-help">${saved?'Includes the last saved notes. Unsaved edits are excluded.':'Includes the guide only until you save notes.'} Notes are held in memory and are lost on reload. Download a copy to keep it.</p></div></div></section>`;
}
function evidenceView(r) {
  const records=r.evidence||[];
  return `<section class="panel"><div class="panel-header"><div><h2>Understand the evidence</h2><p>Initial reviews inform the discussion framing. They do not validate a diagnosis.</p></div><span class="tag">Provisional mappings</span></div><div class="panel-body"><p>Survey results are signals and hypotheses only. They do not establish causes. A direct conceptual link describes an interpretation of an item; it does not mean the mapping is directly validated by research.</p><div class="evidence-list">${records.map(v=>`<details><summary><strong>${e(v.dimension_name)}</strong><span class="tag">${e(statusLabel(v.validation_status))}</span></summary><div class="detail-body"><p>${e(v.external_research_support)}</p><p><strong>Suggested framing</strong><br>${e(v.allowed_language)}</p><p class="field-help">Support: ${e(statusLabel(v.external_support_level))} · Review: ${e(statusLabel(v.review_scope))} · Full-text check: ${e(statusLabel(v.full_text_status))}</p><p class="field-help">${e(v.review_notes)}</p><div class="source-links">${sourceLink(v.external_source_reference)} ${sourceLink(v.source_reference,'Item context')}</div></div></details>`).join('')}</div></div></section>
  <section class="section"><h2>Methodology & limitations</h2>${r.missing_items?.length?`<p><strong>Missing items:</strong> ${e(r.missing_items.join(', '))}</p>`:''}<p>Aggregate survey inputs → validation → hierarchy analysis → relative patterns → provisional communication mapping → discussion prompts.</p><ul>${(r.limitations||[]).map(x=>`<li>${e(x)}</li>`).join('')}<li>Missing items are not imputed. Available-item summaries may not be comparable to complete summaries.</li><li>Item means are weighted equally; varying counts do not establish a unique respondent total.</li><li>No causal inference, benchmark percentile inference, LLM, or RAG is used for Team Diagnostic.</li></ul><details><summary>Data-quality rules</summary><p>Aggregate inputs only. Scores must be finite and between 1 and 5; counts must be positive integers. Duplicate team/item/period rows, malformed files, and invalid values reject the entire input.</p></details><p class="field-help">Fictional teams and invented scores. Not real Gallup results. CommsAlign is not affiliated with or endorsed by Gallup.</p></section>`;
}
function diagnosticView() {
  const r=state.report;
  return `<div class="page-heading"><div><h1>Team Diagnostic</h1><p>Turn survey patterns into a more focused team conversation.</p></div>${!r.suppressed?`<button id="download-diagnostic" class="button button-secondary">${icon('download')}Download summary</button>`:''}</div>${filtersView()}
  <div class="notice notice-info">${icon('info')}<span>Synthetic demonstration data. Survey results are signals, not causes. Interpretations remain provisional.</span></div>${(r.data_quality_notes||[]).map(note=>`<div class="notice notice-warning">${e(note)}</div>`).join('')}
  ${r.suppressed?`<section class="empty-state panel">${icon('shield')}<h2>This team’s report is hidden.</h2><p>The selected reporting threshold is not met. Scores, rankings, discussion prompts, and downloads are unavailable.</p><ul>${(r.limitations||[]).map(x=>`<li>${e(x)}</li>`).join('')}</ul><p class="field-help">Review the minimum-response rule above. Previously saved notes for this team/period have been cleared.</p></section>`:
  `<div class="tabs" role="tablist" aria-label="Diagnostic sections">${[['overview','Team overview'],['signals','Signals & discussion'],['evidence','Evidence & method']].map(([id,label])=>`<button class="tab ${state.tab===id?'active':''}" id="tab-${id}" role="tab" aria-selected="${state.tab===id}" tabindex="${state.tab===id?'0':'-1'}" aria-controls="diagnostic-panel" data-tab="${id}">${label}</button>`).join('')}</div><div class="tab-panel" id="diagnostic-panel" role="tabpanel" aria-labelledby="tab-${state.tab}">${state.tab==='overview'?diagnosticOverview(r):state.tab==='signals'?signalsView(r):evidenceView(r)}</div>`}`;
}
function bindDataViews(route) {
  const select=document.getElementById(route==='/workspace'?'overview-team':'diagnostic-team');
  select?.addEventListener('change', event=>selectTeam(event.target.value));
  document.getElementById('report-filters')?.addEventListener('submit',event=>{
    event.preventDefault();const threshold=Number(document.getElementById('minimum-responses').value);
    if(!Number.isInteger(threshold)||threshold<1||threshold>10000)return;
    state.threshold=threshold;state.teams=[];state.report=null;renderRoute();
  });
  document.getElementById('download-diagnostic')?.addEventListener('click',()=>download('commsalign-diagnostic-summary.txt',state.report.download_text));
  const tabs=[...view.querySelectorAll('[data-tab]')];
  tabs.forEach(button=>button.addEventListener('click',()=>{state.tab=button.dataset.tab;renderCurrentTeam();document.getElementById('tab-'+state.tab).focus();}));
  tabs.forEach((button,index)=>button.addEventListener('keydown',event=>{
    let next;if(event.key==='ArrowRight')next=(index+1)%tabs.length;else if(event.key==='ArrowLeft')next=(index+tabs.length-1)%tabs.length;else if(event.key==='Home')next=0;else if(event.key==='End')next=tabs.length-1;else return;
    event.preventDefault();state.tab=tabs[next].dataset.tab;renderCurrentTeam();document.getElementById('tab-'+state.tab).focus();
  }));
  document.getElementById('discussion-signal')?.addEventListener('change',event=>{state.selectedSignal=event.target.value;renderCurrentTeam();document.getElementById('discussion-signal').focus();});
  const form=document.getElementById('discussion-form');
  if(form){
    const key=noteKey(state.report,state.selectedSignal), values=()=>Object.fromEntries(new FormData(form).entries());
    form.addEventListener('input',()=>state.draftNotes.set(key,values()));form.addEventListener('change',()=>state.draftNotes.set(key,values()));
    form.addEventListener('submit',event=>{event.preventDefault();state.savedNotes.set(key,values());state.draftNotes.set(key,values());notify('Notes saved in this session. Download a copy to keep them.');renderCurrentTeam();});
    document.getElementById('clear-notes').addEventListener('click',()=>{state.savedNotes.delete(key);state.draftNotes.delete(key);renderCurrentTeam();notify('Notes cleared for this signal.');});
    document.getElementById('download-discussion').addEventListener('click',async event=>{
      const button=event.currentTarget;button.disabled=true;
      try {const data=await request('/api/discussion/export',{method:'POST',body:JSON.stringify({team_id:state.team,period:state.period,minimum_responses:state.threshold,item:state.selectedSignal,notes:state.savedNotes.get(key)||{}})});download('commsalign-discussion-summary.txt',data.text);}
      catch(error){notify(error.message);}finally{button.disabled=false;}
    });
  }
}
function renderCurrentTeam(){view.innerHTML=diagnosticView();bindDataViews('/workspace/team-diagnostic');}
async function renderRoute() {
  const version=++renderVersion;
  const route=['/workspace','/workspace/message-coach','/workspace/team-diagnostic'].includes(location.pathname)?location.pathname:'/workspace';
  const label={'/workspace':'Overview','/workspace/message-coach':'Message Coach','/workspace/team-diagnostic':'Team Diagnostic'}[route];
  document.title=`CommsAlign — ${label}`;document.getElementById('breadcrumb').textContent=label;
  document.querySelectorAll('.nav-link').forEach(link=>{const active=link.getAttribute('href')===route;link.classList.toggle('active',active);if(active)link.setAttribute('aria-current','page');else link.removeAttribute('aria-current');});
  if(route==='/workspace/message-coach'){view.innerHTML=coachView();mountCoach(view,{api,escapeHtml:e,icon,download,notify});return;}
  if(!state.report) view.innerHTML='<div class="loading" role="status"><span class="spinner"></span>Loading the demonstration workspace…</div>';
  try {await loadData();if(version!==renderVersion)return;view.innerHTML=route==='/workspace'?overviewView():diagnosticView();bindDataViews(route);}
  catch(error){if(version!==renderVersion)return;view.innerHTML=errorView(error.message);document.getElementById('retry-load').addEventListener('click',()=>{state.teams=[];state.report=null;renderRoute();});}
}
renderRoute();
