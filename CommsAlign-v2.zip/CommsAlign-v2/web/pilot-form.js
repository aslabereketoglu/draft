/** Preview validation only. This module sends and stores no contact information. */
export const TEAM_SIZES = ['', '1–10', '11–50', '51–200', '201+', 'Unsure'];

export function validatePilot(input = {}) {
  const values = Object.fromEntries(['name', 'email', 'organization', 'role', 'team_size', 'challenge']
    .map(key => [key, typeof input[key] === 'string' ? input[key].trim() : '']));
  const errors = {};
  if (!values.name) errors.name = 'Enter your name.';
  else if (values.name.length > 100) errors.name = 'Use 100 characters or fewer for your name.';
  if (!values.email) errors.email = 'Enter an email address.';
  else if (values.email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.email = 'Enter a valid email address, using 254 characters or fewer.';
  }
  if (!values.organization) errors.organization = 'Enter your organization.';
  else if (values.organization.length > 150) errors.organization = 'Use 150 characters or fewer for your organization.';
  if (values.role.length > 100) errors.role = 'Use 100 characters or fewer for your role.';
  if (!TEAM_SIZES.includes(values.team_size)) errors.team_size = 'Choose a listed team size, or leave it blank.';
  if (values.challenge.length > 1500) errors.challenge = 'Describe the challenge in 1,500 characters or fewer.';
  return { values, errors, valid: Object.keys(errors).length === 0 };
}
