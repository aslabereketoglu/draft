export const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
export const icon = name => `<svg class="icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><use href="#icon-${escapeHtml(name)}"></use></svg>`;
export async function request(path, options = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), options.method === 'POST' ? 180000 : 20000);
  try {
    const response = await fetch(path, {credentials:'same-origin', ...options, headers:{'Content-Type':'application/json', ...options.headers}, signal:controller.signal});
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'The request could not be completed. Please try again.');
    return data;
  } catch (error) {
    if (error.name === 'AbortError') throw new Error('The request took too long. Check your connection and try again.');
    throw error;
  } finally { clearTimeout(timer); }
}
export const api = {
  review: body => request('/api/message/review', {method:'POST', body:JSON.stringify(body)}),
  rescore: body => request('/api/message/rescore', {method:'POST', body:JSON.stringify(body)}),
};
export function download(filename, text, mime = 'text/plain;charset=utf-8') {
  const url = URL.createObjectURL(new Blob([text], {type:mime}));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename;
  document.body.append(anchor); anchor.click(); anchor.remove(); setTimeout(() => URL.revokeObjectURL(url), 1000);
}
export function notify(message) {
  const toast = document.getElementById('toast'); toast.textContent = message; toast.classList.remove('hidden');
  clearTimeout(notify.timer); notify.timer = setTimeout(() => toast.classList.add('hidden'), 4000);
}
export function sourceLink(value, label = 'Research source') {
  try { const url = new URL(value); if (!['http:','https:'].includes(url.protocol)) return escapeHtml(value);
    return `<a href="${escapeHtml(url.href)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)} ${icon('external')}</a>`;
  } catch { return escapeHtml(value); }
}
