// Message Coach session state stays in memory and is never evaluated on render.
const state = {
  draft: '', kind: 'task_instruction', consent: false, saved: null,
  revision: '', rescore: null, busy: null, error: '',
};

const e = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
}[character]));
const list = value => Array.isArray(value) ? value : [];
const label = value => {
  const text = String(value ?? '').replace(/^[DF]\d+_/, '').replace(/_/g, ' ');
  return text ? text[0].toUpperCase() + text.slice(1) : 'Not supplied';
};

function notices(items) {
  return list(items).map(item => `<div class="notice notice-warning">${e(item)}</div>`).join('');
}

function scoreChart(result, title = 'Rubric scores') {
  if (!result || result.abstain) return '';
  const dimensions = Object.entries(result.dimensions || {});
  const scored = dimensions.filter(([, rating]) => rating.status === 'scored'
    && rating.score !== null && Number.isFinite(Number(rating.score)));
  const unscored = dimensions.filter(([, rating]) => rating.status !== 'scored' || rating.score === null);
  if (!scored.length && !unscored.length) return '';
  return `<section class="score-chart" aria-label="${e(title)}">
    <h3>${e(title)}</h3>
    ${scored.map(([name, rating]) => {
      const score = Math.max(1, Math.min(5, Number(rating.score)));
      return `<div class="score-row">
        <div class="profile-label"><span>${e(label(name))}</span><strong>${e(score)} <span class="field-help">/ 5</span></strong></div>
        <div class="profile-track" role="meter" aria-label="${e(label(name))}" aria-valuemin="1" aria-valuemax="5" aria-valuenow="${score}">
          <span class="profile-fill" style="width:${((score - 1) / 4) * 100}%"></span>
        </div>
      </div>`;
    }).join('')}
    <p class="field-help">Bars start at 1, the lowest rubric score, and end at 5. Higher scores indicate closer alignment with this rubric.</p>
    ${unscored.length ? `<p class="field-help">Not scored: ${e(unscored.map(([name]) => label(name)).join(', '))}. See the explanations below.</p>` : ''}
  </section>`;
}

function judgment(result, title) {
  if (!result) return '';
  return `<section aria-label="${e(title)}">
    <div class="panel-header"><h3>${e(title)}</h3>${!result.abstain ? `<span class="tag">${e(label(result.label))}</span>` : ''}</div>
    ${result.abstain ? `<div class="notice notice-warning">The reviewer abstained: ${e(result.abstain_reason || 'Outside the rubric’s scope.')}</div>` : ''}
    <p class="field-help">Model-reported confidence: ${e(result.confidence_level || 'Not supplied')}${result.confidence_note ? ` · ${e(result.confidence_note)}` : ''}</p>
    ${scoreChart(result)}
    ${Object.entries(result.dimensions || {}).map(([name, rating]) => `<details>
      <summary>${e(label(name))} <span class="field-help">${rating.status === 'scored' && rating.score !== null ? `${e(rating.score)} / 5` : e(label(rating.status))}</span></summary>
      <div class="panel-body">
        <p class="field-help">Status: ${e(label(rating.status))}</p>
        ${list(rating.evidence).map(quote => `<blockquote class="evidence-quote">${e(quote)}</blockquote>`).join('')}
        <p>${e(rating.note)}</p>
      </div>
    </details>`).join('')}
    ${notices(result.warnings)}
  </section>`;
}

function rewriteView() {
  const rewrite = state.saved?.rewrite;
  if (!rewrite) return '';
  const highlighted = e(rewrite.rewrite).replace(/(\[[^\[\]]*\?\])/g, '<mark class="gap">$1</mark>');
  const cards = new Map(list(rewrite.cards).map(card => [card.id, card]));
  return `<section class="result-panel panel" aria-labelledby="coach-rewrite-heading">
    <div class="panel-header"><div><h2 id="coach-rewrite-heading">Suggested revision</h2><p class="field-help">Highlighted gaps are details only you know. Check every suggestion before using it.</p></div></div>
    <div class="rewrite-body">${highlighted}</div>
    ${notices(rewrite.warnings)}
    ${state.saved.after && list(rewrite.changes).length ? judgment(state.saved.after, 'Suggested revision scores') : ''}
    ${list(rewrite.changes).length ? `<h3>Why these changes</h3>${list(rewrite.changes).map(change => `<details>
      <summary>${e(label(change.dimension))}: ${e(change.what)}</summary>
      <div class="panel-body"><p>${e(change.why)}</p>
      ${list(change.card_ids).length ? list(change.card_ids).map(id => {
        const card = cards.get(id);
        if (!card) return '';
        return `<blockquote class="evidence-quote"><strong>Evidence${card.setting ? ` · ${e(card.setting)}` : ''}</strong><p>${e(card.finding)}</p><p class="field-help">${e(card.source)}${card.locator ? ` · ${e(card.locator)}` : ''}</p><p class="field-help">Limits: ${e(card.limits)}</p></blockquote>`;
      }).join('') : '<p class="field-help">No research card applies to this change; it follows the rubric only.</p>'}
      </div></details>`).join('')}` : ''}
    <form id="coach-rescore-form" novalidate>
      <div class="field"><label class="field-label" for="coach-revision">Make it your own</label>
        <p class="field-help" id="coach-revision-help">Fill in the gaps and edit the suggestion. Re-scoring sends this version to the same configured GW Azure service.</p>
        <textarea id="coach-revision" name="revision" rows="7" maxlength="20000" aria-describedby="coach-revision-help" ${state.busy ? 'disabled' : ''}>${e(state.revision)}</textarea>
      </div>
      <div class="form-actions">
        <button class="button button-primary" type="submit" ${state.busy ? 'disabled' : ''}>${state.busy === 'rescore' ? '<span class="spinner" aria-hidden="true"></span> Re-scoring…' : 'Re-score my version'}</button>
        <button class="button button-secondary" type="button" id="coach-download-revision" ${state.busy || !state.revision.trim() ? 'disabled' : ''}>Download revision</button>
      </div>
      <p class="field-help">The evaluation consent above also applies to re-scoring. You can uncheck it at any time.</p>
    </form>
    ${state.rescore ? judgment(state.rescore, 'Your version’s scores') : ''}
  </section>`;
}

function resultsView() {
  if (!state.saved) return `<section class="empty-state" aria-labelledby="coach-empty-heading">
    <h2 id="coach-empty-heading">A second perspective starts here.</h2>
    <p>Your ratings, supporting evidence, and suggested revision will appear after you submit a draft.</p>
    <p class="field-help">A live GW Azure connection is required. Reviews are provisional model judgments, not validated measures of communication effectiveness.</p>
  </section>`;
  return `<section class="result-panel panel" aria-labelledby="coach-result-heading">
    <div class="panel-header"><div><h2 id="coach-result-heading">Your message review</h2><p class="field-help">${e(label(state.saved.kind))} · Last submitted draft</p></div>
      <button class="button button-secondary button-small" type="button" id="coach-download-review">Download review</button>
    </div>
    <details><summary>View the submitted draft</summary><pre class="evidence-quote">${e(state.saved.draft)}</pre></details>
    ${judgment(state.saved.result, 'Original draft')}
  </section>${rewriteView()}`;
}

export function coachView() {
  return `<div class="page-heading"><div><h1>Message Coach</h1><p>A thoughtful second look before you send.</p></div>
    <span class="tag">GW Azure connection required</span></div>
  <div class="editor-grid">
    <section class="editor-panel panel" aria-labelledby="coach-editor-heading">
      <div class="panel-header"><div><h2 id="coach-editor-heading">What would you like to say?</h2><p class="field-help">Review a task instruction or performance feedback draft.</p></div></div>
      <form id="coach-form" novalidate>
        <div class="field"><label class="field-label" for="coach-kind">Message type</label>
          <select id="coach-kind" name="kind" ${state.busy ? 'disabled' : ''}>
            <option value="task_instruction" ${state.kind === 'task_instruction' ? 'selected' : ''}>Task instruction</option>
            <option value="performance_feedback" ${state.kind === 'performance_feedback' ? 'selected' : ''}>Performance feedback</option>
          </select>
        </div>
        <div class="field"><label class="field-label" for="coach-draft">Your draft</label>
          <textarea id="coach-draft" name="draft" rows="10" maxlength="20000" aria-describedby="coach-draft-help coach-character-count" placeholder="Paste your draft here. Include the context, action, and timing your reader needs." ${state.busy ? 'disabled' : ''}>${e(state.draft)}</textarea>
          <div class="result-meta"><span class="field-help" id="coach-draft-help">Use a non-identifying draft. Avoid sensitive information.</span><span class="field-help" id="coach-character-count">${state.draft.length.toLocaleString()} / 20,000</span></div>
        </div>
        <label class="checkbox-row" for="coach-consent"><input type="checkbox" id="coach-consent" name="consent" ${state.consent ? 'checked' : ''} ${state.busy ? 'disabled' : ''}><span>I agree to send this draft to the configured GW Azure model for evaluation.</span></label>
        <p class="field-help">Nothing is automatically sent to employees. Drafts and results stay in this app session unless you download them.</p>
        <div id="coach-error" ${state.error ? '' : 'class="hidden"'} role="alert">${state.error ? `<div class="notice notice-error">${e(state.error)}</div>` : ''}</div>
        <div class="form-actions"><button class="button button-primary" type="submit" ${state.busy ? 'disabled' : ''}>${state.busy === 'review' ? '<span class="spinner" aria-hidden="true"></span> Reviewing your draft…' : 'Review my draft'}</button>
          <button class="button button-ghost" type="button" id="coach-clear" ${state.busy ? 'disabled' : ''}>Clear draft &amp; review</button></div>
        <div id="coach-status" class="field-help" role="status" aria-live="polite">${state.busy ? 'The model is reviewing your message. This may take a moment.' : ''}</div>
      </form>
    </section>
    <aside class="guide-panel" aria-labelledby="coach-guide-heading">
      <h2 id="coach-guide-heading">A useful draft has context.</h2>
      <div><h3>Task instructions</h3><p>Include what needs to happen, the expected outcome, and any timing or constraints.</p></div>
      <div><h3>Performance feedback</h3><p>Describe the observed behavior and its impact. Give your reader the context they need.</p></div>
      <div class="notice notice-info"><strong>You stay in the conversation.</strong><p>Review the evidence behind each rating. A suggestion is a starting point for your own judgment.</p></div>
      <p class="field-help">The reviewer and rewriter use a message-specific rubric. Missing facts are left as editable gaps rather than guessed.</p>
    </aside>
  </div>
  <details class="setup-panel"><summary>Connection setup &amp; review scope</summary><div class="panel-body">
    <p>Live reviews require your GW-provided Azure settings in the local <code>.env</code> file. Never commit that file or paste API keys into this interface.</p>
    <code>GW_AZURE_OPENAI_KEY · GW_ENDPOINT · GW_API_VERSION · GW_MODEL</code>
    <p>The model may abstain when a draft is outside the rubric’s scope. Scores and interpretations are provisional. A high score does not establish quality or safety.</p>
  </div></details>
  <div id="coach-results" aria-live="polite">${resultsView()}</div>`;
}

export function getCoachSessionSummary() {
  return { hasReview: Boolean(state.saved), kind: state.saved?.kind || state.kind };
}

export function clearCoachSession() {
  Object.assign(state, { draft: '', kind: 'task_instruction', consent: false, saved: null,
    revision: '', rescore: null, busy: null, error: '' });
}

export function mountCoach(container, helpers) {
  const form = container.querySelector('#coach-form');
  if (!form) return;
  const draft = container.querySelector('#coach-draft');
  const kind = container.querySelector('#coach-kind');
  const consent = container.querySelector('#coach-consent');
  const rerender = () => {
    if (!container.querySelector('#coach-form')) return;
    container.innerHTML = coachView();
    mountCoach(container, helpers);
  };
  const showError = (message, focusTarget) => {
    state.error = message;
    const region = container.querySelector('#coach-error');
    if (region) {
      region.classList.remove('hidden');
      region.innerHTML = `<div class="notice notice-error">${e(message)}</div>`;
    }
    focusTarget?.focus();
  };
  draft.addEventListener('input', () => {
    state.draft = draft.value;
    container.querySelector('#coach-character-count').textContent = `${state.draft.length.toLocaleString()} / 20,000`;
  });
  kind.addEventListener('change', () => { state.kind = kind.value; });
  consent.addEventListener('change', () => { state.consent = consent.checked; });
  container.querySelector('#coach-clear').addEventListener('click', () => {
    clearCoachSession();
    rerender();
    container.querySelector('#coach-draft')?.focus();
    helpers.notify?.('Draft and review cleared from this session.');
  });
  form.addEventListener('submit', async event => {
    event.preventDefault();
    if (state.busy) return;
    state.draft = draft.value;
    state.kind = kind.value;
    state.consent = consent.checked;
    if (!state.draft.trim()) return showError('Add a draft message before requesting a review.', draft);
    if (!state.consent) return showError('Confirm the model submission before reviewing your draft.', consent);
    Object.assign(state, { busy: 'review', error: '', saved: null, revision: '', rescore: null });
    rerender();
    try {
      state.saved = await helpers.api.review({ draft: state.draft, kind: state.kind, consent: true });
      state.revision = state.saved.rewrite?.rewrite || '';
      helpers.notify?.('Your message review is ready.');
    } catch (error) {
      state.error = error?.message || 'The review could not be completed. Check the GW connection and try again.';
    } finally {
      state.busy = null;
      rerender();
    }
  });
  container.querySelector('#coach-download-review')?.addEventListener('click', () => {
    if (state.saved) helpers.download('commsalign-message-review.json', JSON.stringify(state.saved, null, 2), 'application/json');
  });
  const revision = container.querySelector('#coach-revision');
  revision?.addEventListener('input', () => {
    state.revision = revision.value;
    const button = container.querySelector('#coach-download-revision');
    if (button) button.disabled = !state.revision.trim();
  });
  container.querySelector('#coach-download-revision')?.addEventListener('click', () => {
    if (state.revision.trim()) helpers.download('commsalign-revised-draft.txt', state.revision, 'text/plain;charset=utf-8');
  });
  container.querySelector('#coach-rescore-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    if (state.busy) return;
    state.revision = revision.value;
    if (!state.revision.trim()) return showError('Add your revised message before re-scoring.', revision);
    if (!state.consent) return showError('Confirm the model submission above before re-scoring your version.', consent);
    Object.assign(state, { busy: 'rescore', error: '', rescore: null });
    rerender();
    try {
      state.rescore = await helpers.api.rescore({ draft: state.revision, kind: state.saved.kind, consent: true });
      helpers.notify?.('Your revised message has been re-scored.');
    } catch (error) {
      state.error = error?.message || 'Re-scoring could not be completed. Check the GW connection and try again.';
    } finally {
      state.busy = null;
      rerender();
    }
  });
}
