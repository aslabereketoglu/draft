import { SCENARIO, STAGES, PERSPECTIVES, DETAILS, DETAIL_LABELS, configureScenario, initialState, normalizeState, interpretation, deriveBrief, transition } from './alignment-data.js';

const STORAGE_KEY = 'commsalign.alignment-explorer.v1';
const e = value => String(value ?? '').replace(/[&<>"']/g, character => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[character]));
const STAGE_LABELS = {expectations:'Expectations', investigate:'Investigate', coach:'Coach', evaluate:'Evaluate (proposed)'};
let state = initialState();
let liveRegion = null;
const instances = [];

function readState() {
  try { return normalizeState(JSON.parse(sessionStorage.getItem(STORAGE_KEY))); }
  catch { return initialState(); }
}
function persistState() {
  try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch { /* The local demonstration works when browser storage is unavailable. */ }
}
function originalMessage() {
  return `<div class="ex-original"><p class="ex-label">Original request · fictional Atlas team</p><blockquote class="ex-message">${e(SCENARIO.originalMessage)}</blockquote></div>`;
}
function rolesAndInterpretations(prefix) {
  return `<fieldset class="ex-role-group"><legend>Choose a perspective</legend><div>${PERSPECTIVES.map(role => `<button class="ex-role-button${state.perspective === role ? ' is-active' : ''}" type="button" data-ex-role="${role}" aria-pressed="${state.perspective === role}">${e(SCENARIO.perspectives[role].label)}</button>`).join('')}</div></fieldset>
  <section aria-labelledby="${prefix}-interpretation-title"><h3 id="${prefix}-interpretation-title" data-ex-interpretation-title>${e(SCENARIO.perspectives[state.perspective].label)}’s possible interpretation</h3><p class="ex-disclosure">Possible interpretation — fictional. These are authored assumptions, not detected beliefs.</p><dl class="ex-interpretation">${interpretation(state).map(row => `<div class="ex-detail${row.confirmed ? ' ex-confirmed' : ''}" data-ex-detail="${row.detail}"><dt class="ex-detail-label">${row.label}</dt><dd class="ex-detail-value"><span data-ex-value>${e(row.value)}</span><span class="ex-state" data-ex-basis>${row.basis}</span></dd></div>`).join('')}</dl></section>`;
}
function expectationsView(prefix, full) {
  return `<div class="ex-heading"><h3>One request. Different expectations.</h3><p>The same words can leave three plausible views of the work.</p></div>${originalMessage()}${rolesAndInterpretations(prefix)}<p class="ex-static-note">When this happens repeatedly, start by understanding the team's experience.</p>${full ? '<div class="ex-actions"><button class="ex-button ex-button-primary" type="button" data-ex-next="investigate">Investigate the team pattern</button></div>' : ''}`;
}
function diagnosticView(prefix) {
  const data = SCENARIO.diagnostic;
  return `<div class="ex-heading"><h3>Start with the team pattern.</h3><p>Fictional survey scenario · not actual Team Diagnostic output</p></div><div class="ex-diagnostic">
  <section class="ex-survey"><h4>Survey signal</h4><p>${e(SCENARIO.team)} · ${data.responses} fictional responses</p><blockquote class="ex-message">“${e(data.question)}”</blockquote><p class="ex-score"><strong>${data.average.toFixed(1)}</strong><span>out of 5 · authored response average</span></p><meter min="1" max="5" value="${data.average}" aria-label="Fictional response average: ${data.average} out of 5">${data.average} out of 5</meter><p class="ex-disclosure">Scale: 1–5. Authored demonstration data, not a product benchmark or customer result.</p></section>
  <div class="ex-actions"><button class="ex-button ex-button-secondary" type="button" data-ex-finding aria-expanded="${state.discussionFindingOpen}" aria-controls="${prefix}-finding">${state.discussionFindingOpen ? 'Hide the discussion finding' : 'Review the discussion finding'}</button></div>
  <div class="ex-finding" id="${prefix}-finding" data-ex-finding-content ${state.discussionFindingOpen ? '' : 'hidden'}><section class="ex-observation"><h4>Manager observation</h4><p>${e(data.observation)}</p></section><section class="ex-hypothesis"><h4>Working hypothesis</h4><p>${e(data.hypothesis)}</p></section><section class="ex-alternative"><h4>Alternative explanation</h4><p>${e(data.alternative)}</p></section></div>
  </div><p class="ex-disclosure">A low survey score does not establish the cause. In this fictional example, the manager discusses the pattern with the team before choosing a communication intervention.</p><div class="ex-actions"><button class="ex-button ex-button-primary" type="button" data-ex-next="coach">Explore message coaching</button><p class="ex-disclosure">Simulated manual handoff. Automatic cross-tool transfer is not implemented.</p></div>`;
}
function coachView(prefix, full) {
  return `<div class="ex-heading"><h3>Make the missing details explicit.</h3><p>Add only the facts the manager has confirmed in this fictional scenario.</p></div>${originalMessage()}
  <fieldset class="ex-controls"><legend>Confirm the scenario facts</legend>${DETAILS.map(detail => `<label class="ex-check" for="${prefix}-${detail}"><input id="${prefix}-${detail}" type="checkbox" data-ex-confirm="${detail}" ${state.confirmedDetails.includes(detail) ? 'checked' : ''}><span><strong>${DETAIL_LABELS[detail]}</strong><span>${e(SCENARIO.confirmed[detail])}</span></span></label>`).join('')}</fieldset>
  <section class="ex-brief" aria-labelledby="${prefix}-brief-heading"><h3 id="${prefix}-brief-heading">The shared written brief</h3><p class="ex-count" data-ex-count>${state.confirmedDetails.length} of 4 details confirmed</p><blockquote class="ex-message ex-shared-text" data-ex-brief tabindex="0">${e(deriveBrief(state))}</blockquote><p class="ex-disclosure">Unchecked details stay as missing-detail prompts. This is a checklist count, not an alignment or quality score.</p><p class="ex-completion" data-ex-completion ${state.confirmedDetails.length === 4 ? '' : 'hidden'}>The written brief now contains the same confirmed details across the perspectives. A conversation is still needed to check understanding.</p><div class="ex-actions"><button class="ex-button ex-button-secondary" type="button" data-ex-copy ${state.confirmedDetails.length === 4 ? '' : 'hidden'}>Copy example brief</button><p class="ex-copy-status" data-ex-copy-status role="status"></p></div></section>
  <p class="ex-disclosure">Deterministic demonstration using authored scenario facts. This example is not live AI feedback or an automatic rewrite.</p>${full ? '<div class="ex-actions"><button class="ex-button ex-button-primary" type="button" data-ex-next="evaluate">Consider the proposed evaluation</button></div>' : '<div class="ex-actions"><a class="ex-button ex-button-secondary" href="/demo">Explore the full example</a></div>'}`;
}
function evaluationView() {
  return `<div class="ex-heading"><h3>What would you want to learn next?</h3><p>Proposed evaluation approach. No measured results or automated tracking are shown.</p></div><section class="ex-evaluation"><ol>${SCENARIO.evaluation.map(point => `<li>${e(point)}</li>`).join('')}</ol><p>A simple before/after observation can inform a pilot, but cannot on its own establish that CommsAlign caused a change.</p></section><div class="ex-actions"><a class="ex-button ex-button-primary" href="/request-pilot">Discuss a team pilot</a></div>`;
}
function fullView(prefix) {
  return `<div class="ex-heading"><h2>Alignment Explorer</h2><p>One fictional request, four stages. Explore at your own pace.</p></div>
  <nav class="ex-stage-nav" aria-label="Alignment Explorer stages">${STAGES.map(stage => `<button class="ex-stage-button${state.stage === stage ? ' is-active' : ''}" type="button" data-ex-stage="${stage}" aria-pressed="${state.stage === stage}" aria-controls="${prefix}-stage-${stage}">${STAGE_LABELS[stage]}</button>`).join('')}</nav>
  ${STAGES.map(stage => `<section class="ex-stage-body" id="${prefix}-stage-${stage}" data-ex-stage-panel="${stage}" aria-label="${STAGE_LABELS[stage]}" ${state.stage === stage ? '' : 'hidden'}>${stage === 'expectations' ? expectationsView(prefix+'-expectations', true) : stage === 'investigate' ? diagnosticView(prefix+'-investigate') : stage === 'coach' ? coachView(prefix+'-coach', true) : evaluationView()}</section>`).join('')}
  <div class="ex-actions"><button class="ex-button ex-button-secondary ex-reset" type="button" data-ex-reset aria-label="Start over: reset the fictional Alignment Explorer">Start over</button><p class="ex-disclosure">Only fictional choices are kept for this browser tab. No model, survey service, or workplace account is connected.</p></div>`;
}
function announce(message) {
  if (liveRegion) liveRegion.textContent = message;
}
function syncViews() {
  for (const {ui} of instances) {
    for (const button of ui.querySelectorAll('[data-ex-role]')) {
      const selected = button.dataset.exRole === state.perspective;
      button.setAttribute('aria-pressed', String(selected));
      button.classList.toggle('is-active', selected);
    }
    for (const heading of ui.querySelectorAll('[data-ex-interpretation-title]')) heading.textContent = `${SCENARIO.perspectives[state.perspective].label}’s possible interpretation`;
    for (const row of interpretation(state)) for (const element of ui.querySelectorAll(`[data-ex-detail="${row.detail}"]`)) {
      element.querySelector('[data-ex-value]').textContent = row.value;
      element.querySelector('[data-ex-basis]').textContent = row.basis;
      element.classList.toggle('ex-confirmed', row.confirmed);
    }
    for (const checkbox of ui.querySelectorAll('[data-ex-confirm]')) checkbox.checked = state.confirmedDetails.includes(checkbox.dataset.exConfirm);
    for (const count of ui.querySelectorAll('[data-ex-count]')) count.textContent = `${state.confirmedDetails.length} of 4 details confirmed`;
    for (const brief of ui.querySelectorAll('[data-ex-brief]')) brief.textContent = deriveBrief(state);
    for (const message of ui.querySelectorAll('[data-ex-completion], [data-ex-copy]')) message.hidden = state.confirmedDetails.length !== 4;
    for (const button of ui.querySelectorAll('[data-ex-stage]')) {
      const selected = button.dataset.exStage === state.stage;
      button.classList.toggle('is-active', selected);
      button.setAttribute('aria-pressed', String(selected));
    }
    for (const panel of ui.querySelectorAll('[data-ex-stage-panel]')) panel.hidden = panel.dataset.exStagePanel !== state.stage;
    for (const button of ui.querySelectorAll('[data-ex-finding]')) {
      button.textContent = state.discussionFindingOpen ? 'Hide the discussion finding' : 'Review the discussion finding';
      button.setAttribute('aria-expanded', String(state.discussionFindingOpen));
    }
    for (const finding of ui.querySelectorAll('[data-ex-finding-content]')) finding.hidden = !state.discussionFindingOpen;
    for (const status of ui.querySelectorAll('[data-ex-copy-status]')) status.textContent = '';
  }
}
function update(action, message) {
  state = transition(state, action);
  persistState();
  syncViews();
  announce(message);
}
function bindInstance(instance) {
  const {ui} = instance;
  ui.addEventListener('change', event => {
    const input = event.target.closest('[data-ex-confirm]');
    if (!input) return;
    const detail = input.dataset.exConfirm;
    update({type:'confirm', detail, confirmed:input.checked}, `${DETAIL_LABELS[detail]} ${input.checked ? 'confirmed' : 'returned to an assumption'}. ${input.checked && !state.confirmedDetails.includes(detail) ? state.confirmedDetails.length + 1 : !input.checked && state.confirmedDetails.includes(detail) ? state.confirmedDetails.length - 1 : state.confirmedDetails.length} of 4 details confirmed.`);
  });
  ui.addEventListener('click', async event => {
    const role = event.target.closest('[data-ex-role]');
    if (role) { update({type:'perspective',value:role.dataset.exRole}, `${SCENARIO.perspectives[role.dataset.exRole].label} perspective selected.`); return; }
    const stage = event.target.closest('[data-ex-stage], [data-ex-next]');
    if (stage) {
      const next = stage.dataset.exStage || stage.dataset.exNext;
      update({type:'stage',value:next}, `${STAGE_LABELS[next]} stage selected.`);
      if (stage.dataset.exNext) ui.querySelector(`[data-ex-stage="${next}"]`)?.focus({preventScroll:true});
      return;
    }
    const finding = event.target.closest('[data-ex-finding]');
    if (finding) { update({type:'finding',open:!state.discussionFindingOpen}, state.discussionFindingOpen ? 'Authored discussion finding hidden.' : 'Authored discussion finding shown. This was not generated.'); return; }
    const reset = event.target.closest('[data-ex-reset]');
    if (reset) { update({type:'reset'}, 'Example reset. Manager perspective, Expectations stage, no confirmed details.'); return; }
    const copy = event.target.closest('[data-ex-copy]');
    if (copy && state.confirmedDetails.length === 4) {
      const status = ui.querySelector('[data-ex-copy-status]');
      try {
        if (!navigator.clipboard?.writeText) throw new Error('Clipboard unavailable');
        await navigator.clipboard.writeText(deriveBrief(state));
        if (status) status.textContent = 'Example brief copied. Nothing was sent.';
      } catch {
        if (status) status.textContent = 'Copying is unavailable. Select the example brief above and copy it manually.';
        ui.querySelector('[data-ex-brief]')?.focus({preventScroll:true});
      }
    }
  });
}

export function mountExplorers(root = document) {
  const mounts = [...root.querySelectorAll('[data-explorer-view]')].filter(mount => mount.dataset.explorerReady !== 'true');
  if (!mounts.length) return;
  try {
    if (!SCENARIO) {
      const data = document.getElementById('alignment-scenario');
      if (!data) return;
      configureScenario(JSON.parse(data.textContent));
      state = readState();
    }
    if (!liveRegion) {
      liveRegion = document.createElement('p');
      liveRegion.className = 'ex-live'; liveRegion.setAttribute('role','status'); liveRegion.setAttribute('aria-live','polite'); liveRegion.setAttribute('aria-atomic','true');
      document.body.append(liveRegion);
    }
    for (const mount of mounts) {
      const kind = mount.dataset.explorerView;
      if (!['perspectives','coach','full'].includes(kind)) continue;
      const prefix = `alignment-${instances.length + 1}`;
      const ui = document.createElement('div'); ui.className = 'explorer-ui ex-panel';
      ui.innerHTML = kind === 'perspectives' ? expectationsView(prefix, false) : kind === 'coach' ? coachView(prefix, false) : fullView(prefix);
      const instance = {mount,ui,kind};
      bindInstance(instance); mount.append(ui); instances.push(instance);
      for (const fallback of mount.querySelectorAll('.explorer-fallback')) fallback.hidden = true;
      mount.dataset.explorerReady = 'true';
    }
    syncViews();
  } catch {
    // If enhancement fails, the server-rendered scenario remains readable.
  }
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => mountExplorers(), {once:true});
  else mountExplorers();
}
