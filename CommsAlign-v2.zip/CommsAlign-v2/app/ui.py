"""Shared presentation for the separate CommsAlign SaaS preview."""
from html import escape
from pathlib import Path

import streamlit as st

ASSETS = Path(__file__).resolve().parent / "assets"


def apply_shell(section: str) -> None:
    """Apply the workspace theme after the page has set its configuration."""
    st.markdown(f"<style>{(ASSETS / 'workspace.css').read_text()}</style>", unsafe_allow_html=True)
    st.logo(str(ASSETS / "brand.svg"), size="large", icon_image=str(ASSETS / "icon.svg"))
    with st.sidebar:
        st.markdown(
            '<div class="ca-workspace"><span class="ca-workspace-mark">D</span>'
            '<div><strong>Demo workspace</strong><span>Explore the prototype</span></div></div>',
            unsafe_allow_html=True,
        )
        with st.expander("About this workspace"):
            st.caption("A local product preview. Team survey data is synthetic. Message reviews require a configured GW Azure connection and your consent.")
            st.caption("Discussion notes and submitted drafts belong to this browser session. Nothing is automatically sent to employees.")
    st.markdown(
        '<div class="ca-topline"><div class="ca-crumb">Workspace'
        f'<span aria-hidden="true">/</span><strong>{escape(section)}</strong></div>'
        '<span class="ca-environment">Local preview</span></div>',
        unsafe_allow_html=True,
    )


def footer() -> None:
    """Close a page with accurate, quiet workspace context."""
    st.markdown(
        '<footer class="ca-footer"><span>CommsAlign · Communication with perspective</span>'
        '<span>Prototype · Interpretations are provisional</span></footer>',
        unsafe_allow_html=True,
    )
