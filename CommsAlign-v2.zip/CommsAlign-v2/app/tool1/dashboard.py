"""Session-only interface for the teammates' Tool 1 judge."""
from dataclasses import asdict
import html
import json
import re
import streamlit as st
import altair as alt
from app.tool1.rubrics import RUBRICS
from app.ui import apply_shell, footer


def dimension_label(name):
    return re.sub(r'^[DF]\d+_', '', name).replace('_',' ').capitalize()


def score_chart(result):
    if result['abstain']:
        return
    rows=[]
    unscored=[]
    for name,rating in result['dimensions'].items():
        label=dimension_label(name)
        if rating['status']=='scored' and rating['score'] is not None:
            rows.append({'Dimension':label,'Score':rating['score'],'Baseline':1})
        else:
            unscored.append(label)
    if rows:
        st.subheader('Rubric scores')
        chart=alt.Chart(alt.Data(values=rows)).encode(
            y=alt.Y('Dimension:N',sort=[row['Dimension'] for row in rows],title=None),
            x=alt.X('Score:Q',scale=alt.Scale(domain=[1,5],zero=False),
                    axis=alt.Axis(values=[1,2,3,4,5]),title='Score (1–5)'),
            tooltip=['Dimension:N','Score:Q'],
        )
        bars=chart.mark_bar(color='#326A55',size=22).encode(x2='Baseline:Q')
        points=chart.mark_point(filled=True,color='#326A55',size=65)
        labels=chart.mark_text(align='left',dx=9,color='#24372F').encode(text='Score:Q')
        st.altair_chart((bars+points+labels).properties(height=max(120,len(rows)*48)),use_container_width=True)
        st.caption('Bars start at 1, the lowest rubric score. Higher scores indicate closer alignment with the rubric.')
    if unscored:
        st.caption('Not scored: '+', '.join(unscored)+'. See the explanations below.')


def clear_message():
    st.session_state['tool1_result']=None
    st.session_state['tool1_draft']=''
    st.session_state.pop('tool1_revision',None)
    st.session_state.pop('tool1_rescore',None)


def main():
    st.set_page_config(page_title='CommsAlign — Message Coach',layout='wide')
    apply_shell('Message Coach')
    st.title('Message Coach')
    st.write('Give your next message a second look. Review a task instruction or performance feedback draft using the team’s rubric.')
    st.session_state.setdefault('tool1_result',None)
    if (st.session_state['tool1_result'] or {}).get('sample'):
        st.session_state['tool1_result']=None
    editor, guidance = st.columns([1.8, 1], gap='large')
    with editor:
        with st.form('tool1_review'):
            st.subheader('Write your message')
            kind=st.selectbox('Message type',list(RUBRICS),format_func=lambda value:value.replace('_',' ').title())
            draft=st.text_area('Draft message',height=260,key='tool1_draft',
                               placeholder='Paste a draft you would like to review. Include the context, action, and timing your reader needs.')
            consent=st.checkbox('I agree to send this draft to the configured GW Azure model for evaluation.')
            st.caption('Use a non-identifying draft. Nothing is sent to employees.')
            submit=st.form_submit_button('Evaluate draft',type='primary',use_container_width=True)
    with guidance:
        with st.container(key='coach-guide-panel',border=True):
            st.subheader('Make the review useful')
            st.markdown('**Task instructions**\n\nInclude what needs to happen, the expected outcome, and any timing or constraints.')
            st.markdown('**Performance feedback**\n\nDescribe the observed behavior and its impact. Include the context your reader would need.')
            st.divider()
            st.caption('Evaluation sends your draft to the configured GW Azure service only when you submit it with consent. No message is sent to employees. The rewrite never invents facts: anything only you know is left as a [gap?] to fill in. Avoid identifying or sensitive content.')
        with st.container(key='coach-review-caution'):
            st.info('Scores are rubric-based model judgments, not validated measures of communication effectiveness. Review the evidence and output yourself.')
    if submit:
        st.session_state['tool1_result']=None
        st.session_state.pop('tool1_revision',None)
        st.session_state.pop('tool1_rescore',None)
        if not draft.strip():
            st.error('Enter a draft message to evaluate.')
        elif not consent:
            st.error('Confirm the model submission before evaluating.')
        else:
            progress=st.progress(10,text='10% — Checking connection settings')
            st.caption('Progress reflects review stages. It stays at 25% while the model responds.')
            try:
                from app.tool1.config import load_settings
                from app.tool1.pipeline import run
                try:
                    load_settings()
                except RuntimeError:
                    progress.empty()
                    st.error('GW Azure settings are missing. Configure the required settings in your local .env file; never paste API keys into chat or commit them to GitHub.')
                else:
                    progress.progress(25,text='25% — Scoring, rewriting, and scoring the rewrite…')
                    with st.spinner('Reviewing and rewriting the draft…'):
                        res=run(draft,kind)
                    st.session_state['tool1_result']={'draft':draft,'kind':kind,'result':asdict(res.before),
                        'rewrite':asdict(res.rewrite) if res.rewrite else None,'after':asdict(res.after) if res.after else None}
                    progress.progress(100,text='100% — Review complete. Your results are below.')
            except ImportError:
                progress.empty()
                st.error('Install requirements-tool1.txt to enable the model connection.')
            except Exception:
                progress.empty()
                st.error('Evaluation could not be completed. Check the GW connection settings and model access, then retry. No result has been substituted.')
    with st.expander('Connection setup and rubric'):
        st.write('Install requirements-tool1.txt, then copy .env.example to .env and enter your GW-provided settings locally. Never commit .env.')
        st.code('GW_AZURE_OPENAI_KEY\nGW_ENDPOINT\nGW_API_VERSION\nGW_MODEL')
        st.markdown(RUBRICS[kind].text())
    saved=st.session_state['tool1_result']
    if not saved:
        with st.container(key='coach-empty-state',border=True):
            st.subheader('Your review will appear here')
            st.write('Submit a draft to see rubric ratings, the evidence behind them, and a suggested revision when available.')
            st.caption('Live evaluation requires your configured GW Azure connection. You review every result before using it.')
    if saved:
        result=saved['result']
        st.subheader('Evaluation of the last submitted draft')
        st.text(saved['draft'])
        if result['abstain']:
            st.warning('Judge abstained: '+str(result['abstain_reason'] or 'Outside rubric scope.'))
        else:
            st.write('Rubric label: '+str(result['label']).replace('_',' '))
        st.caption('Model-reported confidence: '+result['confidence_level']+' — '+result['confidence_note'])
        score_chart(result)
        for name,rating in result['dimensions'].items():
            st.write('**'+dimension_label(name)+'**')
            st.write(f'Status: {rating["status"]}; score: {rating["score"] if rating["score"] is not None else "Not scored"}')
            for quote in rating['evidence']:
                st.text('Evidence: '+quote)
            st.write(rating['note'])
        for warning in result['warnings']:
            st.warning(warning)
        rw=saved.get('rewrite')
        if rw:
            st.subheader('Suggested rewrite')
            st.caption('Highlighted [gaps?] are details only you know. The tool never guesses them.')
            st.markdown('<div class="ca-rewrite">'
                        +re.sub(r'(\[[^\[\]]*\?\])',r'<mark>\1</mark>',html.escape(rw['rewrite']))+'</div>',unsafe_allow_html=True)
            for w in rw['warnings']:
                st.warning(w)
            after=saved.get('after')
            if after and rw['changes']:
                st.write('Rewrite label: '+str(after['label']).replace('_',' '))
                score_chart(after)
            if rw['changes']:
                st.subheader('Why these changes')
                cards={c['id']:c for c in rw['cards']}
                for ch in rw['changes']:
                    with st.expander(dimension_label(str(ch.get('dimension','')))+': '+str(ch.get('what',''))):
                        st.write(ch.get('why',''))
                        for cid in ch.get('card_ids') or []:
                            c=cards.get(cid)
                            if c:
                                st.markdown(f"**Evidence ({c['setting']}).** {c['finding']}  \n_{c['source']}, {c['locator']}. Limits: {c['limits']}_")
                        if not ch.get('card_ids'):
                            st.caption('No evidence card applies to this change; it follows the rubric only.')
            st.subheader('Fill in the gaps and re-score')
            st.session_state.setdefault('tool1_revision',rw['rewrite'])
            revision=st.text_area('Your version',height=220,key='tool1_revision')
            if st.button('Re-score my version',disabled=not revision.strip()):
                from app.tool1.pipeline import rescore
                try:
                    with st.spinner('Scoring your version…'):
                        st.session_state['tool1_rescore']=asdict(rescore(revision,saved.get('kind',kind)))
                except Exception:
                    st.error('Re-scoring could not be completed. Check the GW connection and retry.')
            again=st.session_state.get('tool1_rescore')
            if again:
                if again['abstain']:
                    st.warning('Judge abstained: '+str(again['abstain_reason']))
                else:
                    st.write('Your version label: '+str(again['label']).replace('_',' '))
                    score_chart(again)
            st.download_button('Download your revision',revision,file_name='commsalign-revised-draft.txt',mime='text/plain')
        st.download_button('Download Message Review',json.dumps(saved,indent=2),file_name='commsalign-message-review.json',mime='application/json')
        st.button('Clear message and result',on_click=clear_message)
    footer()
