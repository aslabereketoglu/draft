"""Local presentation layer. Run: streamlit run app/organizational/dashboard.py."""
from html import escape
from pathlib import Path
import sys

# Streamlit executes this file as a script; resolve imports from any working directory.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import streamlit as st
from app.ui import apply_shell, footer

from app.organizational.analyzer import analyze_csv
from app.organizational.workflow import render_workflow, prune_suppressed_notes
from app.organizational.evidence_validation import load_evidence_validation_matrix
from app.organizational.report import ITEM_TOPICS, conversation_priorities, render_report, item_tie_notice

SAMPLE_PATH = PROJECT_ROOT / 'data' / 'organizational' / 'sample_q12_results.csv'
SYNTHETIC_LABEL = 'Synthetic demonstration data — not real Gallup results.'
NEXT_STEPS = (
    'Review the identified signals.',
    'Discuss the findings with the team.',
    'Ask the suggested questions to understand what is behind the survey results.',
    'Document what the team says.',
    'Decide whether additional evidence or action is needed.',
)
VALIDATION_CAUTION = 'Validate the hypotheses with employees before taking action.'
MISSING_ITEMS_CAUTION = 'Missing items are not imputed; available-item summaries may not be comparable to complete summaries.'


def _join_topics(topics):
    if len(topics) < 2:
        return ''.join(topics)
    return ', '.join(topics[:-1]) + ' and ' + topics[-1]


def executive_narrative(report):
    """Describe existing rankings and selected signals without new inference."""
    if set(report.hierarchy_strengths) == set(report.hierarchy_opportunities):
        hierarchy = ('Available hierarchy areas are tied; the results do not distinguish '
                     'a strongest area from an area for investigation.')
    else:
        stronger = _join_topics(report.hierarchy_strengths)
        investigation = _join_topics(report.hierarchy_opportunities)
        verb = 'is the primary hierarchy area' if len(report.hierarchy_opportunities) == 1 else 'are tied hierarchy areas'
        hierarchy = (f'This team shows relatively stronger signals in {stronger}, '
                     f'while {investigation} {verb} for investigation.')
    topics = tuple(dict.fromkeys(
        'clarity of expectations' if signal.signal_name == 'expectations_and_direction'
        else signal.signal_name.replace('_', ' ')
        for signal in report.communication_signals
    ))
    communication = (
        f'Communication-related signals suggest exploring {_join_topics(topics)}.'
        if topics else 'No mapped communication signals were selected for exploration.'
    )
    return f'{hierarchy} {communication}'


def diagnostic_summary_text(report):
    """Download the selected report with the same cautions and discussion steps."""
    if report.suppressed:
        return SYNTHETIC_LABEL + '\n' + render_report(report)
    text = render_report(report)
    text = text.replace('Hierarchy summaries:', executive_narrative(report) + '\n\nHierarchy scores:', 1)
    next_section = '\n'.join([
        '6. What to Do Next', 'Suggested discussion steps, not prescriptions.',
        *(f'{number}. {step}' for number, step in enumerate(NEXT_STEPS, 1)),
        VALIDATION_CAUTION, '', '7. Limitations',
    ])
    text = text.replace('6. Limitations', next_section, 1)
    return '\n'.join([
        SYNTHETIC_LABEL,
        'Survey results are signals and hypotheses only. They do not establish causes.',
        'No causal inference is performed.', '', text,
        '- ' + MISSING_ITEMS_CAUTION,
    ])



def item_rows(records, stronger):
    """Present existing rankings without rescoring or introducing thresholds."""
    return [
        {
            'Q12 Item': record.item_id,
            'Mean Score': record.mean_score,
            'Respondent Count': record.respondent_count,
            'Plain-Language Interpretation': (
                f'A relatively stronger signal concerning {ITEM_TOPICS[record.item_id]} within this team and period.'
                if stronger else
                f'A relatively lower-scoring signal concerning {ITEM_TOPICS[record.item_id]}; explore team experiences.'
            ),
        }
        for record in records
    ]


def hierarchy_chart_spec(report):
    """Show the full valid response scale, with bars explicitly based at 1."""
    return {
        'description': 'Hierarchy mean scores on the complete 1–5 survey scale. Bars start at 1, the minimum valid response.',
        'data': {'values': [
            {'area': area, 'score': score}
            for area, score in report.hierarchy_scores.items() if score is not None
        ]},
        'height': 300,
        'mark': {'type': 'bar', 'color': '#285D7A', 'clip': True},
        'encoding': {
            'x': {'field': 'area', 'type': 'nominal',
                  'sort': list(report.hierarchy_scores),
                  'axis': {'title': 'Engagement Hierarchy Area', 'labelAngle': 0}},
            'y': {'field': 'score', 'type': 'quantitative',
                  'scale': {'domain': [1, 5], 'zero': False, 'nice': False},
                  'axis': {'title': 'Mean Score (1–5)', 'values': [1, 2, 3, 4, 5]}},
            'y2': {'datum': 1},
            'tooltip': [
                {'field': 'area', 'type': 'nominal', 'title': 'Hierarchy Area'},
                {'field': 'score', 'type': 'quantitative', 'title': 'Mean Score', 'format': '.2f'},
            ],
        },
    }


# Concise presentation labels only; these do not define communication mappings.
ITEM_LABELS = {
    'Q01': 'Expectations & Direction', 'Q02': 'Information & Resources',
    'Q03': 'Use of Strengths', 'Q04': 'Recognition', 'Q05': 'Care & Support',
    'Q06': 'Development Support', 'Q07': 'Employee Voice',
    'Q08': 'Purpose Connection', 'Q09': 'Quality & Team Standards',
    'Q10': 'Close Workplace Relationships', 'Q11': 'Progress Feedback',
    'Q12': 'Learning & Growth',
}


def evidence_display_label(status):
    """Translate internal status text without modifying stored evidence values."""
    if status in ('needs_review', 'provisional_needs_evidence_review'):
        return 'Further validation needed'
    return status.replace('_', ' ').capitalize()



def _card_grid(cards, four=False):
    """Render escaped display content in a responsive presentation-only grid."""
    st.markdown('<div class="aa-grid' + (' aa-grid-four' if four else '') + '">' +
                ''.join(cards) + '</div>', unsafe_allow_html=True)


def signal_cards(records, stronger):
    """Present the same ranked item rows as compact cards."""
    tone = 'green' if stronger else 'gold'
    badge = 'Stronger signal' if stronger else 'Area to explore'
    cards = []
    for row in item_rows(records, stronger):
        cards.append(
            f'<article class="aa-card {tone}"><span class="aa-badge {tone}">{badge}</span>'
            f'<div class="aa-item-title">{escape(row["Q12 Item"])} — {escape(ITEM_LABELS[row["Q12 Item"]])}</div>'
            f'<div class="aa-score">{row["Mean Score"]:.2f} <small>/ 5</small></div>'
            f'<div class="aa-label">Respondents: {row["Respondent Count"]}</div>'
            f'<p>{escape(row["Plain-Language Interpretation"])}</p></article>'
        )
    _card_grid(cards)


def main():
    st.set_page_config(page_title='CommsAlign — Team Diagnostic', layout='wide')
    apply_shell('Team Diagnostic')
    st.title('Team Diagnostic')
    st.write('Explore aggregate survey patterns and prepare a focused team discussion.')
    st.caption('Uses synthetic Q12-style demonstration data. Findings remain provisional.')
    with st.container(key='causal-caution'):
        st.warning('Survey results are signals and hypotheses only. They do not establish causes.')

    minimum_responses = int(st.sidebar.number_input(
        'Minimum responses per item', min_value=1, value=5, step=1, key='ca_minimum_responses',
        help='Use your organization-approved reporting threshold. Any supplied item below it suppresses the entire team/period.'))
    st.caption(f'Privacy rule: at least {minimum_responses} responses per supplied item. A failing item suppresses all team/period scores, rankings, prompts and downloads. This does not guarantee anonymity.')
    matrix = load_evidence_validation_matrix()
    try:
        reports = analyze_csv(SAMPLE_PATH, minimum_responses=minimum_responses)
    except (ValueError, OSError) as error:
        st.error(f'Unable to load the synthetic demonstration data: {error}')
        st.stop()

    prune_suppressed_notes(st.session_state, reports)

    with st.sidebar:
        st.header('Select Team')
        team_options = list(dict.fromkeys(r.team_id for r in reports))
        if st.session_state.get('ca_report_team') not in team_options:
            st.session_state['ca_report_team'] = team_options[0]
        team_id = st.selectbox('Team ID', team_options, key='ca_report_team')
        team_reports = [r for r in reports if r.team_id == team_id]
        if len(team_reports) > 1:
            period = st.selectbox('Period', [r.period for r in team_reports],
                                  format_func=lambda value: value or 'Not supplied')
            report = next(r for r in team_reports if r.period == period)
        else:
            report = team_reports[0]
        with st.expander('Methodology'):
            st.write('How this prototype works')
            st.write('Aggregated survey data → validation → Q12 hierarchy analysis → relative team-level patterns → provisional communication mapping → manager discussion prompts')
            st.write('No causal inference is performed.')
            st.caption('Mappings are provisional and need evidence review. No benchmark percentile is inferred. No LLM or RAG is used.')
        with st.expander('Data Disclosure'):
            st.info(SYNTHETIC_LABEL)
            st.caption('The bundled dataset contains fictional teams and invented scores for demonstration only.')
        with st.expander('Limitations'):
            st.write('Results are relative to each team and period. Small groups may create privacy risks; the configured minimum-response rule suppresses the entire team/period when any supplied item fails.')
            st.caption('See Methodology & Limitations below for the full cautions.')

    if report.suppressed:
        for limitation in report.limitations:
            st.warning(limitation)
        st.stop()
    for note in report.data_quality_notes:
        st.warning(note)

    overview_tab, discussion_tab, evidence_tab = st.tabs([
        'Team overview', 'Signals & next steps', 'Evidence & method',
    ])
    with overview_tab:
        st.header('Executive Summary')
        st.caption(f'Team ID: {report.team_id} · Period: {report.period or "Not supplied"}')
        summary_cards = [
            ('Mean score', f'{report.grand_mean:.2f} / 5', 'Average of available items', ''),
            ('Strongest area', ', '.join(report.hierarchy_strengths), 'Relative stronger signal', 'green'),
            ('Area to explore', ', '.join(report.hierarchy_opportunities), 'Area for investigation', 'gold'),
            ('Selected team', report.team_id.removeprefix('SYNTHETIC_'), 'Synthetic demonstration team', 'teal'),
        ]
        _card_grid([
            f'<article class="aa-card {tone}"><div class="aa-label">{escape(label)}</div>'
            f'<div class="aa-value">{escape(value)}</div><div class="aa-label">{escape(note)}</div></article>'
            for label, value, note, tone in summary_cards
        ], four=True)
        st.write(executive_narrative(report))
        st.caption('Areas are relative within this team and period. All tied hierarchy areas are listed.')

        st.header('Hierarchy Profile')
        hierarchy_cards = []
        for area, score in report.hierarchy_scores.items():
            strongest = area in report.hierarchy_strengths
            investigate = area in report.hierarchy_opportunities
            tone = 'gold' if investigate else 'green' if strongest else 'teal'
            label = ('Tied across areas' if strongest and investigate else
                     'Area to explore' if investigate else 'Strongest area' if strongest else 'Hierarchy area')
            score_html = f'{score:.2f} <small>/ 5</small>' if score is not None else '<small>Unavailable</small>'
            meter = (f'<meter min="1" max="5" value="{score}" aria-label="{escape(area)}: {score:.2f} out of 5">{score:.2f} out of 5</meter>'
                     if score is not None else '')
            hierarchy_cards.append(
                f'<article class="aa-card {tone}"><div class="aa-label">{escape(area)}</div>'
                f'<div class="aa-score">{score_html}</div>{meter}'
                f'<div class="aa-scale"><span>1</span><span>Mean score (1–5)</span><span>5</span></div>'
                f'<p><span class="aa-badge {tone}">{label}</span></p></article>'
            )
        _card_grid(hierarchy_cards, four=True)
        st.caption('Scores are aggregated team-level means from synthetic demonstration data.')
        st.caption('Bars show the full valid 1–5 scale, starting at 1. Missing areas are unavailable and are not imputed. Tied areas are labeled explicitly.')

        if item_tie_notice(report):
            st.info(item_tie_notice(report))
        st.header('Stronger Signals')
        st.caption('Relative strengths within this team and period.')
        signal_cards(report.strengths, True)
        st.header('Areas for Investigation')
        st.caption('Relatively lower-scoring items to discuss with the team.')
        signal_cards(report.opportunities, False)

        st.download_button(
            'Download Diagnostic Summary', data=diagnostic_summary_text(report),
            file_name='commsalign-diagnostic-summary.txt', mime='text/plain; charset=utf-8', type='primary',
        )

    with discussion_tab:
        st.header('Communication Signals to Explore')
        st.caption('Open a signal to explore the interpretation and questions. Relationships are provisional associations, not causal explanations.')
        if not report.communication_signals:
            st.info('No mapped items in the lower-scoring selection.')
        for signal_index, signal in enumerate(report.communication_signals):
            name = signal.signal_name.replace('_', ' ').title()
            evidence = evidence_display_label(signal.evidence_status)
            tone = {'direct': 'teal', 'partial': 'gray', 'indirect': 'gold'}.get(signal.relationship_type, 'gray')
            with st.container(key=f'signal-{signal.relationship_type}-{signal_index}'):
                with st.expander(f'{name} · {signal.source_q12_item} · {signal.observed_score:.2f} / 5 · `{signal.relationship_type} conceptual link` · `{evidence}`'):
                    st.markdown(
                        f'<span class="aa-badge {tone}">{escape(signal.relationship_type)} conceptual link</span> '
                        f'<span class="aa-badge gray">Evidence: {escape(evidence)}</span>',
                        unsafe_allow_html=True,
                    )
                    st.subheader(name)
                    st.write(f'**Source Q12 item:** {signal.source_q12_item}')
                    st.write(f'**Observed score:** {signal.observed_score:.2f} / 5')
                    st.write(f'**Conceptual link to communication:** {signal.relationship_type}. This is not a research-validation rating.')
                    st.write(f'**Evidence status:** {evidence}')
                    st.caption('Interpretation remains provisional; no numerical confidence is estimated.')
                    validation = matrix.get_by_source_item(signal.source_q12_item)
                    if validation is not None:
                        st.write('**Preliminary mapping review:** ' + evidence_display_label(validation.validation_status))
                        st.write('**Permitted discussion framing:** ' + validation.allowed_language)
                        if validation.validation_status != 'pending':
                            st.markdown(f'[Research source]({validation.external_source_reference})')
                            st.caption(validation.review_notes)
                    st.write(f'**Interpretation:** {signal.interpretation}')
                    st.warning(signal.caution)
                    st.subheader('Questions to discuss with the team')
                    for number, question in enumerate(signal.manager_questions, 1):
                        st.write(f'{number}. {question}')
        st.header('Conversation Priorities')
        st.caption('Topics to explore with the team — not prescriptions.')
        priorities = conversation_priorities(report)
        _card_grid([
            f'<article class="aa-card teal aa-priority"><span class="aa-badge">Discussion {number}</span>'
            f'<h3>Explore {escape(report.communication_signals[min(number - 1, len(report.communication_signals) - 1)].signal_name.replace("_", " "))}</h3>'
            f'<p>{escape(priority)}</p></article>'
            for number, priority in enumerate(priorities, 1)
        ])
        if not priorities:
            st.info('No communication signals selected; no signal-based conversation priorities generated.')

        st.header('What to Do Next')
        st.caption('Suggested discussion steps, not prescriptions.')
        step_titles = ('Review signals.', 'Discuss with team.', 'Ask follow-up questions.',
                       'Capture what you learn.', 'Decide whether action is needed.')
        st.markdown('<div class="aa-card">' + ''.join(
            f'<div class="aa-step"><span class="aa-number">{number}</span><div>'
            f'<strong>{escape(title)}</strong><p>{escape(step)}</p></div></div>'
            for number, (title, step) in enumerate(zip(step_titles, NEXT_STEPS), 1)
        ) + '</div>', unsafe_allow_html=True)
        with st.container(key='validation-callout'):
            st.info(VALIDATION_CAUTION)

        render_workflow(report, matrix)

    with evidence_tab:
        st.header('Evidence & method')
        st.write('Understand the reporting rules and the limits of these provisional interpretations.')
        with st.expander('Data-quality rules'):
            st.write('Aggregate inputs only. Scores must be finite and between 1 and 5; counts must be positive integers. Duplicate team/item/period rows, malformed files and invalid values reject the entire input. Missing items are not imputed; summaries use available items equally. Varying item counts do not establish a unique respondent total.')

        with st.expander('Evidence validation status'):
            pending = len(matrix.awaiting_external_review())
            st.write(f'Initial research reviews recorded: {len(matrix.validations) - pending} of {len(matrix.validations)}. Initial reviews not yet recorded: {pending}. All mappings still need human review; none is a validated communication diagnosis. Full-text access checks remain open where noted. These reviews do not change survey scores or rankings.')
            st.write('Partially supported means research supports part of the claim. Indirect support means research concerns a related concept. A direct conceptual link describes our interpretation of an item; it does not mean the mapping is directly validated by research.')
            st.dataframe([{'Dimension': v.dimension_name, 'Research support': evidence_display_label(v.validation_status),
                           'Support level (provisional)': evidence_display_label(v.external_support_level),
                           'Review scope': evidence_display_label(v.review_scope),
                           'Full-text check': evidence_display_label(v.full_text_status),
                           'Discussion framing': v.allowed_language}
                          for v in matrix.validations], hide_index=True)
            st.caption(f'{sum(v.full_text_status == "access_pending" for v in matrix.validations)} full-text checks remain pending because access was unavailable. Targeted section checks are not comprehensive paper appraisals.')
            for validation in matrix.validations:
                if validation.validation_status != 'pending':
                    st.markdown(f'**{validation.dimension_name}** — {evidence_display_label(validation.validation_status)}')
                    st.write(validation.external_research_support)
                    st.markdown(f'[Research source]({validation.external_source_reference}) · [Gallup item context]({validation.source_reference})')
                    st.caption(validation.review_notes)

        with st.expander('Methodology & Limitations'):
            st.write('Aggregated results describe signals, not causes. Communication mappings remain provisional and need evidence review.')
            for limitation in report.limitations:
                st.write(f'- {limitation}')
            st.write('- ' + MISSING_ITEMS_CAUTION)
            if report.missing_items:
                st.write('**Missing items:** ' + ', '.join(report.missing_items))

    st.caption('Inspired by contemporary employee-engagement reporting practices. Not affiliated with or endorsed by Gallup.')
    footer()


if __name__ == '__main__':
    main()
