"""Reviewed copy and fictional fixtures for the public CommsAlign website.

The public demonstration is independent of application analysis and model calls.
"""
from pathlib import Path
import json

MARKETING_ROUTES = {
    "/": {
        "title": "CommsAlign — From team insight to clearer manager messages",
        "description": "Explore a connected approach to team communication: investigate patterns, coach managerial drafts and plan how to evaluate change.",
    },
    "/how-it-works": {
        "title": "How it works — CommsAlign",
        "description": "Understand the path from a team concern through human discussion to a clearer managerial message and proposed evaluation.",
    },
    "/demo": {
        "title": "Alignment Explorer — CommsAlign",
        "description": "Explore a fictional expectation gap, confirm missing details and build a shared written brief without live AI or employee data.",
    },
    "/solutions": {
        "title": "Communication pilot examples — CommsAlign",
        "description": "Explore focused communication pilot ideas for People and HR leaders, managers and operational teams.",
    },
    "/research": {
        "title": "Approach, evidence and product status — CommsAlign",
        "description": "See the documented prototype, the limits of survey interpretation, conditional message review and the proposed evaluation agenda.",
    },
    "/pricing": {
        "title": "A focused team pilot — CommsAlign",
        "description": "Discuss a narrow use case, responsible information handling and what a team pilot should test. No public subscription prices are confirmed.",
    },
    "/request-pilot": {
        "title": "Request a team pilot — CommsAlign preview",
        "description": "Preview a focused pilot enquiry. This local preview validates the form without sending or saving contact information.",
    },
}

# One authored fixture supplies SSR fallbacks, browser interaction and tests.
SCENARIO = json.loads(
    (Path(__file__).resolve().parents[1] / "web" / "alignment-scenario.json").read_text(encoding="utf-8")
)

DETAIL_LABELS = {
    "deliverable": "Deliverable",
    "deadline": "Deadline",
    "purpose": "Purpose",
    "checkin": "Check-in",
}

CAPABILITIES = [
    {
        "id": "team-diagnostic",
        "title": "Team survey patterns and discussion",
        "status": "documented-prototype",
        "summary": "The prototype analyzes bundled synthetic team survey inputs and supports discussion notes and downloadable summaries.",
        "disclosure": "Patterns are relative signals, not causal explanations. Small-response suppression is one safeguard, not an anonymity guarantee.",
        "sourceIds": ["R1", "R2", "R3", "V2"],
    },
    {
        "id": "message-coach",
        "title": "Draft assessment, revision and re-scoring",
        "status": "documented-prototype",
        "summary": "The current v2 source supports draft assessment, suggested revisions and re-scoring when GW Azure is configured and a user explicitly consents.",
        "disclosure": "A live model connection was not validated in this website work. The public example is authored and makes no model request. Source support does not establish production availability or effectiveness.",
        "sourceIds": ["R1", "R2", "V2"],
    },
    {
        "id": "alignment-explorer",
        "title": "Alignment Explorer",
        "status": "proposed",
        "summary": "A working public-site demonstration lets visitors inspect fictional assumptions and confirm authored scenario facts.",
        "disclosure": "Deterministic website interaction, not live AI, detected beliefs, employee assessment or proof of shared understanding.",
        "sourceIds": ["B1"],
    },
    {
        "id": "automatic-handoff",
        "title": "Automatic diagnostic-to-coaching handoff",
        "status": "proposed",
        "summary": "The connected story includes a manager choosing a coaching focus after a human discussion.",
        "disclosure": "Automatic cross-tool transfer and intervention routing are not implemented. Shared navigation is not automatic integration.",
        "sourceIds": ["R1", "R2", "V2"],
    },
    {
        "id": "measurement",
        "title": "Longitudinal measurement and follow-up",
        "status": "proposed",
        "summary": "A focused pilot could investigate message clarity, recipient understanding, clarification requests and time costs.",
        "disclosure": "No measured CommsAlign outcomes, automated follow-up surveys or live longitudinal tracking dashboard are shown.",
        "sourceIds": ["B1", "V2"],
    },
    {
        "id": "commercial-availability",
        "title": "Pilot availability and commercial terms",
        "status": "unverified",
        "summary": "The intended next step is a conversation with the project owner about scope, fit and availability.",
        "disclosure": "No public prices, self-service subscription, instant provisioning, response deadline or access guarantee has been established. This site's form is a preview.",
        "sourceIds": ["B1"],
    },
]

STATUS_LABELS = {
    "documented-prototype": "Documented prototype",
    "intended": "Intended approach",
    "proposed": "Proposed",
    "unverified": "Unverified",
}

SOURCE_LEDGER = [
    {
        "id": "R1",
        "title": "Repository README",
        "url": "https://github.com/aslabereketoglu/urmom/blob/main/README.md",
        "note": "Documents the shared prototype, synthetic inputs and conditional model setup. It also contains an older standalone CLI; that CLI's dimensions are not substituted for Message Coach's imported judge.",
    },
    {
        "id": "R2",
        "title": "Tool integration notes",
        "url": "https://github.com/aslabereketoglu/urmom/blob/main/docs/TOOL1_TOOL2_INTEGRATION.md",
        "note": "Describes shared navigation, consented model submission and integration limits. Historical deployment notes do not verify current hosting or a live model connection.",
    },
    {
        "id": "R3",
        "title": "Team Diagnostic demo guide",
        "url": "https://github.com/aslabereketoglu/urmom/blob/main/docs/TOOL2_DEMO_GUIDE.md",
        "note": "Describes synthetic scenarios, relative patterns, discussion records, exports and response-threshold suppression. It does not establish causation or production anonymity.",
    },
    {
        "id": "V2",
        "title": "Local v2 implementation review",
        "url": None,
        "note": "The current source includes conditional suggested revisions and re-scoring. This corrects the supplied brief's older documentation-based statement that rewriting was unimplemented. Live model operation and business impact remain unverified.",
    },
    {
        "id": "B1",
        "title": "Website implementation brief",
        "url": None,
        "note": "Prepared 7 November 2026. The narrative, fictional Atlas scenario, Alignment Explorer and proposed evaluation plan are authored marketing proposals, not product outcomes or customer evidence.",
    },
]
