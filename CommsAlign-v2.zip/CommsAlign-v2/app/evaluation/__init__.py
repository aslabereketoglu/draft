"""Configurable, provisional communication evaluation."""
