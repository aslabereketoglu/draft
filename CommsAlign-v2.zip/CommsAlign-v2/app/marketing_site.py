"""Server-rendered public pages, separate from the private-use workspace.

Important content and fictional examples remain readable without JavaScript.
"""
from html import escape
import json

from app.marketing_content import (
    CAPABILITIES, DETAIL_LABELS, MARKETING_ROUTES, SCENARIO,
    SOURCE_LEDGER, STATUS_LABELS,
)


def _e(value):
    return escape(str(value), quote=True)


def _button(label, href, primary=False, quiet=False):
    variant = 'mk-button-primary' if primary else 'mk-button-quiet' if quiet else 'mk-button-secondary'
    return f'<a class="mk-button {variant}" href="{_e(href)}">{_e(label)}</a>'


def _actions(primary='Request a team pilot', secondary='Explore the example'):
    return '<div class="mk-actions">' + _button(primary, '/request-pilot', True) + _button(secondary, '/demo') + '</div>'


def _disclosure(text, planned=False):
    return f'<p class="mk-disclosure{" mk-proposed" if planned else ""}">{_e(text)}</p>'


def _header(path):
    links = [('/how-it-works', 'How it works'), ('/solutions', 'Solutions'), ('/research', 'Research'), ('/pricing', 'Pricing')]
    navigation_parts = []
    for href, label in links:
        current = ' aria-current="page"' if path == href else ''
        navigation_parts.append(f'<a href="{href}"{current}>{label}</a>')
    navigation = ''.join(navigation_parts)
    return f'''<header class="mk-header"><div class="mk-container mk-header-inner">
      <a class="mk-brand" href="/" aria-label="CommsAlign home"><img src="/assets/brand.svg" alt="CommsAlign" width="176" height="35"></a>
      <button class="mk-menu-toggle" id="marketing-menu-toggle" type="button" aria-expanded="false" aria-controls="marketing-nav"><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><path d="M4 6h16M4 12h16M4 18h16"/></svg><span>Menu</span></button>
      <nav class="mk-nav" id="marketing-nav" aria-label="Main navigation">{navigation}<div class="mk-nav-actions">{_button('Workspace', '/workspace', quiet=True)}{_button('Request a team pilot', '/request-pilot', True)}</div></nav>
    </div></header>'''


def _footer():
    return '''<footer class="mk-footer"><div class="mk-container mk-footer-inner">
      <div><a class="mk-brand" href="/"><img src="/assets/brand.svg" alt="CommsAlign" width="164" height="33"></a><p>CommsAlign connects team communication concerns with practical manager coaching.</p><p class="mk-meta">Local preview. Pilot requests are not being sent.</p></div>
      <nav aria-label="Footer navigation"><a href="/how-it-works">How it works</a><a href="/demo">Explore the example</a><a href="/solutions">Solutions</a><a href="/pricing">Pricing</a><a href="/request-pilot">Request a team pilot</a><a href="/research#product-status">Prototype and methodology</a><a href="/workspace">Existing workspace</a></nav>
    </div></footer>'''


def _shell(path, body, metadata=None):
    meta = metadata or MARKETING_ROUTES[path]
    scenario_data = ''
    if path in ('/', '/demo'):
        encoded = json.dumps(SCENARIO, ensure_ascii=False).replace('<', '\\u003c').replace('&', '\\u0026')
        scenario_data = f'<script type="application/json" id="alignment-scenario">{encoded}</script>'
    return f'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light">
<title>{_e(meta['title'])}</title><meta name="description" content="{_e(meta['description'])}"><meta name="robots" content="noindex,nofollow">
<meta property="og:type" content="website"><meta property="og:site_name" content="CommsAlign"><meta property="og:title" content="{_e(meta['title'])}"><meta property="og:description" content="{_e(meta['description'])}">
<link rel="icon" href="/assets/icon.svg" type="image/svg+xml"><link rel="stylesheet" href="/marketing.css"><script type="module" src="/marketing.js"></script>{'<script type="module" src="/explorer.js"></script>' if scenario_data else ''}
</head><body class="mk-site" data-marketing-page="{_e(path)}"><a class="mk-skip-link" href="#marketing-main">Skip to content</a>{_header(path)}<main class="mk-main" id="marketing-main" tabindex="-1">{body}</main>{_footer()}{scenario_data}</body></html>'''


def _page_hero(title, intro, actions=''):
    return f'<section class="mk-page-hero"><div class="mk-container"><h1>{_e(title)}</h1><p class="mk-lead">{_e(intro)}</p>{actions}</div></section>'


def _final(title='Find the gap. Improve the message. Learn what changes.'):
    return f'''<section class="mk-section mk-final"><div class="mk-container"><h2>{_e(title)}</h2><p>Discuss a focused pilot that connects a team communication concern with practical manager coaching.</p>{_button('Request a team pilot', '/request-pilot', True)}<p class="mk-note">Scope, access, timing and commercial terms are agreed after the conversation. This local preview does not send enquiries.</p></div></section>'''


def _fallback(mode):
    original = f'<p class="mk-message-label">Original request · fictional Atlas example</p><blockquote class="mk-message-example">{_e(SCENARIO["originalMessage"])}</blockquote>'
    completed = f'<h3>After manager confirmation</h3><blockquote class="mk-message-example">{_e(SCENARIO["completedBrief"])}</blockquote><p class="mk-note">Authored illustration, not live model output. Every added fact belongs to this fictional scenario.</p>'
    if mode == 'coach':
        content = original + completed
    else:
        perspectives = []
        for perspective in SCENARIO['perspectives'].values():
            fields = ''.join(f'<div><dt>{_e(label)} <span>Assumed</span></dt><dd>{_e(perspective[key])}</dd></div>' for key, label in DETAIL_LABELS.items())
            perspectives.append(f'<section><h3>{_e(perspective["label"])}</h3><dl class="mk-message-facts">{fields}</dl></section>')
        content = original + '<p class="mk-note">Possible interpretations — fictional. These are authored assumptions, not detected beliefs.</p><div class="mk-grid">' + ''.join(perspectives) + '</div>'
        if mode == 'full':
            content += completed + _disclosure('Proposed evaluation approach. No measured results or automated tracking are shown.', True)
    return f'<div class="explorer-fallback">{content}<noscript><p class="mk-disclosure">Interactive controls are unavailable because JavaScript is disabled. The fictional request, assumptions and authored example remain readable here.</p></noscript></div>'


def _explorer(mode):
    return f'<div class="explorer-mount" data-explorer-view="{mode}">{_fallback(mode)}</div>'


def _diagnostic_scenario():
    d = SCENARIO['diagnostic']
    return f'''<div class="mk-callout"><p class="mk-message-label">Fictional survey scenario · not actual Team Diagnostic output</p><h3>Atlas team</h3><p>{d['responses']} fictional responses</p><p class="mk-quote">“{_e(d['question'])}”</p><div class="mk-report-stat"><strong>{d['average']:.1f} <span>out of 5</span></strong><meter min="1" max="5" value="{d['average']}" aria-label="Authored fictional response average: {d['average']} out of 5">{d['average']} out of 5</meter><p class="mk-meta">Example response average · scale 1–5. Not a benchmark or customer result.</p></div></div>
    <div class="mk-fact-grid"><section><h3>Manager observation</h3><p>{_e(d['observation'])}</p></section><section><h3>Working hypothesis</h3><p>{_e(d['hypothesis'])}</p></section><section><h3>Another explanation to consider</h3><p>{_e(d['alternative'])}</p></section></div>'''


def _workflow():
    return '''<ol class="mk-workflow"><li><h3>Team signal</h3><p>Notice a pattern worth discussing.</p></li><li><h3>Human discussion</h3><p>Test the explanation with the people doing the work.</p></li><li><h3>Manager draft</h3><p>Manager chooses a coaching focus and reviews a relevant message.</p></li></ol>'''


def _home():
    hero_example = f'''<figure class="mk-hero-example"><figcaption class="mk-message-label">Illustrative example · fictional Atlas team</figcaption><blockquote>{_e(SCENARIO['originalMessage'])}</blockquote><div class="mk-summary-row"><div><h3>The manager imagines</h3><p>A detailed report, ready Friday.</p><span class="mk-meta">Assumed</span></div><div><h3>The team member imagines</h3><p>A one-page summary, ready today.</p><span class="mk-meta">Assumed</span></div></div><p class="mk-note">The request is shared. The expectations are not yet explicit.</p></figure>'''
    return f'''<section class="mk-hero-section"><div class="mk-container mk-hero"><div class="mk-hero-copy"><h1>Your team isn't always on the same page. Let's find out why.</h1><p class="mk-lead">Find where communication may be breaking down. Help managers turn those insights into clearer instructions and more actionable feedback.</p>{_actions()}<p class="mk-note">A connected approach: Team Diagnostic → Message Coach. Improvement tracking is a future ambition.</p><p class="mk-disclosure">Current documentation describes a <a href="/research#product-status">prototype</a>. Public examples use fictional data.</p></div>{hero_example}</div></section>
    <section class="mk-section mk-section-rule" id="expectation-gap"><div class="mk-container"><div class="mk-section-heading"><h2>One request. Different expectations.</h2><p>A message can feel clear to the sender and still leave others guessing. Explore what happens when the outcome, timing and context stay unstated.</p></div>{_explorer('perspectives')}<p class="mk-transition">One unclear message is a moment. A repeated pattern is something to investigate.</p></div></section>
    <section class="mk-section mk-section-soft" id="team-diagnostic"><div class="mk-container"><div class="mk-section-heading"><h2>Start with what the team is experiencing.</h2><p>Team Diagnostic explores survey patterns and supports a structured manager discussion. Use those signals to ask better questions and decide where attention may be needed.</p></div>{_diagnostic_scenario()}{_disclosure('A low survey score does not establish the cause. In this fictional example, the manager discusses the pattern with the team before choosing a communication intervention.')}<p class="mk-transition">When unclear expectations are part of the problem, the next step is a message someone can act on.</p></div></section>
    <section class="mk-section" id="message-coach"><div class="mk-container"><div class="mk-section-heading"><h2>Turn the insight into a clearer instruction.</h2><p>Message Coach is designed to assess managerial drafts against defined criteria. The manager supplies missing facts, reviews the feedback and decides what to send.</p></div>{_explorer('coach')}{_disclosure('Deterministic demonstration using authored scenario facts. Not live AI feedback. The public example does not call the model service.')}<p class="mk-note">Clarify the deliverable. Make the deadline explicit. Explain the purpose. Agree a check-in. These are demonstration prompts, not a transcription of the live judging rubric.</p></div></section>
    <section class="mk-section mk-section-rule"><div class="mk-container"><div class="mk-section-heading"><h2>Diagnosis gives coaching a reason to happen.</h2><p>Team insight identifies a concern. A conversation tests the explanation. Message coaching helps the manager change a relevant behavior.</p></div>{_workflow()}{_disclosure('Conceptual workflow. The handoff is manual; automatic cross-tool transfer is not implemented.')}<a class="mk-inline-link" href="/how-it-works">See how the approach fits together</a></div></section>
    <section class="mk-section mk-section-soft"><div class="mk-container"><div class="mk-section-heading"><h2>Then ask whether the change helped.</h2><p>A pilot could compare message clarity, recipient understanding and clarification requests over time. These are evaluation goals, not established CommsAlign results.</p></div><ul class="mk-questions"><li>Are expectations clearer?</li><li>Do recipients need less clarification?</li><li>Is the coaching effort worthwhile?</li></ul>{_disclosure('Future measurement concept — no live tracking dashboard.', True)}</div></section>
    <section class="mk-section"><div class="mk-container mk-split"><div class="mk-section-heading"><h2>A better sentence is useful. A clearer management practice goes further.</h2></div><div><p>CommsAlign's intended distinction is a structured managerial workflow: understand a team concern, assess a relevant draft and review the missing information before sending.</p><ul class="mk-list"><li>Team context before a writing task.</li><li>Defined criteria instead of a blank prompt.</li><li>Manager confirmation of facts and next steps.</li></ul><a class="mk-inline-link" href="/research">Understand the approach and its limits</a></div></div></section>
    <section class="mk-section mk-section-rule"><div class="mk-container"><div class="mk-section-heading"><h2>Less guessing. Clearer expectations. More useful conversations.</h2><p>These are the outcomes a focused pilot should test. Begin with a narrow use case—task instructions or progress feedback—and learn whether the approach helps your team.</p></div></div></section>{_final()}'''


def _how_it_works():
    stages = [
        ('See the signal.', 'Team Diagnostic explores team-level survey patterns. Current prototype inputs are synthetic; the patterns are provisional. In the Atlas illustration, a low response average starts an investigation rather than supplying its explanation.'),
        ('Discuss the explanation.', 'Separate what the manager hears from what the manager infers. Ask the team whether unclear expectations contribute to the concern, while considering workload and competing priorities as alternatives.'),
        ('Coach the draft.', 'A manager chooses a relevant instruction or feedback draft. The application can assess it and offer a revision when its model service is configured and the user consents. The public Explorer instead uses authored scenario facts, with each added detail confirmed by the visitor.'),
        ('Evaluate the change — proposed.', 'Agree what clearer communication would look like. Consider recipient understanding, clarification requests, rework definitions and the manager’s time. There is no automated measurement dashboard in this example.'),
    ]
    return _page_hero('From team concern to a message someone can act on.', 'Start with a pattern. Investigate it with the team. Help the manager change the relevant communication behavior.', _button('Explore the example', '/demo', True)) + f'''<section class="mk-section"><div class="mk-container"><ol class="mk-long-workflow">{''.join(f'<li><h2>{_e(title)}</h2><p>{_e(copy)}</p></li>' for title, copy in stages)}</ol>{_disclosure('Simulated manual handoff. The manager chooses the coaching focus; automatic cross-tool transfer is not implemented.')}</div></section><section class="mk-section mk-section-soft"><div class="mk-container"><div class="mk-section-heading"><h2>What exists, and what is proposed.</h2><p>The documented prototype and a public website demonstration serve different purposes.</p></div><div class="mk-split"><section><h3>Current prototype work</h3><ul class="mk-list"><li>Synthetic team analysis, human discussion records and summaries.</li><li>Conditional draft assessment, suggested revisions and re-scoring in the current v2 source.</li><li>Explicit submission consent and small-response reporting rules.</li></ul></section><section><h3>Proposed next steps</h3><ul class="mk-list"><li>Automated transfer between the two tools.</li><li>Longitudinal evaluation and follow-up tracking.</li><li>Broader real-world pilot evidence and production availability.</li></ul></section></div><p class="mk-note">Code support is not evidence of an operational live model connection, production readiness or measured business impact.</p><a class="mk-inline-link" href="/research#product-status">Read the full product status</a></div></section>{_final('Start with one concern, not a broad rollout.')}'''


def _demo():
    return _page_hero('One request. Different expectations.', 'Explore a fictional expectation gap, investigate the team context, then make the missing details explicit.') + f'''<section class="mk-section mk-demo-section"><div class="mk-container">{_disclosure('Interactive fictional example. No live AI, real survey analysis or employee data is used here.')}{_explorer('full')}</div></section>'''


def _solutions():
    audiences = [
        ('People and HR leaders', 'Your survey highlights a concern. Managers need a useful next step.', 'Explore an expectations concern, discuss context with the team and coach a relevant task instruction.', 'What would managers and employees need to see for this to be a useful next step after a survey?'),
        ('Managers and team leads', 'You have explained the task. Does the message contain enough to act?', 'Assess an instruction or progress-feedback draft, confirm missing facts and decide what to send.', 'Can the recipient identify the expected result, timing, context and next step?'),
        ('Operations leaders', 'Repeated clarification can make execution harder to coordinate.', 'Examine one workflow with repeated handoffs and define what clearer communication would mean.', 'Which kinds of clarification or rework should a focused pilot examine, and how will they be recorded?'),
    ]
    sections = ''.join(f'''<section class="mk-audience"><div><h2>{_e(name)}</h2><p class="mk-lead">{_e(situation)}</p></div><div><h3>A proposed pilot focus</h3><p>{_e(focus)}</p><h3>A question worth testing</h3><p>{_e(question)}</p>{_button('Discuss a team pilot', '/request-pilot', quiet=True)}</div></section>''' for name, situation, focus, question in audiences)
    return _page_hero('A practical starting point for clearer management communication.', 'Choose a narrow concern, connect it to an everyday behavior and agree what a pilot should test.') + f'''<section class="mk-section"><div class="mk-container">{_disclosure('Proposed pilot examples, not customer case studies or verified outcomes.')}{sections}<aside class="mk-callout"><h2>Keep the first question focused.</h2><p>Task expectations and progress feedback are the starting use cases. Recognition and employee-voice coaching are possible future research directions, not advertised current coaching solutions.</p></aside></div></section>{_final('Give one team a useful next question.')}'''


def _status_table():
    rows = ''.join(f'''<tr><th scope="row">{_e(item['title'])}</th><td><span class="mk-status-label">{_e(STATUS_LABELS[item['status']])}</span></td><td><p>{_e(item['summary'])}</p><p class="mk-note">{_e(item['disclosure'])}</p><span class="mk-meta">Sources: {_e(', '.join(item['sourceIds']))}</span></td></tr>''' for item in CAPABILITIES)
    return f'<div class="mk-table-wrap"><table class="mk-status-table"><thead><tr><th scope="col">Capability</th><th scope="col">Status</th><th scope="col">What that means</th></tr></thead><tbody>{rows}</tbody></table></div>'


def _research():
    ledger = ''.join(f'''<li id="source-{_e(source['id'].lower())}"><h3>{_e(source['id'])} · {f'<a href="{_e(source["url"])}">{_e(source["title"])}</a>' if source['url'] else _e(source['title'])}</h3><p>{_e(source['note'])}</p></li>''' for source in SOURCE_LEDGER)
    return _page_hero('Understand the approach. See its limits.', 'A useful communication tool should make its assumptions and evidence visible.') + f'''<section class="mk-section"><div class="mk-container"><div class="mk-section-heading"><h2>The mechanism is a sequence of judgments.</h2><p>Team patterns inform a human discussion. The manager decides whether a draft is a useful place to intervene. A message review does not explain the team’s survey results.</p><p class="mk-note">The connected journey is conceptual and manual. The manager chooses a coaching focus after discussion; automatic transfer between the tools is not implemented.</p></div>{_workflow()}</div></section>
    <section class="mk-section mk-section-soft"><div class="mk-container mk-split"><section><h2>Rubrics and evidence</h2><p>Task instructions and performance feedback need different kinds of context. The product materials discuss outcome clarity, timing, rationale, support and progress review. These are high-level examples, not a new validated scoring instrument.</p><p>Message Coach’s imported judging implementation is separate from the older rule-based CLI. Exact labels and scores should be read with the active rubric and their supporting evidence. A change in a rubric rating is not proof of business impact.</p><p class="mk-note">The public Explorer’s four confirmation prompts are authored demonstration controls. They are not a transcription of the imported judge rubric or live AI output. No public research-corpus or RAG capability is asserted.</p></section><section><h2>Survey interpretation</h2><p>Survey patterns are not causal explanations. The same result can be consistent with unclear expectations, workload, competing priorities or other conditions. A discussion with the team is essential.</p><h3>Privacy has limits.</h3><p>Small-response suppression is documented. It does not establish anonymity, legal compliance, consent coverage or safe production processing. The application can clear saved notes when a team becomes suppressed; this is not a promise that hidden information is preserved.</p></section></div></section>
    <section class="mk-section" id="product-status"><div class="mk-container"><div class="mk-section-heading"><h2>Product status</h2><p>A documented prototype, a local website demonstration and a production service are different things. No production deployment or generally available subscription is established here.</p></div>{_status_table()}<div class="mk-callout"><h3>A note on changing documentation</h3><p>The supplied website brief relied on earlier documents that described rewriting as unimplemented. The current v2 source includes conditional suggested revisions and re-scoring. This website corrects that narrow source-status point while keeping authored public examples separate from model operation. No live model request was made to validate that connection.</p><p>The deck describes Team Diagnostic as proposed; repository documents describe limited synthetic-data prototype work. Neither is proof of production availability.</p></div></div></section>
    <section class="mk-section mk-section-soft"><div class="mk-container"><div class="mk-section-heading"><h2>An evaluation agenda, not an impact claim.</h2><p>Independently assess message clarity and recipient understanding. Define clarification requests and rework consistently. Include manager time costs and the possibility that other factors explain a change.</p></div><ul class="mk-list">{''.join(f'<li>{_e(item)}</li>' for item in SCENARIO['evaluation'])}</ul>{_disclosure('Proposed evaluation approach. No measured results or automated tracking are shown.', True)}<p>A before/after observation can inform a pilot, but cannot on its own establish that CommsAlign caused a change. External workplace statistics and a better rubric score are not substitutes for product evidence.</p></div></section>
    <section class="mk-section"><div class="mk-container"><div class="mk-section-heading"><h2>Source ledger</h2><p>Review context: 7 November 2026. Repository documentation informed the supplied brief; current local v2 source was checked for the specific capability correction above. Mutable links should be rechecked before public launch.</p></div><ol class="mk-source-list">{ledger}</ol><p class="mk-note">The supplied implementation brief informed the narrative. Its fictional scenario and proposed workflow are not independent evidence. No customer outcomes, numerical ROI, security certifications or commercial prices were established.</p>{_button('Explore the example', '/demo', True)}</div></section>'''


def _pricing():
    faq = [
        ('Can I subscribe online?', 'Self-service subscriptions are not offered on this website.'),
        ('What does a pilot cost?', 'Pricing and scope are discussed with the project owner. No public plan prices have been confirmed.'),
        ('Does a request guarantee access?', 'No. A request starts a conversation about fit and availability.'),
        ('Will this preview send my request?', 'No. The current form validates a fictional preview locally. Nothing is sent or saved as a lead.'),
    ]
    return _page_hero('Start with a focused team pilot.', 'Discuss your use case, the team involved and what you want to learn. Pilot scope, availability and commercial terms are agreed individually.', _button('Request a team pilot', '/request-pilot', True)) + f'''<section class="mk-section"><div class="mk-container mk-split"><div><h2>Define what is worth learning.</h2><p>A pilot conversation begins with the work, rather than a subscription tier. Keep the use case narrow enough to evaluate responsibly.</p></div><ul class="mk-list"><li>The communication use case and intended participants.</li><li>The manager workflow and time involved.</li><li>Responsible handling of any real information.</li><li>An agreed evaluation approach.</li><li>Access, support and availability requirements.</li></ul></div></section><section class="mk-section mk-section-soft"><div class="mk-container"><h2>Questions before a pilot</h2><div class="mk-faq">{''.join(f'<details><summary>{_e(question)}</summary><p>{_e(answer)}</p></details>' for question, answer in faq)}</div></div></section>{_final('Start a conversation about fit.')}'''


def _field(name, label, required=False, maxlength=None, type_='text', help_text='', autocomplete=None):
    attrs = f' type="{type_}" id="pilot-{name}" name="{name}"'
    if required:
        attrs += ' required'
    if maxlength:
        attrs += f' maxlength="{maxlength}"'
    if autocomplete:
        attrs += f' autocomplete="{autocomplete}"'
    attrs += f' aria-describedby="pilot-error-{name}' + (f' pilot-help-{name}' if help_text else '') + '"'
    return f'''<div class="mk-field"><label for="pilot-{name}">{_e(label)}{' <span>(required)</span>' if required else ' <span>(optional)</span>'}</label><input{attrs}><p id="pilot-error-{name}" class="mk-error" hidden></p>{f'<p id="pilot-help-{name}" class="mk-field-help">{_e(help_text)}</p>' if help_text else ''}</div>'''


def _request_pilot():
    return _page_hero("Let's discuss one team and one communication challenge.", 'Tell us where expectations or feedback are getting lost, and what a useful pilot would help you learn.') + f'''<section class="mk-section"><div class="mk-container mk-split"><div><div class="mk-callout"><h2>Preview form — requests are not being sent.</h2><p>You can try the enquiry form below. It checks your entries locally without sending or saving a request.</p></div><p class="mk-note">A public enquiry service needs an approved destination, privacy notice and operating process. Those are not configured in this preview.</p><noscript><p class="mk-disclosure">The preview form requires JavaScript for local validation. Submission is unavailable; no enquiry can be sent from this page.</p></noscript></div><form class="mk-form" id="pilot-form" novalidate method="post" action="/request-pilot" data-pilot-preview><div class="mk-form-errors" id="pilot-errors" tabindex="-1" role="alert" hidden></div><div class="mk-field-grid">{_field('name','Name',True,100,autocomplete='name')}{_field('email','Work email',True,254,type_='email',autocomplete='email')}</div>{_field('organization','Organization',True,150,autocomplete='organization')}<div class="mk-field-grid">{_field('role','Role',False,100,autocomplete='organization-title')}<div class="mk-field"><label for="pilot-team_size">Team size <span>(optional)</span></label><select id="pilot-team_size" name="team_size" aria-describedby="pilot-error-team_size"><option value="">Select if known</option><option value="1–10">1–10</option><option value="11–50">11–50</option><option value="51–200">51–200</option><option value="201+">201+</option><option value="Unsure">Unsure</option></select><p id="pilot-error-team_size" class="mk-error" hidden></p></div></div><div class="mk-field"><label for="pilot-challenge">Communication challenge <span>(optional)</span></label><textarea id="pilot-challenge" name="challenge" maxlength="1500" rows="5" aria-describedby="pilot-help-challenge pilot-error-challenge"></textarea><p id="pilot-error-challenge" class="mk-error" hidden></p><p id="pilot-help-challenge" class="mk-field-help">Please describe the situation generally. Do not include identifiable employee information or confidential message content. Maximum 1,500 characters.</p></div><button class="mk-button mk-button-primary" type="submit" data-pilot-submit disabled>Preview request</button><p class="mk-field-help">Preview only. Nothing is sent or saved. There is no automatic email enrolment.</p><div class="mk-form-result" id="pilot-result" role="status" tabindex="-1" hidden></div></form></div></section>'''


_RENDERERS = {
    '/': _home,
    '/how-it-works': _how_it_works,
    '/demo': _demo,
    '/solutions': _solutions,
    '/research': _research,
    '/pricing': _pricing,
    '/request-pilot': _request_pilot,
}


def render_marketing(path: str) -> str:
    """Return a complete server-rendered public page for a canonical route."""
    path = path.rstrip('/') or '/'
    if path not in _RENDERERS:
        return render_not_found(path)
    return _shell(path, _RENDERERS[path]())


def render_not_found(path: str) -> str:
    """Render a useful escaped 404 without inventing a destination."""
    body = _page_hero('That page is not here.', 'You can return to the product story, explore the fictional example or open the existing workspace.')
    body += f'<section class="mk-section"><div class="mk-container"><p class="mk-note">Requested path: <code>{_e(path[:300])}</code></p><div class="mk-actions">{_button("Go to CommsAlign", "/", True)}{_button("Explore the example", "/demo")}{_button("Open workspace", "/workspace", quiet=True)}</div></div></section>'
    return _shell('/404', body, {'title': 'Page not found — CommsAlign', 'description': 'Find the CommsAlign product story, fictional example or existing communication workspace.'})
