"""Local web API around the existing CommsAlign analysis and review engines.

The custom browser interface is deliberately stateless on the server. Diagnostic
data is synthetic; message text is processed only by explicit review requests.
"""
from __future__ import annotations

import asyncio
from dataclasses import asdict
import json
from pathlib import Path
from urllib.parse import urlsplit

from starlette.applications import Starlette
from starlette.concurrency import run_in_threadpool
from starlette.exceptions import HTTPException
from starlette.requests import Request
from starlette.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response
from starlette.routing import Route

from app.organizational.analyzer import analyze_csv
from app.organizational.evidence_validation import load_evidence_validation_matrix
from app.organizational.report import (
    ITEM_TOPICS, conversation_priorities, item_tie_notice, render_report,
)
from app.organizational.workflow import DECISIONS, OUTCOMES, discussion_summary, selected_signal
from app.tool1.rubrics import RUBRICS

PROJECT_ROOT = Path(__file__).resolve().parents[1]
WEB_ROOT = PROJECT_ROOT / "web"
SAMPLE_PATH = PROJECT_ROOT / "data/organizational/sample_q12_results.csv"
MAX_JSON_BYTES = 100_000
MAX_DRAFT_CHARACTERS = 20_000
MAX_MINIMUM_RESPONSES = 1_000_000
SYNTHETIC_LABEL = "Synthetic demonstration data — not real Gallup results."
NEXT_STEPS = (
    "Review the identified signals.",
    "Discuss the findings with the team.",
    "Ask the suggested questions to understand what is behind the survey results.",
    "Document what the team says.",
    "Decide whether additional evidence or action is needed.",
)
ITEM_LABELS = {
    "Q01": "Expectations & Direction", "Q02": "Information & Resources",
    "Q03": "Use of Strengths", "Q04": "Recognition", "Q05": "Care & Support",
    "Q06": "Development Support", "Q07": "Employee Voice",
    "Q08": "Purpose Connection", "Q09": "Quality & Team Standards",
    "Q10": "Close Workplace Relationships", "Q11": "Progress Feedback",
    "Q12": "Learning & Growth",
}
MODEL_REQUEST_LOCK = asyncio.Lock()


def error(message: str, status: int = 400) -> JSONResponse:
    return JSONResponse({"error": message}, status_code=status)


def minimum_responses(request: Request) -> int:
    raw = request.query_params.get("minimum_responses", "5")
    if len(raw) > 12 or not raw.isascii() or not raw.isdecimal():
        raise HTTPException(400, "Minimum responses must be a positive whole number.")
    threshold = int(raw)
    if not 1 <= threshold <= MAX_MINIMUM_RESPONSES:
        raise HTTPException(400, "Minimum responses must be between 1 and 1,000,000.")
    return threshold


def _join_topics(topics) -> str:
    return ", ".join(topics[:-1]) + " and " + topics[-1] if len(topics) > 1 else "".join(topics)


def executive_narrative(report) -> str:
    """Summarize existing relative rankings without deriving new judgments."""
    if set(report.hierarchy_strengths) == set(report.hierarchy_opportunities):
        hierarchy = ("Available hierarchy areas are tied; the results do not distinguish "
                     "a strongest area from an area for investigation.")
    else:
        verb = "is the primary hierarchy area" if len(report.hierarchy_opportunities) == 1 else "are tied hierarchy areas"
        hierarchy = (
            f"This team shows relatively stronger signals in {_join_topics(report.hierarchy_strengths)}, "
            f"while {_join_topics(report.hierarchy_opportunities)} {verb} for investigation."
        )
    topics = tuple(dict.fromkeys(
        "clarity of expectations" if signal.signal_name == "expectations_and_direction"
        else signal.signal_name.replace("_", " ")
        for signal in report.communication_signals
    ))
    communication = (
        f"Communication-related signals suggest exploring {_join_topics(topics)}."
        if topics else "No mapped communication signals were selected for exploration."
    )
    return f"{hierarchy} {communication}"


def diagnostic_download(report) -> str:
    """Export the existing diagnostic, its discussion steps, and limitations."""
    if report.suppressed:
        raise ValueError("A suppressed diagnostic cannot be exported.")
    text = render_report(report).replace(
        "Hierarchy summaries:", executive_narrative(report) + "\n\nHierarchy scores:", 1,
    )
    next_section = "\n".join([
        "6. What to Do Next", "Suggested discussion steps, not prescriptions.",
        *(f"{number}. {step}" for number, step in enumerate(NEXT_STEPS, 1)),
        "Validate the hypotheses with employees before taking action.", "", "7. Limitations",
    ])
    text = text.replace("6. Limitations", next_section, 1)
    return "\n".join([
        SYNTHETIC_LABEL,
        "Survey results are signals and hypotheses only. They do not establish causes.",
        "No causal inference is performed.", "", text,
        "- Missing items are not imputed; available-item summaries may not be comparable to complete summaries.",
    ])


def diagnostic_payload(report) -> dict:
    if report.suppressed:
        # Whitelist rather than serialize-and-delete: future report fields must
        # never accidentally expose a suppressed group's diagnostics or exports.
        return {
            "team_id": report.team_id,
            "period": report.period,
            "suppressed": True,
            "minimum_responses": report.minimum_responses,
            "limitations": list(report.limitations),
            "synthetic": True,
        }
    payload = report.to_dict()
    payload.update(
        synthetic=True,
        priorities=list(conversation_priorities(report)),
        executive_narrative=executive_narrative(report),
        download_text=diagnostic_download(report),
        item_labels=ITEM_LABELS,
        item_topics=ITEM_TOPICS,
        evidence=[asdict(row) for row in load_evidence_validation_matrix().validations],
        tie_notice=item_tie_notice(report),
        next_steps=list(NEXT_STEPS),
    )
    return payload


async def teams(request: Request) -> Response:
    threshold = minimum_responses(request)
    try:
        reports = await run_in_threadpool(analyze_csv, SAMPLE_PATH, minimum_responses=threshold)
    except (ValueError, OSError):
        return error("The synthetic team dataset could not be loaded. Check the local data files and try again.", 503)
    return JSONResponse({
        "teams": [
            {"team_id": report.team_id, "period": report.period, "suppressed": report.suppressed}
            for report in reports
        ],
        "minimum_responses": threshold,
    })


async def diagnostic(request: Request) -> Response:
    threshold = minimum_responses(request)
    team_id = request.query_params.get("team_id")
    period = request.query_params.get("period")
    try:
        reports = await run_in_threadpool(analyze_csv, SAMPLE_PATH, minimum_responses=threshold)
        matches = [report for report in reports if team_id is None or report.team_id == team_id]
        if period is not None:
            matches = [report for report in matches if (report.period or "") == period]
        if not matches:
            return error("That team or reporting period is unavailable. Choose a team from the list.", 404)
        payload = await run_in_threadpool(diagnostic_payload, matches[0])
    except (ValueError, OSError):
        return error("The diagnostic could not be loaded. Check the local data files and try again.", 503)
    return JSONResponse(payload)


async def read_json(request: Request) -> dict:
    content_type = request.headers.get("content-type", "").split(";", 1)[0].strip().lower()
    if content_type != "application/json":
        raise HTTPException(415, "Send this request as JSON.")
    content_length = request.headers.get("content-length")
    if content_length is not None:
        try:
            declared_length = int(content_length)
        except ValueError:
            raise HTTPException(400, "The request length is invalid.") from None
        if declared_length < 0:
            raise HTTPException(400, "The request length is invalid.")
        if declared_length > MAX_JSON_BYTES:
            raise HTTPException(413, "The request is too large. Shorten your draft and try again.")
    body = bytearray()
    async for chunk in request.stream():
        if len(body) + len(chunk) > MAX_JSON_BYTES:
            raise HTTPException(413, "The request is too large. Shorten your draft and try again.")
        body.extend(chunk)
    try:
        def reject_constant(value):
            raise ValueError(value)
        data = json.loads(body, parse_constant=reject_constant)
    except (ValueError, UnicodeDecodeError):
        raise HTTPException(400, "The request is not valid JSON.") from None
    if not isinstance(data, dict):
        raise HTTPException(400, "The request must contain a JSON object.")
    return data


async def read_message_input(request: Request) -> dict:
    data = await read_json(request)
    if data.get("consent") is not True:
        raise HTTPException(400, "Confirm that you agree to send this draft to the configured GW Azure model before evaluating.")
    if not isinstance(data.get("draft"), str) or not data["draft"].strip():
        raise HTTPException(400, "Enter a draft message to evaluate.")
    if len(data["draft"]) > MAX_DRAFT_CHARACTERS:
        raise HTTPException(413, "Your draft is too long. Use 20,000 characters or fewer.")
    if not isinstance(data.get("kind"), str) or data["kind"] not in RUBRICS:
        raise HTTPException(400, "Choose Task instruction or Performance feedback as the message type.")
    return data


def perform_message_request(data: dict, *, rescore_only: bool) -> dict:
    # Keep settings/model dependencies behind validated, explicit consent. Never
    # send messages, return credentials, or substitute a demonstration result.
    from app.tool1.config import load_settings
    try:
        load_settings()
    except RuntimeError:
        raise HTTPException(503, "GW Azure settings are missing. Add your GW-provided settings to the local .env file, then try again. Never paste API keys into the app or commit them to GitHub.") from None
    from app.tool1.pipeline import rescore, run
    if rescore_only:
        return asdict(rescore(data["draft"], data["kind"]))
    result = run(data["draft"], data["kind"])
    return {
        "draft": data["draft"], "kind": data["kind"],
        "result": asdict(result.before),
        "rewrite": asdict(result.rewrite) if result.rewrite is not None else None,
        "after": asdict(result.after) if result.after is not None else None,
    }


async def message_request(request: Request, *, rescore_only: bool = False) -> Response:
    data = await read_message_input(request)
    if MODEL_REQUEST_LOCK.locked():
        return error("Another message review is still running. Wait for it to finish, then try again.", 429)
    async with MODEL_REQUEST_LOCK:
        try:
            payload = await run_in_threadpool(perform_message_request, data, rescore_only=rescore_only)
        except HTTPException:
            raise
        except ImportError:
            return error("The model connection dependencies are unavailable. Install requirements-web.txt and requirements-tool1.txt, then restart the local server.", 503)
        except Exception:
            # Upstream exceptions can contain connection details. Keep the
            # recovery instruction useful without serializing an exception.
            return error("Evaluation could not be completed. Check the GW connection settings and model access, then retry. No result has been substituted.", 502)
    return JSONResponse(payload)


async def review(request: Request) -> Response:
    return await message_request(request)


async def rescore(request: Request) -> Response:
    return await message_request(request, rescore_only=True)


async def discussion_export(request: Request) -> Response:
    data = await read_json(request)
    team_id, period, item = data.get("team_id"), data.get("period"), data.get("item")
    threshold = data.get("minimum_responses", 5)
    if not isinstance(team_id, str) or not team_id.strip() or len(team_id) > 256:
        return error("Choose an available team before downloading a discussion summary.")
    if period is not None and (not isinstance(period, str) or len(period) > 256):
        return error("Choose a valid reporting period.")
    if type(threshold) is not int or not 1 <= threshold <= MAX_MINIMUM_RESPONSES:
        return error("Minimum responses must be a whole number between 1 and 1,000,000.")
    if not isinstance(item, str) or len(item) > 16:
        return error("Choose an available communication signal.")
    submitted_notes = data.get("notes", {})
    if not isinstance(submitted_notes, dict):
        return error("Discussion notes must be an object containing text fields.")
    notes = {
        "observations": "", "outcome": OUTCOMES[0], "reflection": "",
        "decision": DECISIONS[0], "action": "", "owner": "", "follow_up": "",
    }
    if set(submitted_notes) - set(notes):
        return error("Discussion notes contain an unsupported field.")
    for key, value in submitted_notes.items():
        if not isinstance(value, str):
            return error("Each discussion note must contain text.")
        if len(value) > 5_000:
            return error("Each discussion note must be 5,000 characters or fewer.", 413)
        notes[key] = value
    if notes["outcome"] not in OUTCOMES or notes["decision"] not in DECISIONS:
        return error("Choose a listed observation outcome and next-step decision.")
    try:
        reports = await run_in_threadpool(analyze_csv, SAMPLE_PATH, minimum_responses=threshold)
        matches = [report for report in reports if report.team_id == team_id]
        if period is not None:
            matches = [report for report in matches if (report.period or "") == period]
        if not matches:
            return error("That team or reporting period is unavailable.", 404)
        report = matches[0]
        if report.suppressed:
            return error("This team’s results are suppressed by the reporting threshold. Discussion summaries are unavailable.", 403)
        try:
            selected_signal(report, item)
        except ValueError:
            return error("Choose an available communication signal.")
        matrix = await run_in_threadpool(load_evidence_validation_matrix)
        text = discussion_summary(report, item, matrix.get_by_source_item(item), notes)
    except (ValueError, OSError):
        return error("The discussion summary could not be prepared. Check the local data files and try again.", 503)
    return JSONResponse({"text": text})


async def health(request: Request) -> Response:
    return JSONResponse({"status": "ok", "app": "CommsAlign", "local": True})


async def frontend(request: Request) -> Response:
    path = request.path_params.get("path", "")
    from app.marketing_site import MARKETING_ROUTES, render_marketing, render_not_found
    public_path = "/" + path
    if public_path in MARKETING_ROUTES:
        return HTMLResponse(render_marketing(public_path), headers={"Cache-Control": "no-cache"})
    if path == "robots.txt":
        return Response("User-agent: *\nDisallow: /\n", media_type="text/plain")
    if path == "sitemap.xml":
        # This preview uses its actual loopback origin, never an invented public domain.
        from html import escape
        origin = str(request.base_url).rstrip("/")
        entries = "".join(f"<url><loc>{escape(origin + route)}</loc></url>" for route in MARKETING_ROUTES)
        return Response(f'<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">{entries}</urlset>', media_type="application/xml")
    if path in ("message-coach", "team-diagnostic"):
        return RedirectResponse("/workspace/" + path, status_code=307)
    if path in ("workspace", "workspace/", "workspace/message-coach", "workspace/team-diagnostic"):
        target = WEB_ROOT / "index.html"
    else:
        if path.startswith("api/") or any(part.startswith(".") for part in Path(path).parts):
            return error("Page not found.", 404)
        target = (WEB_ROOT / path).resolve()
        if not target.is_relative_to(WEB_ROOT.resolve()) or target.suffix not in {
            ".css", ".js", ".svg", ".png", ".jpg", ".webp", ".ico", ".woff2",
        }:
            return HTMLResponse(render_not_found(public_path), status_code=404)
    if not target.is_file():
        if target.name == "index.html":
            return error("The workspace interface is unavailable. Check the local web files and restart the server.", 503)
        return error("Asset not found.", 404)
    return FileResponse(target, headers={"Cache-Control": "no-cache"})


async def http_error(request: Request, exception: HTTPException) -> Response:
    return error(str(exception.detail), exception.status_code)


class LocalWorkspaceMiddleware:
    """Constrain browser requests to this loopback workspace and its origin."""
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return
        request = Request(scope)
        host = request.headers.get("host", "")
        try:
            parsed = urlsplit("http://" + host)
            # Access .port to reject malformed/out-of-range port values.
            parsed.port
            valid_host = (
                parsed.hostname in {"127.0.0.1", "localhost", "::1"}
                and not parsed.username and not parsed.password
                and not parsed.path and not parsed.query and not parsed.fragment
                and parsed.netloc == host
            )
        except ValueError:
            valid_host = False
        if not valid_host:
            await error("This workspace is available only through its local address.", 403)(scope, receive, send)
            return
        origin = request.headers.get("origin")
        if origin is not None and origin.lower() != f"{scope.get('scheme', 'http')}://{host}".lower():
            await error("Open the local workspace page to use this action.", 403)(scope, receive, send)
            return
        if request.method not in {"GET", "HEAD"} and request.headers.get("sec-fetch-site") not in {None, "same-origin", "none"}:
            await error("Open the local workspace page to use this action.", 403)(scope, receive, send)
            return

        async def secure_send(message):
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))
                headers.extend([
                    (b"x-content-type-options", b"nosniff"),
                    (b"x-frame-options", b"DENY"),
                    (b"referrer-policy", b"same-origin"),
                    (b"x-robots-tag", b"noindex, nofollow"),
                    (b"content-security-policy", b"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"),
                ])
                if request.url.path.startswith("/api/"):
                    headers.append((b"cache-control", b"no-store"))
                message["headers"] = headers
            await send(message)
        await self.app(scope, receive, secure_send)


def create_app() -> Starlette:
    app = Starlette(debug=False, routes=[
        Route("/api/health", health),
        Route("/api/teams", teams),
        Route("/api/diagnostic", diagnostic),
        Route("/api/message/review", review, methods=["POST"]),
        Route("/api/message/rescore", rescore, methods=["POST"]),
        Route("/api/discussion/export", discussion_export, methods=["POST"]),
        Route("/{path:path}", frontend),
    ], exception_handlers={HTTPException: http_error})
    app.add_middleware(LocalWorkspaceMiddleware)
    return app


app = create_app()
