"""Personal-use agent orchestration."""
