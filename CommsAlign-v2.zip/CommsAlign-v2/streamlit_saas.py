"""Separate CommsAlign dashboard preview. The original app is in ../urmom."""
from html import escape
from pathlib import Path

import streamlit as st

from app.organizational.analyzer import analyze_csv
from app.organizational.dashboard import main as team_diagnostic
from app.tool1.dashboard import main as message_coach
from app.ui import apply_shell, footer

SAMPLE_PATH = Path(__file__).resolve().parent / 'data/organizational/sample_q12_results.csv'


def open_tool(name):
    st.switch_page(PAGES[name])


def team_name(team_id):
    return team_id.removeprefix('SYNTHETIC_')


def team_snapshot():
    """Show only bundled demo values under the current reporting rule."""
    try:
        reports = analyze_csv(SAMPLE_PATH, minimum_responses=int(st.session_state.get('ca_minimum_responses', 5)))
    except (ValueError, OSError):
        st.warning('The demo snapshot is unavailable. Open Team Diagnostic to review the data settings.')
        return
    with st.container(key='ca-snapshot'):
        heading, selection = st.columns([1.8, 1], vertical_alignment='center')
        with heading:
            st.subheader('Team snapshot')
            st.caption('A closer look at the synthetic demonstration data.')
        with selection:
            teams = list(dict.fromkeys(report.team_id for report in reports))
            previous = st.session_state.get('ca_report_team', teams[0])
            if st.session_state.get('ca_overview_team') not in teams:
                st.session_state['ca_overview_team'] = previous if previous in teams else teams[0]
            selected = st.selectbox('Demo team', teams, format_func=lambda value: f'{team_name(value)} team',
                                    key='ca_overview_team', label_visibility='collapsed')
            st.session_state['ca_report_team'] = selected
        report = next(report for report in reports if report.team_id == selected)
        if report.suppressed:
            st.info('This team does not meet the selected reporting threshold. Scores and signals are hidden. Open Team Diagnostic to review your settings.')
            st.button('Open reporting settings', on_click=open_tool, args=('team',), key='open-suppressed-report')
            return
        profile, discussion = st.columns([1.5, 1], gap='large')
        with profile:
            st.markdown('<div class="ca-detail-row"><strong>Hierarchy profile</strong><span>Mean score · 1–5</span></div>', unsafe_allow_html=True)
            rows = []
            for area, score in report.hierarchy_scores.items():
                if score is None:
                    rows.append(f'<div class="ca-profile-row"><span>{escape(area)}</span><span>Unavailable</span></div>')
                    continue
                width = max(0, min(100, (score - 1) / 4 * 100))
                rows.append(
                    f'<div class="ca-profile-row"><div class="ca-profile-name"><span>{escape(area)}</span>'
                    f'<span class="ca-profile-score">{score:.2f}</span></div>'
                    f'<div class="ca-profile-track" role="meter" aria-label="{escape(area)}" '
                    f'aria-valuemin="1" aria-valuemax="5" aria-valuenow="{score:.2f}">'
                    f'<div class="ca-profile-fill" style="width:{width:.2f}%"></div></div></div>'
                )
            st.markdown('<div class="ca-profile">' + ''.join(rows) + '</div>', unsafe_allow_html=True)
            st.caption('Bars run from 1 to 5. These are fictional team scores, not benchmarks.')
        with discussion:
            st.markdown('**A starting point for discussion**')
            if report.communication_signals:
                signal = report.communication_signals[0]
                topic = signal.signal_name.replace('_', ' ')
                st.write(f'Explore {topic} with your team. Use the signal as a question, rather than a conclusion.')
                st.caption(signal.manager_questions[0])
            else:
                st.write('Start with the relative patterns in this team’s results, then ask the team what is behind them.')
            st.button('Explore this team', key='open-snapshot-team', on_click=open_tool,
                      args=('team',), icon=':material/arrow_forward:', width='stretch')


def overview():
    st.set_page_config(page_title='CommsAlign — Workspace', layout='wide', initial_sidebar_state='auto')
    apply_shell('Overview')
    st.title('Your communication workspace')
    st.write('Review a message, understand your team’s signals, and make the next conversation count.')
    primary, secondary = st.columns([1.3, 1], gap='medium')
    with primary:
        with st.container(key='ca-task-primary'):
            st.subheader('Find the right words.')
            st.write('Bring a draft to Message Coach for structured feedback, supporting evidence, and a suggested revision.')
            st.markdown('<div class="ca-task-meta">Task instructions · Performance feedback</div>', unsafe_allow_html=True)
            st.button('Review a message', type='primary', key='open-message-coach',
                      on_click=open_tool, args=('coach',), icon=':material/edit_note:', width='stretch')
            st.caption('Live reviews require your GW Azure connection.')
    with secondary:
        with st.container(key='ca-task-secondary'):
            st.subheader('Listen to the bigger picture.')
            st.write('Explore team survey patterns and turn a selected signal into a thoughtful discussion.')
            st.markdown('<div class="ca-task-meta">Team Diagnostic · Synthetic demo</div>', unsafe_allow_html=True)
            st.button('Explore team signals', key='open-team-diagnostic', on_click=open_tool,
                      args=('team',), icon=':material/analytics:', width='stretch')
            st.caption('Ready to explore. No model connection needed.')
    team_snapshot()
    session, context = st.columns([1.3, 1], gap='large')
    with session:
        with st.container(key='ca-start'):
            st.subheader('Your session')
            saved = st.session_state.get('tool1_result')
            notes = st.session_state.get('discussion_drafts', {})
            if saved:
                kind = saved.get('kind', 'message').replace('_', ' ')
                st.write(f'Your latest {kind} review is ready to revisit.')
                st.button('Return to your review', on_click=open_tool, args=('coach',), key='return-to-review')
            elif notes:
                st.write('You have saved discussion notes in this session.')
                st.button('Return to team discussions', on_click=open_tool, args=('team',), key='return-to-notes')
            else:
                st.markdown('<div class="ca-session-empty"><strong>A fresh place to start.</strong><p>No message reviews or saved discussion notes yet. Choose a tool above to begin.</p></div>', unsafe_allow_html=True)
    with context:
        with st.container(key='ca-start-context'):
            st.subheader('A little context')
            st.write('CommsAlign supports reflection. Ratings and survey interpretations are provisional, and team signals do not establish causes.')
            st.caption('The demo uses fictional teams. Nothing is automatically sent to employees or between tools.')
    footer()


PAGES = {
    'overview': st.Page(overview, title='Overview', icon=':material/space_dashboard:', default=True),
    'coach': st.Page(message_coach, title='Message Coach', icon=':material/edit_note:', url_path='message-coach'),
    'team': st.Page(team_diagnostic, title='Team Diagnostic', icon=':material/analytics:', url_path='team-diagnostic'),
}

if __name__ == '__main__':
    st.navigation(list(PAGES.values())).run()
