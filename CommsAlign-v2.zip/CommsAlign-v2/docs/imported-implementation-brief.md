# CommsAlign — SaaS marketing website implementation brief

Version: 1.0 · Prepared 7 November 2026

Deliverable: a responsive marketing website and an interactive, fictional demonstration of the product story. This document specifies a proposed website; it does not certify that the underlying tools are production ready.

## 1. Start here: instructions for the implementing Codex agent

Build a coherent story about organizational communication, rather than two unrelated tool landing pages:

**Recognize the misunderstanding → investigate the team pattern with Tool 2 → confirm a communication gap with people → coach a manager's message with Tool 1 → propose a way to evaluate improvement.**

Tool 2 establishes why an intervention might be needed. Tool 1 is the main practical intervention and commercial focus. Measurement closes the long-term story, but remains an aspiration until implemented and evaluated.

Use this brief as the implementation specification. Preserve the product-status boundaries in section 3 even when a more expansive claim would make the page easier to sell. The website may demonstrate a connected journey; it must not claim that the software already automates that journey.

Implementation sequence:

1. Inspect the target repository, its instructions, current application, dependencies and design assets. Reuse the existing site framework if one exists.
2. Record verified product facts separately from website design choices. Recheck the linked source documents before public release.
3. Implement the complete marketing journey, with the Alignment Explorer as its signature interaction.
4. Use local, deterministic fictional data for public demonstrations. Connect no model, survey service or production product account by default.
5. Implement a real pilot-request submission only when the owner supplies an approved destination. Otherwise ship an explicitly labeled preview state, with no false success message.
6. Verify the acceptance criteria and document remaining launch dependencies. Deliver runnable source and setup instructions. Publishing is a separate action unless already authorized.

Default decisions in this document authorize implementation of the proposed marketing experience. They do not authorize expanding the underlying product into a full SaaS application, inventing customer evidence, or asserting unsupported functionality.

## 2. Product, audience and commercial objective

**Positioning:** CommsAlign connects team communication concerns with practical coaching for the managers whose everyday messages shape the work.

**Public product names:** Team Diagnostic (internal reference: Tool 2) and Message Coach (internal reference: Tool 1). Avoid leading with tool numbers in navigation or headlines.

**Primary buyers:** People/HR leaders, learning and development leaders, and operational leaders responsible for manager effectiveness. This audience definition is a proposed marketing focus, not a verified customer base.

**Primary beneficiary:** a manager who needs to make task instructions and performance feedback easier to act on.

**Visitor's immediate job:** recognize a familiar expectation gap, understand how diagnosis can inform coaching, and decide whether to discuss a focused team pilot.

**Primary conversion:** Request a team pilot. This means requesting a conversation about a pilot; it must not imply instant provisioning, guaranteed eligibility, or a currently purchasable subscription.

**Secondary conversion:** Explore the interactive example. Let visitors understand the mechanism before asking them to submit contact information.

**Intended benefits:** clearer expectations, more actionable feedback, fewer avoidable clarification cycles and less rework. Present these as goals to evaluate, never measured CommsAlign results.

## 3. Product truth: required claim boundaries

### 3.1 Evidence and status vocabulary

Use these distinctions throughout content and implementation:

| Status | Meaning | Website treatment |
| --- | --- | --- |
| Documented prototype | A repository document describes the capability. This review did not run the app or validate production readiness. | Describe with limits; link to methodology. Do not label generally available. |
| Intended / deck-described | The presentation or earlier discussion describes a workflow, but available evidence does not establish implementation. | Explain as intended design or an illustrative example. |
| Proposed marketing interaction | A new, local interaction specified in this brief. | May be fully functional as a website demonstration; clearly label fictional and simulated. |
| Proposed product feature | Not established as implemented in the inspected sources. | Mark “Planned” or “Proposed”; no live-looking controls suggesting availability. |
| Unverified | Evidence is missing, inaccessible, conflicting or insufficient. | Omit the claim or qualify it explicitly. |

“Documented” does not mean independently runtime-tested, scientifically validated, deployed, secure for production, or commercially available.

### 3.2 Capability matrix

| Capability | Evidence/status | Allowed representation |
| --- | --- | --- |
| Tool 2 analyzes synthetic team survey inputs and displays relative patterns | Documented prototype [R1, R3] | “Explore team survey patterns to identify areas worth discussing.” State that the current documented prototype uses synthetic data. |
| Tool 2 records manager observations, hypotheses, reflection and next steps; supports downloadable summaries | Documented prototype [R2, R3] | Show the discussion workflow as documented. Marketing demo exports, if added, must say they contain fictional demonstration data. |
| Minimum-response suppression | Documented prototype [R3] | Explain that small-group results can be withheld. The guide uses a configurable minimum of 5 responses per item; this is a documented demo setting, not a blanket anonymity guarantee. |
| Tool 2 establishes why engagement is low or identifies the person causing a problem | Unsupported | Never claim this. Survey patterns prompt investigation; they do not establish causation. |
| Tool 1 accepts a draft and uses an imported AI judging component for evaluation/feedback | Documented integration, conditional on Azure configuration and explicit submission consent [R1, R2] | Describe a draft-assessment workflow. Do not imply a verified operational live model connection. |
| Exact Tool 1 rubric dimensions | Deck-described; imported judge source not newly verified [D1, R2] | Explain task-instruction and feedback criteria at a high level. Any exact labels or score scale must be checked against the imported judge before being represented as actual output. |
| Automatic message rewriting | Explicitly unimplemented in inspected documentation [R1, R2] | The website may show a manually authored, manager-confirmed improved example; label it illustrative. Do not advertise an existing one-click rewrite. |
| Automatic Tool 2 → Tool 1 transfer, recommendations or intervention routing | Explicitly unimplemented [R1, R2] | The connected demonstration is a conceptual/manual workflow. State this at the handoff. Shared navigation is not automatic integration. |
| Measured improvement dashboard, longitudinal tracking and automated follow-up surveys | Proposed; not established by inspected sources | Show only as a clearly separated future concept or explain in prose. No working-looking “live” dashboard. |
| Recognition and employee-voice coaching | Possible extensions in prior discussion [C1] | Do not list as current Tool 1 capabilities. Prioritize task expectations and progress feedback. |
| Reduced rework, time savings, ROI or engagement gains from CommsAlign | Unproven | Describe pilot hypotheses. No invented impact percentages, testimonials or savings. |
| Enterprise integrations, SSO, compliance certifications, data residency, multilingual support, production availability | Unverified | Omit unless the owner supplies current evidence. |

Additional facts to preserve:

- The repository describes a **shared prototype**. Its README also contains an older, separate rule-based CLI; do not attribute that CLI's dimensions or revision template to the imported Tool 1 judge. [R1]
- Integration verification did not include a real model request. Mocked tests do not establish successful live AI operation. [R2]
- The deck calls Tool 2 “proposed,” while repository documents describe a synthetic-data prototype. Explain this difference in the methodology page: the deck expresses intent; the repository documents limited prototype work. Neither proves production deployment. [D1, R1–R3]
- The Tool 2 guide describes suppressed groups losing saved notes when the response threshold is raised. Do not casually promise that all hidden data is preserved, or transplant this behavior into the marketing demonstration. [R3]
- The source review inspected documents, not live product behavior or the complete underlying code. Mutable repository links should be checked again before launch.

### 3.3 Safe language and language to avoid

| Use | Avoid |
| --- | --- |
| “Highlights patterns worth investigating” | “Finds the root cause of disengagement” |
| “Helps managers assess a draft” | “Automatically fixes every message” |
| “A connected approach to diagnosis and coaching” | “Already integrated end to end” |
| “Designed to support clearer expectations” | “Proven to reduce rework by 30%” |
| “Future measurement concept” | “Track your verified ROI today” |
| “Small-group suppression is one safeguard” | “Guaranteed anonymous” |
| “Illustrative, manager-confirmed revision” | “Actual AI output” for an authored example |

Do not say “research-validated,” “scientifically proven,” or “evidence-based impact.” Prefer a specific description of the documented rubric and evidence-review status.

## 4. Narrative and information architecture

### 4.1 The uninterrupted argument

1. **Recognition:** one ordinary request can create several different expectations.
2. **Visibility:** repeated misunderstandings deserve a team-level conversation, not an assumption about one person's writing.
3. **Diagnosis:** Tool 2 makes survey patterns visible and structures that conversation.
4. **Judgment:** a manager and team explore whether unclear communication contributes to the issue.
5. **Intervention:** Tool 1 helps the manager assess task instructions or feedback before sending.
6. **Learning:** a pilot could examine whether messages and employee understanding improve. Automated measurement is proposed.

Each section must create the reason for the next. Keep the same fictional team and report example across diagnosis and coaching. Give Message Coach the deepest product demonstration after Team Diagnostic establishes the need.

### 4.2 Routes

| Route | Purpose | Main action |
| --- | --- | --- |
| `/` | Sell the connected story | Request a team pilot |
| `/how-it-works` | Explain diagnosis, human interpretation, coaching and proposed evaluation | Explore the example |
| `/demo` | Full Alignment Explorer | Request a team pilot |
| `/solutions` | Connect the same workflow to HR, managers and operations | Discuss a team pilot |
| `/research` | Explain method, evidence, limits and product status | Explore the example |
| `/pricing` | Explain pilot-led commercial approach without invented prices | Request a team pilot |
| `/request-pilot` | Capture a legitimate pilot enquiry when configured | Submit request |

Include a useful 404. Add privacy and terms routes only when approved policy text exists. A preview may show a clearly labeled policy placeholder; production must not link to fabricated policies. Do not add an application dashboard, checkout, account creation or login route. A configured, verified external product URL may be linked later.

### 4.3 Navigation and footer

Desktop: CommsAlign wordmark → How it works · Solutions · Research · Pricing → Request a team pilot.

“Explore the example” links to `/demo`; use it as the hero's secondary action. “Platform” may label an anchor to the capabilities section, but do not add a redundant platform route for this release.

Mobile: wordmark, menu button, simple disclosure containing the same links and CTA. The menu must work with keyboard and touch; opening it must not hide the current page's title behind an overlay.

Footer copy: “CommsAlign connects team communication concerns with practical manager coaching.” Include route links, approved contact information when supplied, and a visible “Prototype and methodology” link to `/research#product-status`. Never invent a company address, customer logo, partner affiliation or social account.

## 5. Homepage: structure and production copy

The copy below is approved **for this proposed marketing implementation**, subject to the status disclosures specified alongside it. It is not a claim that features have been verified beyond section 3.

### H1. Hero — promise and mechanism

Eyebrow: **TEAM INSIGHT. EVERYDAY ACTION.**

Headline: **Your team isn't always on the same page. Let's find out why.**

Body: “Find where communication may be breaking down. Help managers turn those insights into clearer instructions and more actionable feedback.”

Primary CTA: **Request a team pilot** → `/request-pilot`.

Secondary CTA: **Explore the example** → `/demo`.

Supporting line: “A connected approach: Team Diagnostic → Message Coach. Improvement tracking is a future ambition.”

Visual: a large, readable native interface showing one fictional request and contrasting expectations. Include a compact “Illustrative example” label. No decorative AI orb, stock office collage or fabricated product screenshot. Keep the headline visible without animation.

Hero disclosure: “Current documentation describes a prototype. Public examples use fictional data.” Link “prototype” to `/research#product-status`.

### H2. Recognition — the interactive expectation gap

Anchor: `#expectation-gap`.

Headline: **One request. Different expectations.**

Body: “A message can feel clear to the sender and still leave others guessing. Explore what happens when the outcome, timing and context stay unstated.”

Implement the perspective-exploration part of section 6 here. It translates the attached tree-swing reference into a live experience of diverging interpretations. Introduce the confirmation/coaching controls in H4, after the diagnosis and discussion. It must not embed the screenshot as the experience.

Transition below the module: **“One unclear message is a moment. A repeated pattern is something to investigate.”**

### H3. Team Diagnostic — establish the need

Eyebrow: **01 · UNDERSTAND THE PATTERN**

Headline: **Start with what the team is experiencing.**

Body: “Team Diagnostic explores survey patterns and supports a structured manager discussion. Use those signals to ask better questions and decide where attention may be needed.”

Show the same fictional team and expectation concern used in the Explorer. Include a sample aggregate pattern, a manager observation and a hypothesis as distinct objects. The human observation creates the bridge to coaching.

Caption: “Fictional demonstration data. A survey pattern does not establish its cause. The documented prototype uses synthetic inputs.”

Transition: **“When unclear expectations are part of the problem, the next step is a message someone can act on.”**

### H4. Message Coach — make the intervention tangible

Eyebrow: **02 · IMPROVE THE MESSAGE**

Headline: **Turn the insight into a clearer instruction.**

Body: “Message Coach is designed to assess managerial drafts against defined criteria. The manager supplies missing facts, reviews the feedback and decides what to send.”

Show the original message, missing-detail prompts and confirmation/coaching controls from section 6.6. Reuse the Explorer's state from H2 so supplied details also update its interpretations; do not invent a second dataset. The visitor can now construct the manager-confirmed example below.

Main comparison:

> Before: “Can you get the report ready ASAP? We need it for leadership.”
>
> After manager confirmation: “Please prepare the November revenue report with regional totals for leadership's monthly revenue review by Friday at 2 PM. Send a draft Thursday at 3 PM so we can review it together.”

Caption: “Authored illustration, not a live model output. The manager confirms every added fact. Automatic rewriting is not implemented in the inspected documentation.”

Supporting points: “Clarify the deliverable.” · “Make the deadline explicit.” · “Explain the purpose.” · “Agree a check-in.” These are demonstration prompts, not a verified transcription of the imported judge rubric.

### H5. Connected approach — state the handoff honestly

Headline: **Diagnosis gives coaching a reason to happen.**

Body: “Team insight identifies a concern. A conversation tests the explanation. Message coaching helps the manager change a relevant behavior.”

Use one continuous sequence with three labeled stages: Team signal → Human discussion → Manager draft. The transition to Tool 1 is explicitly **“Manager chooses a coaching focus.”**

Disclosure at the connector: “Conceptual workflow. Automatic transfer between the tools is not currently documented as implemented.”

### H6. Evaluation — aspiration with a concrete pilot question

Eyebrow: **03 · EVALUATE THE CHANGE · PROPOSED**

Headline: **Then ask whether the change helped.**

Body: “A pilot could compare message clarity, recipient understanding and clarification requests over time. These are evaluation goals, not established CommsAlign results.”

Present three questions, without numbers or rising graphs: “Are expectations clearer?” · “Do recipients need less clarification?” · “Is the coaching effort worthwhile?”

Persistent label: **“Future measurement concept — no live tracking dashboard.”**

### H7. Differentiation — explain the job

Headline: **A better sentence is useful. A clearer management practice goes further.**

Body: “CommsAlign's intended distinction is a structured managerial workflow: understand a team concern, assess a relevant draft and review the missing information before sending.”

Three short contrasts framed as product focus, without unsupported competitor claims: “Team context before a writing task.” · “Defined criteria instead of a blank prompt.” · “Manager confirmation of facts and next steps.”

Research link: **Understand the approach and its limits** → `/research`.

### H8. Intended business value

Headline: **Less guessing. Clearer expectations. More useful conversations.**

Body: “These are the outcomes a focused pilot should test. Begin with a narrow use case—task instructions or progress feedback—and learn whether the approach helps your team.”

No savings calculator, fabricated testimonial or quantified benefit in the default build. Proof comes from the visible mechanism and transparent limits.

### H9. Final conversion

Eyebrow: **START WITH ONE TEAM**

Headline: **Find the gap. Improve the message. Learn what changes.**

Body: “Discuss a focused pilot that connects a team communication concern with practical manager coaching.”

CTA: **Request a team pilot** → `/request-pilot`.

Supporting line: “Scope, access, timing and commercial terms are agreed after the conversation.”

## 6. Signature interaction: the Alignment Explorer

### 6.1 Purpose and reference

The user supplied a tree-swing cartoon showing different interpretations of the same request. Preserve its central insight: **people can appear to agree while imagining different outcomes**. Translate that insight into an original, interactive workplace example.

Do not place the screenshot on the page as the tool. Build native text, controls and live previews. Do not copy its ten panels, artwork or role stereotypes. Show plausible assumptions without blaming customers, managers, designers or developers.

**Experience name:** Alignment Explorer.

**Visible title:** One request. Different expectations.

**Promise:** explore how an unclear instruction can produce different assumptions; supply manager-confirmed details and see a shared written brief emerge.

This is a **proposed marketing interaction**, not a new current product capability. Its state changes use authored local scenario data and templates. There is no AI inference, employee assessment, psychological prediction or claim that actual people now understand one another.

Use this as the website's memorable interaction. It connects the familiar problem to Team Diagnostic and then makes Message Coach's intended intervention tangible.

### 6.2 Homepage versus full demonstration

- **Homepage:** H2 shows perspective exploration only, immediately after the hero. H3 establishes the team pattern and human discussion. H4 introduces the confirmation/coaching controls. These views share one scenario and state, so confirmed details also update the earlier interpretation view. Visitors stay on the same page, in the order problem → diagnosis/discussion → coaching.
- **`/demo`:** expand the same component/data into four explicit stages: Expectations → Investigate → Coach → Evaluate (proposed). Keep stage navigation visible and preserve choices while moving between stages.
- Do not auto-advance, auto-scroll the visitor, demand an email, or play a timed sequence. Let people inspect and compare.
- Use one shared scenario module and state model. Do not maintain different messages, facts or simulated “results” across the homepage and demo.
- A reload may reset the website demo. If persistence is added, make it session-scoped and store only these fictional choices. The inline conversation preview may use its host's state mechanism; that host API is not a website dependency.

### 6.3 Scenario fixture: explicit fictional facts

**Team:** Atlas, a fictional team. **Task:** a revenue report for a leadership review.

Original message: **“Can you get the report ready ASAP? We need it for leadership.”**

Before clarification, selecting a perspective reveals these possible interpretations:

| Detail | Manager assumes | Team member assumes | Stakeholder assumes |
| --- | --- | --- | --- |
| Deliverable | November revenue report with regional totals | A one-page report summary | A slide deck with recommendations |
| Deadline | Friday, 2 PM | End of today | Before Wednesday's meeting |
| Purpose | Leadership's monthly revenue review | A general leadership update | A decision on next quarter's budget |
| Check-in | A draft on Thursday | No draft review needed | Review together before the meeting |

Label these **“Possible interpretation — fictional”**, not detected beliefs. A manager's assumption is still an assumption until explicitly communicated.

Manager-confirmed scenario facts, revealed by the coaching controls:

1. Deliverable: November revenue report with regional totals.
2. Deadline: Friday at 2 PM.
3. Purpose: leadership's monthly revenue review.
4. Check-in: send a draft Thursday at 3 PM for review.

Times belong to this fictional scenario. Do not derive them from today's date, imply that a real meeting is scheduled, or attach a fabricated customer calendar.

### 6.4 Stage 1 — explore expectations

Show the original message, then three native perspective buttons: **Manager**, **Team member**, **Stakeholder**. The active button must be visibly selected and expose `aria-pressed`.

Selecting a role changes its possible deliverable, deadline, purpose and check-in. Use a readable miniature report/brief preview or a four-row interpretation view. A richer website may show three small artifact previews together on wide screens, but role selection must expose the full content and remain usable on mobile.

Pair every interpretation with its basis: **Assumed** or **Confirmed in this example**. Never use color alone. Do not display an “alignment score” or an invented probability of misunderstanding.

Bridge copy: “When this happens repeatedly, start by understanding the team's experience.”

Action: **Investigate the team pattern** → stage 2, a local demo state change, not a call to Tool 2.

### 6.5 Stage 2 — Tool 2 sets the problem

Show a small, clearly synthetic team snapshot, not a fabricated screenshot of the live product:

- Label: **Fictional survey scenario · not actual Team Diagnostic output**.
- Atlas: 20 fictional responses.
- Original demonstration prompt: “Tasks arrive with a clear expected result and deadline.”
- Example response average: 2.8 out of 5, with a visible scale label. This number is authored demonstration data, not a product benchmark or customer result.
- Manager observation: “People describe receiving tasks without a shared view of the deliverable or deadline.”
- Working hypothesis: “Unstated expectations may be contributing to confusion.”
- Alternative explanation: “Competing priorities or workload could also be contributing.”

Keep the survey signal, observation and hypothesis visually separate. Use an original demonstration question rather than reproducing a named licensed instrument or implying endorsement. Mention the project's engagement-framework connections only on the methodology page, with verified attribution and a clear status note.

Required disclosure: “A low survey score does not establish the cause. In this fictional example, the manager discusses the pattern with the team before choosing a communication intervention.”

Explicit control: **Review the discussion finding** reveals the authored observation; it does not claim to generate one. Follow with **Explore message coaching**.

Handoff label, adjacent to the action: **“Simulated manual handoff. Automatic cross-tool transfer is not implemented in the inspected documentation.”**

### 6.6 Stage 3 — Tool 1 provides the intervention

Keep the original message visible. Show four labeled checkboxes that **add the confirmed fictional details** listed in section 6.3. A checked box means that this scenario fact is now explicit, not that the software invented it or inferred its truth.

On each change:

1. Update that field across all perspectives, marking it confirmed and leaving other fields unchanged. The currently selected perspective shows the change immediately.
2. Update the shared brief from confirmed facts only.
3. Preserve all other fields as assumptions or explicit missing-detail prompts.
4. Update a factual count such as **“2 of 4 details confirmed”**. This is a checklist count, not a product quality score.
5. Announce a short result with `aria-live="polite"`; avoid reading the entire interface twice.

An unchecked deadline remains **“[deadline to confirm]”** in the brief. Never fill missing facts with invented dates, recipients or commitments.

Completed illustrative revision:

> Please prepare the November revenue report with regional totals for leadership's monthly revenue review by Friday at 2 PM. Send a draft Thursday at 3 PM so we can review it together.

Completion copy: “The written brief now contains the same confirmed details across the perspectives. A conversation is still needed to check understanding.”

Caption: “Deterministic demonstration using authored scenario facts. Not live AI feedback or an implemented automatic rewrite.”

Allow unchecking any detail; its assumptions and missing prompt must return. A **Start over** action on the full demo restores the original state with a clear accessible label. No destructive confirmation is needed for fictional local state.

Optional, lower priority: a **Copy example brief** action after all four details are confirmed. Report clipboard failure and provide selectable text; never claim the message was sent. Do not add send-to-email or workplace integration controls.

### 6.7 Stage 4 — the aspirational measurement loop

Heading: **What would you want to learn next?**

Show a proposed pilot evaluation plan, not a simulated improvement chart:

- Compare original and revised messages using an agreed assessment method.
- Ask recipients whether the expected result, timing and next step are clear.
- Record clarification requests and rework consistently, with agreed definitions.
- Account for manager time spent using the coaching workflow.
- Revisit the relevant team concern after an agreed interval.

Required label: **“Proposed evaluation approach. No measured results or automated tracking are shown.”**

Explain: “A simple before/after observation can inform a pilot, but cannot on its own establish that CommsAlign caused a change.”

Final action: **Discuss a team pilot** → `/request-pilot`.

### 6.8 State model and edge cases

Suggested framework-independent model:

```ts
type ExplorerStage = 'expectations' | 'investigate' | 'coach' | 'evaluate';
type Perspective = 'manager' | 'team' | 'stakeholder';
type Detail = 'deliverable' | 'deadline' | 'purpose' | 'checkin';

interface ExplorerState {
  stage: ExplorerStage;
  perspective: Perspective;
  confirmedDetails: Detail[];
  discussionFindingOpen: boolean;
}
```

- Initialize to Expectations, Manager, zero confirmed details, finding closed.
- Derive the brief and visible assumptions from state; do not persist duplicate computed results.
- Moving between stages preserves choices. Reset clears them. Invalid persisted state falls back to defaults.
- Empty or partial confirmation is a useful state, not an error. Do not show a “success” banner until all four facts are present, and even then describe completed facts rather than actual organizational alignment.
- No loading spinner or artificial “AI thinking” delay; this interaction is local and immediate.
- No free-text evaluation in this release. If an editable message field is added later, it must not imply live AI scoring without a real, separately authorized service and its own product disclosure.
- If JavaScript fails, show the original message, the three possible interpretations and the completed authored example as readable content, with a notice that interaction is unavailable.
- All user-supplied text must be rendered as text, not raw HTML, if later versions permit editing.

## 7. Secondary pages: content and behavior

### `/how-it-works`

H1: **From team concern to a message someone can act on.**

Intro: “Start with a pattern. Investigate it with the team. Help the manager change the relevant communication behavior.”

Use four substantial sections, with the same example:

1. **See the signal.** Team Diagnostic explores team-level survey patterns. Current documented inputs are synthetic; patterns are provisional.
2. **Discuss the explanation.** Separate observations from hypotheses and record a human judgment about the next step.
3. **Coach the draft.** Message Coach's documented integration assesses drafts when its model service is configured; the website shows an authored example, not live model output.
4. **Evaluate the change — proposed.** Explain the pilot questions and future measurement ambition.

Include “What the tools do today / What is proposed” using the section 3 matrix in a shortened form. End with **Explore the example** and a secondary pilot link. Do not repeat the entire homepage verbatim.

### `/solutions`

H1: **A practical starting point for clearer management communication.**

Intro: “Choose a narrow concern, connect it to an everyday behavior and agree what a pilot should test.”

Three sections with concrete situations:

| Audience | Situation and copy | Proposed pilot focus |
| --- | --- | --- |
| People and HR leaders | “Your survey highlights a concern. Managers need a useful next step.” | Explore an expectations concern, discuss context and coach task instructions. |
| Managers and team leads | “You have explained the task. Does the message contain enough to act?” | Assess instructions and feedback, confirm missing facts and review the draft. |
| Operations leaders | “Repeated clarification can make execution harder to coordinate.” | Examine one workflow with repeated handoffs and define what clearer communication would mean. |

Label the use cases as proposed pilot examples. No customer names, implied adoption or industry-specific compliance claims. Recognition and employee voice may appear only in a clearly marked future-research note, not as current coaching solutions.

### `/research`

H1: **Understand the approach. See its limits.**

Intro: “A useful communication tool should make its assumptions and evidence visible.”

Required sections:

- **The mechanism:** team patterns → human interpretation → draft assessment. Distinguish team-level signals from individual messages.
- **Rubrics and evidence:** the deck describes task-instruction and feedback criteria including outcome clarity, timing, rationale, support and progress review. Say that exact implementation labels and scoring need verification against the imported judge. Do not substitute the older CLI rubric. Research-corpus/RAG claims remain qualified until the active implementation and evidence review are confirmed.
- **Survey interpretation:** patterns are not causal explanations; a manager discussion is essential. An engagement measure alone does not show communication caused an issue.
- **Privacy limits:** small-response suppression is documented; it does not establish anonymity, legal compliance, consent coverage or safe production processing.
- **Product status** (`#product-status`): current documentation describes a prototype, synthetic Tool 2 inputs, conditional model setup, unimplemented rewriting and handoff, and proposed measurement.
- **Evaluation agenda:** independently assess message clarity and recipient understanding; track time costs and avoid treating a change in a rubric score as proof of business impact.
- **Source ledger:** readable links to R1–R3, presentation attribution where publishable, and source review date. Avoid publishing private uploaded material without the owner's decision.

Default to no numerical workplace statistics. The deck's Axios, Gallup and other figures are external problem-context claims, not CommsAlign evidence; independently verify exact source, date, population and wording before adding them. Never combine a general workplace cost estimate with a product savings promise.

### `/pricing`

H1: **Start with a focused team pilot.**

Body: “Discuss your use case, the team involved and what you want to learn. Pilot scope, availability and commercial terms are agreed individually.”

Show the discussion topics: use case; participants and manager workflow; responsible handling of any real information; evaluation approach; access and support requirements.

CTA: **Request a team pilot**.

FAQ:

- **Can I subscribe online?** “Self-service subscriptions are not offered on this website.”
- **What does a pilot cost?** “Pricing and scope are discussed with the project owner. No public plan prices have been confirmed.”
- **Does a request guarantee access?** “No. A request starts a conversation about fit and availability.”

Do not invent a free trial, paid tiers, seat limits, annual discounts, implementation fees, payment flow or support SLA.

### `/request-pilot`

H1: **Let's discuss one team and one communication challenge.**

Body: “Tell us where expectations or feedback are getting lost, and what a useful pilot would help you learn.”

Minimum form:

| Field | Requirement and validation |
| --- | --- |
| Name | Required, trimmed, 1–100 characters |
| Work email | Required, valid email format, maximum 254 characters; do not reject personal domains automatically |
| Organization | Required, trimmed, 1–150 characters |
| Role | Optional, maximum 100 characters |
| Team size | Optional select: 1–10, 11–50, 51–200, 201+, Unsure |
| Communication challenge | Optional, maximum 1,500 characters; ask for a general description, with no employee names or confidential messages |

Submit label: **Request a team pilot**. Pending label: **Sending request…**

Form helper: “Please describe the situation generally. Do not include identifiable employee information or confidential message content.”

Production success, only after confirmed submission: **“Your request has been received. The project team will review it and contact you using the email provided.”** Do not promise a response deadline without an operational commitment.

Production error: **“Your request could not be sent. Your entries are still here. Please try again.”** Display a reference ID only if one is actually returned.

Unconfigured preview: prominent notice **“Preview form — requests are not being sent.”** Replace submit with **“Preview request”**; validate locally and label the result **“Preview only. Nothing was sent or saved.”** Do not show a disabled or fake-success form that resembles a real lead pipeline.

Production launch requires an approved processing destination, approved privacy notice, necessary legal/consent text, spam controls and a verified end-to-end submission. Exact legal text must come from the owner; do not generate operational promises as facts.

## 8. Visual system

### 8.1 Direction

Inherit the earlier conversation's direction: **warm off-white, deep navy, restrained teal, large editorial headlines and precise product examples**. Make the website feel like a thoughtful management instrument. The recognizable visual is an unclear request becoming an explicit brief.

The colors, measurements and components below are proposed implementation defaults; there are no verified brand assets in this brief. Preserve any later owner-supplied brand assets rather than silently replacing them.

Avoid generic AI artwork, glowing gradients, glass panels, endless equal-sized feature cards, decorative dashboards and miniature text pretending to be a product screenshot. Prefer typography, quiet space, clear rules and realistic messages.

### 8.2 Tokens

```css
:root {
  --surface-page: #F7F5EF;
  --surface-panel: #FFFFFF;
  --surface-soft: #ECEFEA;
  --ink: #162B3D;
  --ink-secondary: #536272;
  --action: #076D67;
  --action-hover: #055650;
  --action-ink: #FFFFFF;
  --accent-soft: #E7F1EE;
  --rule: #CDD6D3;
  --focus: #0C6FC4;
  --planned-ink: #7A4A00;
  --planned-surface: #FFF3DD;
  --error-ink: #9A2525;
  --error-surface: #FFF0EE;

  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 24px;
  --space-6: 32px;
  --space-7: 48px;
  --space-8: 64px;
  --space-9: 96px;
  --space-10: 128px;

  --radius-control: 8px;
  --radius-panel: 12px;
  --content-max: 1200px;
  --copy-max: 65ch;
}
```

Use thin neutral rules as structure, not as the only boundary of an interactive control. Controls need clearly visible boundaries and focus states. Validate contrast on the actual combinations used, including selected, hovered, disabled and error states. The palette alone does not establish accessibility.

### 8.3 Typography

- Headings: Georgia or an approved self-hosted editorial serif. Body/interface: system sans-serif stack. These defaults work without external font requests.
- If a supplied font is adopted, verify its license and loading strategy; use fallbacks and prevent invisible text.
- H1: fluid 40–72px; approximately 1.05 line height; maximum 18–20 characters per line where possible. On 320px screens, allow 36px and natural wrapping.
- H2: fluid 30–48px; 1.15 line height. H3: 22–28px; 1.25 line height.
- Body: 17–18px; 1.6 line height. Interface text: 16px; supporting labels: 14px minimum.
- Use sentence case. Eyebrows may use restrained uppercase and modest tracking. Avoid entire paragraphs in uppercase.
- Keep body copy to roughly 60–65 characters per line. Never use tiny text to make a mock interface look sophisticated.

### 8.4 Layout and pacing

- Desktop container: 1,200px maximum with 32px minimum gutters; use a 12-column grid where helpful.
- Hero: text and native example share the first viewport on wide screens. Give the example enough width to read; no compressed dashboard collage.
- Section spacing: roughly 96–128px on desktop and 56–72px on mobile. Give more space above headings than below them.
- Alternate open editorial sections with focused product demonstrations. Use one quiet dark-navy section for the closing CTA if contrast and tone are maintained.
- Connected workflow: horizontal on wide screens, vertical on narrow screens, with explicit labels at every step. The proposed measurement step uses a visible “Proposed” label and distinct surface; do not rely on a dashed line alone.
- Native message examples and interpretation rows should feel like real work artifacts, not chat bubbles floating in empty space.
- The homepage may reuse the explorer component, but must not show the same full interactive module twice in one scroll.

### 8.5 Responsive rules

| Width | Behavior |
| --- | --- |
| 320–639px | One column; 20px gutters where space permits; navigation disclosure; stacked stage navigation and full-width form fields; perspective controls wrap. |
| 640–1023px | Two-column layouts only when content remains readable; explorer may keep a single-column stage body; 24px gutters. |
| 1024px+ | Two-column hero and product sections; full navigation; 32px or larger gutters. |
| 1440px+ | Center the capped content; do not stretch paragraph measures or add decorative filler. |

No horizontal page scrolling at 320px. Interpretation views must wrap or become semantic field/value lists on narrow screens. All essential content must fit at 200% zoom. Headline line breaks should adapt; avoid hardcoded desktop `<br>` elements that break mobile reading.

### 8.6 Components

Build a small reusable set: `SiteHeader`, `MobileNav`, `SiteFooter`, `ButtonLink`, `SectionHeading`, `StatusDisclosure`, `MessageExample`, `AlignmentExplorer`, `PerspectiveSelector`, `InterpretationView`, `ConfirmedDetailControls`, `SharedBrief`, `DiagnosticScenario`, `ManualHandoffNote`, `MeasurementConcept`, `PilotRequestForm`, `FormField`, `FaqDisclosure`.

Use the status disclosure in context, close to the relevant example. Keep technical provenance on `/research`; avoid repeating full implementation caveats in every marketing paragraph. Critical demo/availability labels must remain visible without a tooltip.

Use simple icons only where they aid scanning. Decorative icons are hidden from assistive technology. Every icon-only control needs an accessible name; favor visible labels.

## 9. Interactions, accessibility and performance

### Interaction rules

- Primary buttons show an unambiguous next action; links use real destinations. No `href="#"` placeholders or dead controls.
- Hover may add subtle emphasis but must not reveal essential information. Touch and keyboard have the complete experience.
- Perspective selection is reversible. Stage navigation preserves local choices; reset restores the documented default.
- Form validation appears near fields and in a focused error summary on submission. Preserve entries after network failure and prevent accidental duplicate submissions.
- FAQs use native disclosure elements where possible. Mobile navigation uses a genuine button with `aria-expanded` and `aria-controls`.
- Optional sticky navigation must respect anchor offsets and never obscure focused elements. No sticky mobile conversion bar is required.

### Motion

- Use short, purposeful transitions of approximately 150–220ms for state changes. Content is visible before animation runs.
- During clarification, emphasize only the changed detail. Do not animate the page into a completely different layout or move the selected control.
- Respect `prefers-reduced-motion`; all meaning remains visible with transitions removed. No autoplay video, parallax, continuous swinging animation or simulated AI typing.

### Accessibility target

Aim for WCAG 2.2 AA conformance and verify the implemented experience, including keyboard use and mobile content. Required behavior:

- One H1 per page, logical headings, semantic landmarks and a skip link.
- Native buttons, links, checkboxes, labels and fieldsets; complete keyboard operation and visible focus.
- At least 44×44px effective touch targets for key controls where feasible; no overlapping targets.
- Correct pressed/expanded/selected states, unique IDs and programmatically associated labels.
- If a tab interface is used, implement its keyboard model; a group of stage buttons is also acceptable and simpler.
- Text contrast at least 4.5:1 for ordinary text and 3:1 for large text; test interface boundaries and focus indicators against adjacent colors.
- Live updates use a short polite announcement. Errors use appropriate alerts. No broad live region that announces the whole page after every click.
- A textual equivalent for any decorative scenario graphic. No image containing the only copy or interaction.
- Respect reduced motion, zoom, text reflow and browser text-size settings. Never lock orientation.

### Performance and resilience

- Prefer static generation or server-rendered content with client JavaScript scoped to the explorer, navigation and form.
- Do not ship charting libraries, animation frameworks, a model SDK or a canvas engine for this brief's simple interactions.
- Defer nonessential assets, reserve media dimensions and avoid layout shifts when controls update.
- Target LCP ≤2.5s, CLS ≤0.1 and INP ≤200ms as performance goals; report actual measurement context rather than claiming field metrics from a local audit.
- Keep important product copy and the primary CTA readable without client-side rendering. A no-JavaScript visitor receives the example as static content and a useful form/interaction availability notice.
- No external calls are needed for the demonstration. Production form submission is the only required service integration when configured.

## 10. Implementation specification

### 10.1 Framework and project structure

Reuse the repository's current web framework, router, test tooling and package manager. If this is a separate greenfield marketing project, a TypeScript component-based frontend with static rendering is a suitable default; choose a maintained framework compatible with the hosting environment and record the choice. Do not convert the underlying Streamlit prototype into the marketing site as an incidental task.

Suggested organization; adapt file names to the chosen framework:

```text
src/
  routes/                  # The seven routes in section 4
  components/site/         # Header, footer, layout, CTA, disclosures
  components/explorer/     # Perspective, facts, brief, stage controls
  components/forms/        # Pilot request and field/error components
  content/site-copy.ts     # Approved copy and route metadata
  content/product-status.ts# Claim statuses, source IDs and disclosures
  data/alignment-demo.ts   # Fictional facts and assumptions only
  lib/explorer-state.ts    # Pure state/derived brief helpers
  lib/pilot-request.ts     # Form validation and configured submission
  styles/tokens.css
  styles/global.css
public/
  approved-assets/         # Only approved brand/visual assets
```

Use semantic HTML and CSS for the report/brief previews. No screenshot is required for the Alignment Explorer. The supplied screenshot is a conceptual reference, not a shipping asset.

### 10.2 Product claims as structured content

Store the source/status alongside feature copy, so a future edit does not silently promote a concept into a live feature:

```ts
type CapabilityStatus = 'documented-prototype' | 'intended' | 'proposed' | 'unverified';
interface CapabilityCopy {
  id: string;
  title: string;
  status: CapabilityStatus;
  summary: string;
  disclosure: string;
  sourceIds: string[];
}
```

Documented automatic-rewriting and handoff limitations should be stored explicitly, not inferred from a missing feature entry. Keep product status text reviewable in one place. No client-side feature flag should remove a required disclosure while leaving the associated demo or claim visible.

### 10.3 Marketing and application boundary

- The marketing website does not inspect employee messages or real survey data.
- The demo never calls Tool 1's Azure service or Tool 2's analysis code. It uses authored fixtures.
- Do not embed credentials or model endpoints in public code. Any later live product integration needs a separate scope and implementation review.
- Real application links come from verified configuration. Hide unconfigured “Open app” or “Log in” actions rather than linking to a fake dashboard.
- Keep the public demonstration independent from private product sessions and data stores.

### 10.4 Pilot form integration

Prefer a same-origin server handler such as `POST /api/pilot-request`, with an owner-approved storage or delivery service behind it. Secrets stay server-side. Alternatively, use the host's approved form service with equivalent validation and status handling.

Required configuration:

- Submission destination and credentials, if applicable.
- Approved recipient/team workflow, without inventing an email address.
- Approved privacy notice and any required consent wording.
- Production origin and deployment configuration.
- Verified public product URL, only if such a link should be shown.

Validate server-side as well as client-side, enforce field lengths, apply suitable abuse protection and avoid logging free-text enquiry contents by default. Return machine-readable success/error states without exposing credentials or internal traces.

Handle slow response, timeout, validation rejection, rate limiting and server error. Do not clear form entries until success is confirmed. Disable repeated submit while pending, then allow retry after failure. No automatic enrollment in marketing email.

### 10.5 Analytics and SEO

Analytics are optional and must follow the owner's approved privacy configuration. The site must function without analytics or advertising scripts.

If enabled, a minimal event set is sufficient: `explorer_started`, `perspective_changed`, `detail_confirmed`, `demo_completed`, `pilot_cta_clicked`, `pilot_request_success`. Record only event type, fictional scenario ID and appropriate non-identifying context. Never record contact fields, raw messages, enquiry text or real employee details. Fire success only after confirmed production submission; preview interactions must not count as leads.

Provide unique titles and descriptions, canonical URLs once the domain is known, share metadata, a sitemap and a useful 404. Suggested home title: **CommsAlign — From team insight to clearer manager messages**. Suggested description: **Explore a connected approach to team communication: investigate patterns, coach managerial drafts and plan how to evaluate change.**

Do not invent a canonical domain, structured ratings, reviews, address, software price or availability. Keep preview deployments out of search indexing; make the production indexing choice explicit at release.

## 11. Acceptance criteria

The implementation is complete only when the applicable criteria below are met. A preview can meet the site/demo criteria while production form and publication remain explicitly blocked by missing configuration. Report that distinction honestly.

### A. Narrative and content

- [ ] A new visitor can identify the problem, the diagnosis-to-coaching connection and the next action from the first two sections.
- [ ] Team Diagnostic precedes Message Coach in the story; human interpretation sits between them.
- [ ] Message Coach receives the deepest intervention example, keeping Tool 1's commercial role clear.
- [ ] Every route in section 4 contains useful copy, working navigation and a relevant CTA.
- [ ] The same report, roles, confirmed facts and deadlines appear throughout the homepage and demo.
- [ ] No customer logos, testimonials, user counts, prices, ROI statistics or affiliations have been invented.

### B. Product truth

- [ ] The site identifies the documented product as a prototype, not a verified production SaaS deployment.
- [ ] Survey examples are visibly fictional/synthetic, and patterns are never presented as causal proof.
- [ ] Documented Tool 1 judging is separated from authored demonstration prompts and unverified exact rubric details.
- [ ] The older CLI rubric is never silently substituted for the imported Tool 1 judge.
- [ ] Authored revisions are labeled; no claim of implemented automatic rewriting is made.
- [ ] The diagnostic-to-coaching handoff is explicitly conceptual/manual, with no false automatic-integration claim.
- [ ] Measurement is persistently marked proposed; no simulated tracking dashboard or business impact is presented as real.
- [ ] Small-response suppression is not described as a guarantee of anonymity or production security.

### C. Alignment Explorer

- [ ] It is native, interactive content; the screenshot is not used as the tool.
- [ ] Selecting each role changes the visible possible interpretation and its accessible selected state.
- [ ] Initially every field is marked assumed and the shared brief contains missing-detail prompts.
- [ ] Confirming a detail changes only that field and its brief clause; the other assumptions remain visible.
- [ ] All three perspectives show the same value for each confirmed field. Unconfirmed fields retain the scenario-specific assumptions.
- [ ] Unchecking a detail restores that field's assumption and missing-detail prompt.
- [ ] After four confirmations, the brief contains exactly the four approved facts; no extra deadline or commitment appears.
- [ ] The completed state describes shared written details, not a measured alignment score or guaranteed recipient understanding.
- [ ] Full-demo stage navigation preserves choices; reset restores defaults; invalid persisted state is handled safely.
- [ ] Stage 2 separates synthetic survey signal, observation, hypothesis and alternative explanation.
- [ ] The public demo makes no model/API calls and submits no employee data.
- [ ] A readable static example remains when JavaScript is unavailable.

### D. Form and conversion

- [ ] Every primary CTA reaches the pilot page and preserves ordinary browser navigation behavior.
- [ ] Unconfigured mode clearly says preview; nothing is sent, saved as a lead or reported as a successful enquiry.
- [ ] Configured mode validates client and server inputs, preserves entries on failure and prevents duplicate pending submissions.
- [ ] Success is shown only after a confirmed backend success. Error, timeout and retry states work.
- [ ] Production handling uses an approved destination and actual privacy/consent text. No invented email address, policy or response SLA appears.

### E. Visual, accessibility and technical quality

- [ ] The design follows the warm off-white/navy/teal direction and uses readable message examples at normal scale.
- [ ] All key routes and explorer states work at 320, 390, 768, 1024 and 1440px, without horizontal page scrolling or clipped content.
- [ ] Keyboard-only use reaches and operates navigation, stages, perspectives, confirmation controls, FAQs and form.
- [ ] Focus is visible, control states are programmatic, labels are associated and dynamic announcements are concise.
- [ ] Contrast, 200% zoom, reduced motion and touch behavior have been checked.
- [ ] No dead links, placeholder buttons, console errors, hydration failures or missing assets remain.
- [ ] Production build and existing relevant checks pass. New dependencies are justified and locked.
- [ ] Measured performance is reported with its test environment; performance targets are not represented as observed field results.

### Verification plan

Use a bounded review rather than repeated cosmetic changes:

1. Run the project's build, type checks and relevant existing tests.
2. Add meaningful explorer checks for role changes, partial/full confirmation, undo, reset and stage preservation. Test the invariant across the three roles and relevant confirmation combinations: confirmed values agree, unconfirmed values retain their authored assumptions.
3. Verify preview form behavior. When a production handler is configured, exercise success, invalid input, timeout/server failure and duplicate-submit prevention against a safe test destination.
4. Inspect desktop and mobile screenshots together. Check intermediate widths, long text, partial confirmation and the proposed measurement state. Fix material issues in one batch and confirm once more if needed.
5. Perform keyboard and basic screen-reader checks; automated accessibility checks supplement these rather than replacing them.
6. Review every public claim against the section 3 matrix. A working website simulation is not evidence that the underlying product supports the same automation.

Do not call production model services or send a real pilot enquiry as part of routine testing without an approved test destination.

## 12. Delivery, priorities and launch dependencies

### Required first release

All seven public routes; responsive design system; homepage story; compact Alignment Explorer; four-stage demo; structured product-status content; explicit preview or real pilot form mode; metadata; no-JavaScript fallbacks; acceptance verification.

### Optional after the first release

Copy example brief, richer original artifact previews, additional task/feedback scenarios, approved research statistics, verified product links and real pilot evidence. Add only when they strengthen the same connected story.

### Separate future product scope

Automatic rewriting, automated Tool 2 → Tool 1 routing, real survey ingestion beyond documented prototype inputs, longitudinal dashboards, SSO, integrations, subscriptions and customer administration. These require product implementation and evidence; do not slip them into the marketing build.

### Owner inputs that are still needed for public launch

- Target repository/hosting context and verified product availability.
- Current imported Tool 1 rubric, live-model validation evidence and a fresh product-status review if more specific claims are desired.
- Brand assets if the proposed text wordmark, typography and palette should change.
- Approved pilot contact/delivery destination, operating process and commercial terms.
- Approved privacy/terms/consent material and any production data-handling commitments.
- Domain, public contact details, analytics decision and publication authorization if not already given.

Proceed with the proposed design and honest preview behaviors while these are unresolved. List the missing production inputs in the handoff; do not manufacture them or block local implementation on optional brand choices.

### Implementation handoff checklist

Deliver source, local setup instructions, environment-variable examples without secrets, route list, demo fixture description, tests/checks performed and limitations. Include desktop/mobile captures where the environment supports them. State whether the form is preview or production-connected and whether anything was published.

## 13. Source ledger and provenance

Reviewed on 7 November 2026. Repository documentation was inspected through read-only browsing. The application, full imported judge implementation and live model connection were not executed or independently validated. Links below are mutable; recheck them before launch, and record a commit permalink if the implementing agent can obtain one.

| ID | Source | Use and limitation |
| --- | --- | --- |
| R1 | [CommsAlign repository README](https://github.com/aslabereketoglu/urmom/blob/main/README.md) | Shared-prototype status, synthetic data, conditional Tool 1 setup, unimplemented rewriting/handoff; distinguishes the separate older CLI. |
| R2 | [Tool 1 / Tool 2 integration notes](https://github.com/aslabereketoglu/urmom/blob/main/docs/TOOL1_TOOL2_INTEGRATION.md) | Shared navigation, conditional consented model submission, integration limits and lack of live model testing in the documented verification. Historical deployment notes do not prove today's hosting status. |
| R3 | [Tool 2 demo guide](https://github.com/aslabereketoglu/urmom/blob/main/docs/TOOL2_DEMO_GUIDE.md) | Synthetic scenarios, relative patterns, manager discussion, exports, response-threshold suppression and limits on causal/LLM interpretation. |
| D1 | User-supplied `draft1.pptx`, 11 slides, from the referenced conversation | Slide 6: illustrative before/after. Slide 7: intended Tool 1 workflow and rubric concepts. Slides 8–10: Tool 2 and connections described as proposed. External numerical claims not independently verified for public use. File not bundled with this brief. |
| C1 | [Referenced conversation: Explain Tools 1 And 2](chatgpt-conversation://6aefa616-8800-83e9-9089-21d42987aa31) | User's connected narrative, commercial focus on Tool 1, prior website direction and aspiration to evaluate change. Assistant suggestions are context, not implementation evidence. |
| I1 | User-supplied `Screenshot 2026-11-07 at 18.00.47.png` | Conceptual inspiration: different interpretations of one request. The artwork is not included as a website asset. |

No product impact results, customer references, operational security guarantees or public pricing were established by these sources. The Alignment Explorer, website structure, production copy, visual tokens and marketing interactions are proposals authored for this implementation brief.
