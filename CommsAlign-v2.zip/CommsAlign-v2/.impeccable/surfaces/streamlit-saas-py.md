---
version: 1
slug: "streamlit-saas-py"
primary_target: "web/index.html"
related_targets: ["web/app.css","web/app.js","web/coach.js","web/helpers.js","app/web_api.py","server.py"]
---

# SaaS workspace preview

Scope: separate copied custom web application; overview and two existing tool pages.
Mode: Operate. User confirmed a working dashboard, delegated visual choices, requested comfortable colors and separate source files. Build directly in the copied source; no persistent workflow default is inferred from this session.

## Direction contract

THESIS: A communication research workspace puts the next real task and an honest synthetic team snapshot in reach. Replace the oversized introduction with a compact, task-oriented SaaS shell.

OWN-WORLD: Quiet pale-gray canvas, white working surfaces, dark slate text, desaturated forest-green primary actions, subtle single-line boundaries, consistent 12px panels, system UI typography and a compact side rail. No gradients, ornamental hero, or fake activity.

STORY: The visitor identifies the workspace as a local demonstration, chooses a message review or team exploration, sees actual bundled survey values, and enters either existing workflow. Evidence and privacy disclosures remain available.

FIRST VIEWPORT: On desktop a 230px custom sidebar anchors brand/navigation; the main column has a slim breadcrumb and demo status, a 32px title, one-line description, two unequal task surfaces, and a real synthetic team snapshot with aligned hierarchy bars. At 587px and 390px the sidebar collapses and tasks stack without clipping. Primary message review is at the start of the task area. Signature interaction: a native HTML synthetic-team selector updates the overview profile; tool links navigate into the working pages. Controls transition in 160ms and respect reduced motion.

FORM: Research operations workspace, candidate 7, seed c50abd7d. Grounded candidates considered: meeting agenda, conversation notebook, survey report, evidence library, coaching desk, project issue tracker, research operations workspace. User-pinned professional SaaS intent and delegated choice govern the selection. Catalog challengers were declined for audience identification and product clarity: dense retail mosaic, lexicon apparatus, mascot roster, orienteering map, coded record sleeve, and strobing data field. Kept disciplines: dense but legible alignment, concise evidence references, consistent states, clear selection mapping, precise indexing, honest data scales. No challenger visual costume is imported.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

Open decisions: no published hosting, commercial claims, pricing, sign-in, or customer metrics are added. Existing model calls and suppression rules stay unchanged. No shipping raster assets are needed for this dashboard.


## Framework replacement

The user explicitly required removing Streamlit after seeing the first preview. The active site is custom semantic HTML/CSS/JavaScript with a Python ASGI API. server.py listens on loopback port 8502. Existing Python analysis/model engines are reused; Streamlit is neither imported nor served by this runtime. Navigation, forms, reporting, and exports are custom. The original source copy stays untouched.
