---
version: 1
slug: "marketing-site"
primary_target: "app/marketing_site.py"
related_targets: ["app/marketing_content.py", "web/marketing.css", "web/marketing.js", "web/pilot-form.js", "web/explorer.js", "web/alignment-data.js", "web/alignment-scenario.json", "app/web_api.py"]
---

# CommsAlign public website

Mode: Persuade. Scope: seven public pages, authored Alignment Explorer, preview pilot form and navigation into the preserved Workspace. The user explicitly chose marketing homepage + Workspace and supplied the implementation brief in docs/imported-implementation-brief.md. Build directly in the separate v2 source copy, as previously requested.

THESIS: Show how one ambiguous request can produce different expectations, then connect team investigation with a clearer managerial message. The fictional mechanism earns interest before a focused pilot invitation.

OWN-WORLD: The supplied brief pins warm off-white #F7F5EF, deep navy #162B3D, restrained teal #076D67, white working examples, Georgia editorial headings and system UI body text. Wide margins, thin rules, flat surfaces and quiet shifts in density create a calm professional site. No decorative AI imagery, invented commercial metrics, testimonials or production guarantees.

STORY: Start with the expectation gap; compare authored perspectives; investigate a fictional team pattern; confirm missing facts; read the assembled brief; consider a proposed evaluation. Supporting pages explain the workflow, intended audiences, evidence limitations and unconfirmed pilot terms. Existing tools remain accessible under /workspace.

FIRST VIEWPORT: At desktop widths, a compact horizontal brand/navigation row leads to a large editorial statement on the left and the original fictional request with two assumed interpretations on the right. Both a pilot CTA and an example CTA are visible. Mobile stacks the content with comfortable gutters and an expanding in-flow navigation. Signature interaction: the same canonical scenario powers the homepage and four-stage Explorer; reversible confirmations replace only known facts while leaving explicit prompts for unknown details. State changes preserve focus. Transitions are brief color changes, and reduced motion is respected.

FORM: User-pinned visual and narrative form from the supplied brief, sections 4–8; no unrequested concept selection replaces that specified world. This code-led implementation honors the user's instruction to work in copied code files. The authored scenario and typography carry the design; no raster assets or imitation physical materials are required.

FINISH: unreviewed and undocumented is unfinished; this build ends with the finish review, the verdict, DESIGN.md, and every shipping raster carrying its provenance

Truth constraints: the public demo is deterministic and makes no model/API calls; the diagnostic handoff is manual; evaluation is proposed. Pilot requests are preview-only and neither sent nor saved. Local pages remain noindex. Publication and a production enquiry service are outside this change.
