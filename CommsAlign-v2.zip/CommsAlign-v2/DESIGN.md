---
name: CommsAlign
description: A calm workspace for thoughtful workplace communication.
colors:
  "canvas": "#F6F8F7"
  "surface": "#FFFFFF"
  "rail": "#F0F3F1"
  "text": "#27372E"
  "muted": "#5C6B62"
  "border": "#E0E7E2"
  "border-strong": "#C9D5CC"
  "accent": "#315F4E"
  "accent-hover": "#254B3D"
  "sage": "#EDF4EF"
  "warning": "#755B26"
  "warning-bg": "#F8F3E8"
  "error": "#913F3D"
  "error-bg": "#FBF0EF"
  "profile-track": "#E9EEEA"
  "profile-fill": "#668A74"
  "tag-bg": "#EDF3EE"
  "tag-text": "#4D6654"
  "marketing-surface-page": "#F7F5EF"
  "marketing-surface-panel": "#FFFFFF"
  "marketing-surface-soft": "#ECEFEA"
  "marketing-ink": "#162B3D"
  "marketing-ink-secondary": "#536272"
  "marketing-action": "#076D67"
  "marketing-action-hover": "#055650"
  "marketing-action-ink": "#FFFFFF"
  "marketing-accent-soft": "#E7F1EE"
  "marketing-rule": "#CDD6D3"
  "marketing-focus": "#0C6FC4"
  "marketing-planned-ink": "#7A4A00"
  "marketing-planned-surface": "#FFF3DD"
  "marketing-error-ink": "#9A2525"
  "marketing-error-surface": "#FFF0EE"
typography:
  headline:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "1.875rem"
    fontWeight: 650
    lineHeight: 1.25
    letterSpacing: "-.025em"
  title:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "1.25rem"
    fontWeight: 620
    lineHeight: 1.4
    letterSpacing: "-.016em"
  body:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: ".875rem"
    lineHeight: 1.65
  label:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: ".77rem"
    fontWeight: 550
    lineHeight: 1.5
  help:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: ".7rem"
    fontWeight: 400
    lineHeight: 1.65
  button:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: ".8rem"
    fontWeight: 550
    lineHeight: 1.35
  marketing-display:
    fontFamily: "Georgia, \"Times New Roman\", serif"
    fontSize: "clamp(40px, 4.7vw, 72px)"
    fontWeight: 400
    lineHeight: 1.06
    letterSpacing: "-.035em"
  marketing-headline:
    fontFamily: "Georgia, \"Times New Roman\", serif"
    fontSize: "clamp(30px, 3.25vw, 48px)"
    fontWeight: 400
    lineHeight: 1.15
    letterSpacing: "-.025em"
  marketing-title:
    fontFamily: "Georgia, \"Times New Roman\", serif"
    fontSize: "clamp(22px, 2.1vw, 28px)"
    fontWeight: 400
    lineHeight: 1.25
    letterSpacing: "-.015em"
  marketing-body:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "18px"
    lineHeight: 1.65
  marketing-label:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "16px"
    fontWeight: 600
    lineHeight: 1.5
  marketing-help:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "14px"
    lineHeight: 1.65
  marketing-button:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "16px"
    fontWeight: 600
    lineHeight: 1.4
  marketing-message:
    fontFamily: "Georgia, \"Times New Roman\", serif"
    fontSize: "25px"
    lineHeight: 1.5
  marketing-explorer-title:
    fontFamily: "-apple-system, BlinkMacSystemFont, \"Segoe UI\", sans-serif"
    fontSize: "24px"
    fontWeight: 650
    lineHeight: 1.35
    letterSpacing: "-.01em"
  marketing-display-mobile:
    fontFamily: "Georgia, \"Times New Roman\", serif"
    fontSize: "clamp(36px, 8.8vw, 48px)"
    fontWeight: 400
    lineHeight: 1.08
    letterSpacing: "-.03em"
rounded:
  "meter": "3px"
  "tag": "5px"
  "evidence": "6px"
  "control": "7px"
  "disclosure": "8px"
  "panel": "12px"
  "marketing-control": "8px"
  "marketing-panel": "12px"
  "marketing-tag": "5px"
  "marketing-notice": "8px"
spacing:
  "8": "8px"
  "12": "12px"
  "16": "16px"
  "20": "20px"
  "24": "24px"
  "25": "25px"
  "32": "32px"
  "40": "40px"
  "marketing-1": "4px"
  "marketing-2": "8px"
  "marketing-3": "12px"
  "marketing-4": "16px"
  "marketing-5": "24px"
  "marketing-6": "32px"
  "marketing-7": "48px"
  "marketing-8": "64px"
  "marketing-9": "96px"
  "marketing-10": "128px"
components:
  button-primary:
    backgroundColor: "{colors.accent}"
    textColor: "{colors.surface}"
    typography: "{typography.button}"
    rounded: "{rounded.control}"
    padding: "10px 15px"
  button-primary-hover:
    backgroundColor: "{colors.accent-hover}"
    textColor: "{colors.surface}"
  button-secondary:
    backgroundColor: "{colors.surface}"
    textColor: "#3A5743"
    typography: "{typography.button}"
    rounded: "{rounded.control}"
    padding: "10px 15px"
  button-ghost:
    backgroundColor: "transparent"
    textColor: "#4D6754"
    typography: "{typography.button}"
    rounded: "{rounded.control}"
    padding: "10px 6px"
  field:
    backgroundColor: "{colors.surface}"
    textColor: "{colors.text}"
    rounded: "{rounded.control}"
    padding: "10px 12px"
  navigation:
    backgroundColor: "transparent"
    textColor: "#5C6B61"
    rounded: "{rounded.control}"
    padding: "11px 12px"
  navigation-active:
    backgroundColor: "#DFEAE1"
    textColor: "#2A523E"
  tag:
    backgroundColor: "{colors.tag-bg}"
    textColor: "{colors.tag-text}"
    rounded: "{rounded.tag}"
    padding: "4px 8px"
  panel:
    backgroundColor: "{colors.surface}"
    rounded: "{rounded.panel}"
  profile-meter:
    backgroundColor: "{colors.profile-track}"
    rounded: "{rounded.meter}"
    height: "7px"
  marketing-button-primary:
    backgroundColor: "{colors.marketing-action}"
    textColor: "{colors.marketing-action-ink}"
    typography: "{typography.marketing-button}"
    rounded: "{rounded.marketing-control}"
    padding: "12px 20px"
  marketing-button-primary-hover:
    backgroundColor: "{colors.marketing-action-hover}"
    textColor: "{colors.marketing-action-ink}"
  marketing-button-secondary:
    backgroundColor: "{colors.marketing-surface-panel}"
    textColor: "{colors.marketing-action}"
    typography: "{typography.marketing-button}"
    rounded: "{rounded.marketing-control}"
    padding: "12px 20px"
  marketing-button-secondary-hover:
    backgroundColor: "{colors.marketing-accent-soft}"
    textColor: "{colors.marketing-action-hover}"
  marketing-button-quiet:
    backgroundColor: "transparent"
    textColor: "{colors.marketing-ink}"
    typography: "{typography.marketing-button}"
    rounded: "{rounded.marketing-control}"
    padding: "12px 8px"
  marketing-field:
    backgroundColor: "{colors.marketing-surface-panel}"
    textColor: "{colors.marketing-ink}"
    rounded: "{rounded.marketing-control}"
    padding: "12px 14px"
  marketing-navigation:
    backgroundColor: "{colors.marketing-surface-page}"
    textColor: "{colors.marketing-ink}"
    padding: "12px 0"
  marketing-navigation-active:
    textColor: "{colors.marketing-action}"
  marketing-tag:
    backgroundColor: "{colors.marketing-accent-soft}"
    textColor: "{colors.marketing-action-hover}"
    rounded: "{rounded.marketing-tag}"
    padding: "5px 9px"
  marketing-tag-proposed:
    backgroundColor: "{colors.marketing-planned-surface}"
    textColor: "{colors.marketing-planned-ink}"
  marketing-panel:
    backgroundColor: "{colors.marketing-surface-panel}"
    rounded: "{rounded.marketing-panel}"
    padding: "30px"
  marketing-explorer-control:
    backgroundColor: "{colors.marketing-surface-panel}"
    textColor: "{colors.marketing-ink}"
    typography: "{typography.marketing-button}"
    rounded: "{rounded.marketing-control}"
    padding: "11px 17px"
  marketing-explorer-control-active:
    backgroundColor: "{colors.marketing-action}"
    textColor: "{colors.marketing-action-ink}"
  marketing-confirmation:
    backgroundColor: "{colors.marketing-surface-panel}"
    textColor: "{colors.marketing-ink}"
    rounded: "{rounded.marketing-control}"
    padding: "16px"
  marketing-confirmation-checked:
    backgroundColor: "{colors.marketing-accent-soft}"
---

# Design System: CommsAlign

## Overview

**Creative North Star: "Research operations workspace"**

The research operations workspace is quiet and task oriented: pale neutral surroundings, white working surfaces, forest-green actions, and readable green-slate text. Compact labels and restrained boundaries keep the emphasis on a draft, a survey value, or the next conversation.

This system describes the custom HTML/CSS/JavaScript interface served by the Python ASGI preview. It covers the shared shell, Message Coach, and Team Diagnostic. The SVG wordmark and consistent line icons provide identity without decorative imagery.

**Marketing expression: "Thoughtful management instrument"**

The public website adds the user-approved warm off-white, deep navy, and restrained teal world from the supplied implementation brief. Editorial Georgia headings, generous margins, thin rules, and readable native message examples make the experience calm and precise. It shares the Workspace's comfortable colors, flat surfaces, and explicit controls while giving public reading more space.

The two expressions coexist: unprefixed tokens remain the sage/forest Workspace system in `web/app.css`; `marketing-` tokens describe the public website in `web/marketing.css`. Namespaced marketing colors, radii, and spacing mirror that file's root custom properties; type and component roles capture its implemented selectors. Keep the existing SVG branding. Neither expression requires shipping raster imagery. Page composition and conversion strategy remain in `.impeccable/surfaces/marketing-site.md`.

**Key Characteristics:**

- Comfortable neutral and sage surfaces with one forest-green action accent.
- Compact UI typography and aligned numeric values.
- Flat, softly rounded working panels with single-line boundaries.
- Native form controls, disclosures, and visible keyboard focus.
- Warm editorial public pages with navy text and restrained teal actions.
- Readable message artifacts and explicit assumed, confirmed, and proposed states.
- Independent Workspace and marketing token scopes that preserve both approved expressions.

## Colors

A restrained forest accent sits among near-white, sage, and green-slate neutrals. Frontmatter values are the source of truth; the CSS custom properties in `web/app.css` supply the runtime primitives.

The marketing palette uses warm paper, deep navy, and restrained teal. Its `marketing-` frontmatter entries map to the corresponding unprefixed custom properties in `web/marketing.css`.

### Primary

- **Forest** (`accent`) identifies primary actions, links, carets, and keyboard focus; **Deep Forest** (`accent-hover`) handles hover.
- **Pale Sage** (`sage`) distinguishes the leading task panel. **Profile Sage** (`profile-fill`) fills the shared score bars.
- **Marketing Teal** and **Deep Marketing Teal** (`marketing-action`, `marketing-action-hover`) identify public actions, links, and selected Explorer controls. **Soft Teal** (`marketing-accent-soft`) marks confirmations and quiet hover states; **Action White** (`marketing-action-ink`) keeps filled controls readable.

### Neutral

- **Cool Canvas**, **White Surface**, and **Soft Rail** (`canvas`, `surface`, `rail`) separate the surrounding workspace, working panels, and navigation.
- **Green Slate** and **Muted Slate** (`text`, `muted`) carry reading and supporting text.
- **Fine Boundary** and **Strong Boundary** (`border`, `border-strong`) divide panels and the workspace identifier.
- **Profile Track**, **Tag Sage**, and **Tag Text** (`profile-track`, `tag-bg`, `tag-text`) support compact data and state presentation.
- **Warm Paper**, **Example White**, and **Quiet Gray-Green** (`marketing-surface-page`, `marketing-surface-panel`, `marketing-surface-soft`) separate public reading, work artifacts, and alternating sections. **Deep Navy**, **Slate Support**, and **Quiet Rule** (`marketing-ink`, `marketing-ink-secondary`, `marketing-rule`) carry text and structure. The closing public call to action reverses white text onto navy.

### State colors

Amber text on warm cream (`warning`, `warning-bg`) communicates caution. Muted red on pale rose (`error`, `error-bg`) communicates failure. These are functional state colors, not additional brand accents.

Marketing uses **Proposed Amber** on **Proposed Cream** (`marketing-planned-ink`, `marketing-planned-surface`) for proposed or unconfigured states, and **Error Red** on **Error Rose** (`marketing-error-ink`, `marketing-error-surface`) for validation errors. **Focus Blue** (`marketing-focus`) is reserved for the public keyboard outline; it remains separate from teal selection.

**The Visible Values Rule.** Keep the numeric label and the 1–5 scale alongside a score bar; its fill is a second reading of the value.

**The Named States Rule.** Pair state color with a readable label or explanation, as the notices and signal tags do.

## Typography

In the Workspace, one system UI stack serves the interface. The reusable roles are captured in frontmatter; there is no separate display face. Page headings use the headline role, panel headings use title or the smaller section treatment, and supporting copy uses body or help. The observed hierarchy is compact rather than promotional.

Page headings reduce to (1.625rem) below the mobile breakpoint, then (1.5rem) at the narrow breakpoint. Section headings use (1rem), with larger standalone sections where the source requires them. Tags, footer notes, and scale endpoints share a final size of (.6875rem). Numbers in score labels and summary values use tabular figures. Main explanatory copy is commonly limited to (65–78ch); page descriptions use (75ch).

### Marketing typography

Georgia with Times New Roman and serif fallbacks gives public headings their editorial character. The system UI stack handles body copy, navigation, native controls, and the Explorer's operational headings. Both stacks work without external font requests. Use the namespaced display, headline, and title roles for public h1, h2, and h3; their normal weight lets scale and spacing establish hierarchy. Body text uses the marketing body role and a (65ch) reading measure. Public field and button labels stay at (16px); notes, status labels, and disclosures stay at (14px).

At (639px) and below, use the marketing mobile display role; h2 becomes `clamp(30px, 7.3vw, 38px)`, h3 becomes (23px), and body text becomes (17px). At (359px) and below, h1 settles at (36px). Message examples use a readable serif quote treatment: the Explorer message role becomes (23px) on mobile, while hero/example quotes use (26px), reducing to (24px). Explorer headings use system sans rather than the editorial heading face. Numeric survey values use tabular figures.

**The Readable Artifact Rule.** Keep example messages, field values, and status notes at their real reading sizes; do not shrink a work artifact to imitate a product screenshot.

## Layout

The desktop shell has a fixed navigation rail (230px), a white top bar, and a flexible content column capped at (1400px). Default content padding is (30px 40px 26px). Tool, snapshot, context, and editor sections use unequal two-column grids; diagnostic summaries use four columns and signals use three. Repeated gaps and padding use the frontmatter spacing steps, with component-specific adjustments in the source.

At widths up to (1150px), the content becomes denser and summary/data grids use two columns. Between (768px) and (991px), the rail narrows to (205px), while tool, snapshot, and editor grids become single columns. At (767px) and below, a mobile header replaces the persistent rail; navigation becomes a (245px) drawer, primary working regions stack, and ordinary buttons have a minimum height of (44px). The content gutter becomes (19px), reducing to (16px) at (420px). Narrow screens also reduce data cards and report filters to one column. The body supports widths from (320px).

### Marketing layout

Public content is centered in a capped (1200px) container with (32px) minimum desktop gutters. Open editorial sections alternate with bounded message examples and the Explorer. Normal sections use (104px) vertical padding; the two-column hero uses a slightly wider text column, a (64px) gap, and (84px 96px) vertical padding. Reusable splits use equal columns, while audience and long workflow sections use unequal columns. Three-column reading groups use thin top rules rather than repeated enclosing cards. The root marketing spacing scale is recorded separately in frontmatter.

At (1440px) and above, the hero gap grows to (80px) and its top padding to (96px). At (1150px) and below, header and split spacing tighten. At (1023px) and below, gutters become (24px), the header becomes an expanding in-flow menu, split sections stack, and section padding becomes (80px). The hero and three-column groups stack at (767px); Explorer stage buttons become a two-column grid and confirmation controls become one column. At (639px), gutters become (20px), section padding becomes (64px), action rows become full width, form fields stack, and interpretation rows become field/value lists. At (359px), gutters reduce to (16px). The public body supports widths from (320px); wide status tables scroll inside their own wrapper.

Marketing panels normally use (30px) padding; the pilot form uses (38px). Both reduce progressively, reaching (22px) on mobile and (20px) on the narrowest screens. Keep supporting text and actions separated by the source's explicit vertical margins; section rhythm must survive when a link or button follows a paragraph directly.

## Elevation & Depth

Surfaces are flat. Tonal changes and thin borders create structure; neither resting cards nor their hover states use a lift effect. Floating toast feedback alone uses a soft shadow (`0 6px 24px #234C2C14`).

**The Tonal Separation Rule.** Use canvas, rail, white surfaces, and thin boundaries to distinguish working regions; panels do not need shadows.

Marketing is also flat: no card shadows, glass treatment, gradients, or hover lift. Warm paper, white artifacts, quiet gray-green sections, and thin rules create depth. The navy closing section is a tonal change rather than an elevated object. Keep this treatment separate from the Workspace's floating toast exception.

## Shapes

Working panels share the panel radius. Controls and navigation use the smaller control radius; disclosures and notices use the disclosure radius. Tags are compact rounded rectangles, rather than pills. Meter tracks use the smallest rounded form; only status dots and loading spinners are circular. Borders are single-pixel strokes. SVG line icons use rounded caps and joins, normally within an (18–20px) footprint.

Marketing panels use the namespaced panel radius; fields, buttons, checkable fact rows, and notice surfaces use the smaller marketing control/notice radius. Marketing tags retain a compact (5px) rounded rectangle. Boundaries are single-pixel strokes; fields and selectable controls keep visible strokes stronger than the quiet editorial divider. Public line icons use an (18–20px) footprint. Preserve the SVG wordmark rather than rendering the brand as a raster or a replacement glyph.

## Components

### Buttons

Primary buttons carry forest fill with white text. Secondary buttons use a white surface, green text, and a visible green-gray boundary. Ghost buttons are transparent with quieter text and reduced horizontal padding. A smaller variant reduces the default height and padding for compact actions. Hover changes color and boundary, without movement. Disabled controls use a pale gray-green fill and muted text; buttons stop accepting pointer interaction.

State transitions last (160ms) with `ease-out`. Keyboard focus uses a (2px) forest outline offset by (3px). The mobile drawer transitions over (180ms); the loading spinner rotates over (1s). The reduced-motion preference disables transitions and animation.

### Inputs / Fields

Native inputs, selects, and textareas share a white surface, thin green-gray border, and the control radius. Text fields and selects have a minimum height of (42px); textareas start at (150px) and resize vertically. Hover strengthens the boundary. Focus adds the forest boundary plus a soft translucent forest outline (2px, 1px offset). Disabled fields use the rail tone. Labels, help text, explicit error notices, and the consent checkbox stay visible next to their controls.

### Navigation

Named sidebar links pair consistent line icons with compact text. Hover adds a soft tonal fill; the current page uses a darker sage fill, stronger green text, and greater weight. Active routes expose `aria-current`. The mobile drawer includes a backdrop and a close button, supports Escape, and keeps keyboard focus inside while open. Diagnostic tabs use a forest underline and weight for selection; keyboard arrow, Home, and End navigation is implemented.

### Tags / Notices

Tags use a small-radius sage background and readable state text. Amber variants identify an area to explore. Notices use a larger-radius, bordered tinted surface and a full sentence; information, caution, error, and success remain distinct. Local-preview tags and status dots use the same restrained vocabulary.

### Panels / Disclosures

White panels use the shared radius and fine boundary. Headers and bodies commonly use (22–25px) padding, reducing on mobile. The leading task panel uses pale sage. Native details/summary disclosures keep supporting evidence available and rotate a small CSS chevron when open. Empty states use a dashed border and concise supporting text.

### Profile meters

A thin sage bar on a pale track accompanies an aligned label and tabular value. The fill maps the full score range: score (1) is empty and score (5) is full. The same meter pattern is used in team profiles and rubric results, with accessible meter values. No color threshold is implied by the fill.

### Marketing buttons and navigation

Public actions are comfortable and explicit. Teal primary buttons and white outlined secondary buttons share the marketing control shape, (12px 20px) padding, and a minimum height of (48px). Quiet actions remove the visible border and reduce horizontal padding to (8px). Hover changes color and boundary without movement. Disabled controls use the source's muted gray-green treatment. Color transitions last (180ms) with `ease-out`; public keyboard focus uses a (3px) blue outline offset by (4px). Reduced motion disables transitions, animations, and smooth scrolling.

Desktop navigation uses system text, real links, a visible Workspace entry, and a quiet teal underline for hover/current-page state. Below the public tablet breakpoint, the menu button reveals the same navigation in normal page flow and exposes its expanded state. Its target is at least (44px) square. This is independent of the Workspace drawer.

### Marketing fields and status disclosures

Public native fields use white backgrounds, visible green-gray boundaries, (12px 14px) padding, and (16px) text. Inputs and selects have a minimum height of (48px); textareas start at (140px) and resize vertically. Hover strengthens the border to teal; focus uses the public blue outline and border. Labels and helper text remain adjacent. Invalid controls use red borders, nearby explanations, and a linked error summary. The preview result is a bordered soft-teal notice; proposed/unconfigured notices use amber on cream and state their meaning in text.

The pilot form groups fields in two columns before stacking on mobile. Its preview notice and locally validated result stay visible. Native FAQ disclosures use a thin rule, a readable summary, and a minimum summary height of (48px). Status tags use a compact tint plus explicit wording; color alone never distinguishes fictional, confirmed, or proposed content.

### Alignment Explorer and message artifacts

White, bordered message artifacts carry real text, not image-based mockups. Serif requests and assembled briefs sit alongside sans-serif labels, ruled interpretation rows, and explicit assumed/confirmed notes. Role and stage buttons use outlined white controls, with teal fill and `aria-pressed` for selection; they keep their shape and position when state changes. Role controls start at a minimum (46px) height; four stage buttons use (64px), reducing to (55px) on mobile.

Confirmed-detail controls are native (20px) checkboxes inside labeled rows with a minimum height of (64px), (16px) padding, and a soft-teal checked surface. Interpretation rows use label/value columns on desktop and stack on mobile; confirmation adds both a tint and a written state. The shared brief remains selectable text. A visible count describes confirmed details, while proposed evaluation uses a separate amber surface. State updates preserve focus and communicate a short textual update.

## Do's and Don'ts

### Do:

- Do use the shared panel radius, thin boundaries, and white or sage working surfaces.
- Do preserve native controls, readable labels, keyboard focus, and reduced-motion behavior.
- Do retain the numeric values, full score scales, and textual state explanations.
- Do keep the Workspace's existing tokens and use the `marketing-` namespace for the warm public website.
- Do use Georgia for public editorial headings and readable messages, with system text for public controls and Explorer headings.
- Do retain visible assumed, confirmed, fictional, proposed, preview, error, and focus states alongside their color treatments.

### Don't:

- Don't use panel shadows to create the main hierarchy; reserve the documented shadow for floating feedback.
- Don't make score fills or status colors the only source of meaning.
- Don't replace the SVG brand or named navigation with decorative glyphs or unnamed controls.
- Don't add decorative AI imagery, glowing gradients, glass panels, or miniature dashboard text to the marketing world.
- Don't turn public reading sections into endless equal-sized enclosed feature cards; use open space, thin rules, and focused work artifacts.
- Don't replace native Explorer controls or readable message text with a screenshot of the interaction.
