"""Public content stays readable, fictional, and separate from the working tools."""
from html import unescape
from html.parser import HTMLParser
from pathlib import Path

import pytest
from starlette.testclient import TestClient

from app.web_api import create_app

ROOT = Path(__file__).resolve().parents[1]
PUBLIC_ROUTES = ('/', '/how-it-works', '/demo', '/solutions', '/research', '/pricing', '/request-pilot')


class Page(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.headings = 0
        self.fields = {}
        self.links = []
        self.scripts = []
        self.meta = {}
        self.mounts = []
        self.feed(html)

    def handle_starttag(self, tag, attributes):
        attrs = dict(attributes)
        if tag == 'h1':
            self.headings += 1
        if tag in ('input', 'select', 'textarea') and attrs.get('name'):
            self.fields[attrs['name']] = attrs
        if tag == 'a':
            self.links.append(attrs.get('href', ''))
        if tag == 'script':
            self.scripts.append(attrs)
        if tag == 'meta' and attrs.get('name'):
            self.meta[attrs['name']] = attrs.get('content', '')
        if 'data-explorer-view' in attrs:
            self.mounts.append(attrs['data-explorer-view'])


@pytest.fixture
def client():
    with TestClient(create_app(), base_url='http://127.0.0.1') as browser:
        yield browser


def test_all_public_routes_have_server_rendered_copy_metadata_and_real_destinations(client):
    descriptions = set()
    for route in PUBLIC_ROUTES:
        response = client.get(route)
        assert response.status_code == 200
        assert 'text/html' in response.headers['content-type']
        page = Page(response.text)
        assert page.headings == 1, route
        assert '/request-pilot' in page.links
        assert '/workspace' in page.links
        assert '#' not in page.links
        assert 'noindex' in page.meta.get('robots', '')
        description = page.meta.get('description', '')
        assert len(description) > 30
        descriptions.add(description)
        scripts = {script.get('src') for script in page.scripts}
        assert '/app.js' not in scripts and '/coach.js' not in scripts
        assert response.headers['x-robots-tag'] == 'noindex, nofollow'
    assert len(descriptions) == len(PUBLIC_ROUTES)


def test_home_and_demo_have_shared_native_fixture_and_readable_fallback(client):
    original = 'Can you get the report ready ASAP? We need it for leadership.'
    completed = "Please prepare the November revenue report with regional totals for leadership's monthly revenue review by Friday at 2 PM. Send a draft Thursday at 3 PM so we can review it together."
    for route, mounts in (('/', {'perspectives', 'coach'}), ('/demo', {'full'})):
        response = client.get(route)
        text = unescape(response.text)
        assert original in text
        assert completed in text
        assert 'explorer-fallback' in text
        assert 'alignment-scenario' in text
        assert set(Page(text).mounts) == mounts
        for role in ('Manager', 'Team member', 'Stakeholder'):
            assert role in text
        assert 'fictional' in text.lower()


def test_public_demo_and_preview_form_modules_cannot_contact_private_tools():
    for name in ('explorer.js', 'alignment-data.js', 'marketing.js', 'pilot-form.js'):
        source = (ROOT / 'web' / name).read_text()
        for forbidden in ('fetch(', 'XMLHttpRequest', 'sendBeacon', 'WebSocket', '/api/diagnostic', '/api/message'):
            assert forbidden not in source, (name, forbidden)
    form_source = (ROOT / 'web/pilot-form.js').read_text()
    assert 'localStorage' not in form_source and 'sessionStorage' not in form_source


def test_pilot_is_explicitly_preview_and_fields_have_bounds_and_labels(client):
    response = client.get('/request-pilot')
    assert 'Preview form' in response.text
    assert 'requests are not being sent' in response.text
    assert 'Preview request' in response.text
    page = Page(response.text)
    for name, limit in (('name', 100), ('email', 254), ('organization', 150), ('role', 100), ('challenge', 1500)):
        assert page.fields[name]['id'] == f'pilot-{name}'
        assert int(page.fields[name]['maxlength']) == limit
        assert f'for="pilot-{name}"' in response.text
    for name in ('name', 'email', 'organization'):
        assert 'required' in page.fields[name]
    assert 'team_size' in page.fields
    assert client.post('/api/pilot-request', json={'name': 'No real contact'}).status_code in (404, 405)


def test_research_distinguishes_authored_demo_and_current_conditional_product(client):
    response = client.get('/research')
    text = unescape(response.text).lower()
    assert 'product-status' in response.text
    assert 'azure' in text and 'consent' in text
    assert 're-scor' in text
    assert 'authored' in text
    assert 'proposed' in text and 'manual' in text
    assert 'not implemented' in text  # Handoff/measurement are not silently promoted.


def test_sitemap_uses_actual_preview_origin_and_unknown_pages_are_useful(client):
    assert 'Disallow: /' in client.get('/robots.txt').text
    sitemap = client.get('/sitemap.xml')
    assert sitemap.status_code == 200
    for path in PUBLIC_ROUTES:
        assert f'<loc>http://127.0.0.1{path}</loc>' in sitemap.text
    missing = client.get('/page-that-does-not-exist')
    assert missing.status_code == 404
    assert 'text/html' in missing.headers['content-type']
    assert 'CommsAlign' in missing.text and 'href="/"' in missing.text
    assert client.get('/.env').status_code == 404
    assert client.get('/app/web_api.py').status_code == 404


def test_existing_workspace_is_preserved_under_its_own_namespace(client):
    for route in ('/workspace', '/workspace/message-coach', '/workspace/team-diagnostic'):
        response = client.get(route)
        assert response.status_code == 200
        assert 'id="route-view"' in response.text
        assert 'src="/app.js"' in response.text
        assert 'href="/workspace/message-coach"' in response.text
