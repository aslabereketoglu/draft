/** Optional developer check: import this module and call runAlignmentStateTests(). */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { SCENARIO, STAGES, PERSPECTIVES, DETAILS, configureScenario, initialState, normalizeState, interpretation, deriveBrief, transition } from '../web/alignment-data.js';

export function runAlignmentStateTests() {
  const authored = JSON.parse(readFileSync(new URL('../web/alignment-scenario.json', import.meta.url), 'utf8'));
  configureScenario(authored);
  assert.notEqual(SCENARIO, authored);
  assert(Object.isFrozen(SCENARIO.confirmed));
  assert.deepEqual(initialState(), {stage:'expectations',perspective:'manager',confirmedDetails:[],discussionFindingOpen:false});
  const empty = deriveBrief(initialState());
  for (const phrase of ['[deliverable to confirm]','[deadline to confirm]','[purpose to confirm]','[check-in to confirm]']) assert(empty.includes(phrase));
  assert(!empty.includes('Friday') && !empty.includes('Thursday'));

  let combinations = 0;
  for (let mask = 0; mask < 16; mask++) {
    let state = initialState();
    for (let index = 0; index < DETAILS.length; index++) if (mask & (1 << index)) state = transition(state, {type:'confirm',detail:DETAILS[index],confirmed:true});
    for (const role of PERSPECTIVES) {
      const selected = transition(state, {type:'perspective',value:role});
      const rows = interpretation(selected);
      assert.equal(rows.length, 4);
      for (const row of rows) {
        const confirmed = state.confirmedDetails.includes(row.detail);
        assert.equal(row.value, confirmed ? authored.confirmed[row.detail] : authored.perspectives[role][row.detail]);
        assert.equal(row.basis, confirmed ? 'Confirmed in this example' : 'Assumed');
        assert.equal(row.confirmed, confirmed);
      }
      const brief = deriveBrief(selected);
      for (const detail of DETAILS) {
        const placeholder = `[${detail === 'checkin' ? 'check-in' : detail} to confirm]`;
        assert.equal(brief.includes(placeholder), !state.confirmedDetails.includes(detail));
      }
      if (mask === 15) assert.equal(brief, "Please prepare the November revenue report with regional totals for leadership's monthly revenue review by Friday at 2 PM. Send a draft Thursday at 3 PM so we can review it together.");
      assert.equal(deriveBrief(selected), deriveBrief(state), 'Perspective changes must never invent or alter confirmed facts.');
      combinations++;
    }
  }

  let complete = initialState();
  for (const detail of DETAILS) complete = transition(complete, {type:'confirm',detail,confirmed:true});
  assert.equal(deriveBrief(complete), authored.completedBrief);
  for (const detail of DETAILS) {
    const undone = transition(complete, {type:'confirm',detail,confirmed:false});
    assert.equal(undone.confirmedDetails.length, 3);
    assert.equal(complete.confirmedDetails.length, 4, 'Transitions must not mutate the previous state.');
    for (const role of PERSPECTIVES) {
      const row = interpretation(undone, role).find(row => row.detail === detail);
      assert.equal(row.value, authored.perspectives[role][detail]);
      assert.equal(row.basis, 'Assumed');
    }
  }
  let traversed = transition(complete, {type:'perspective',value:'team'});
  traversed = transition(traversed, {type:'finding',open:true});
  for (const stage of STAGES) {
    traversed = transition(traversed, {type:'stage',value:stage});
    assert.equal(traversed.stage, stage);
    assert.equal(traversed.perspective, 'team');
    assert.equal(traversed.discussionFindingOpen, true);
    assert.deepEqual(traversed.confirmedDetails, DETAILS);
  }
  assert.deepEqual(transition(traversed, {type:'reset'}), initialState());

  const badStates = [null, false, {}, [], {stage:'invalid'}, {...initialState(),perspective:'employee'}, {...initialState(),stage:'ai-results'}, {...initialState(),confirmedDetails:['secret']}, {...initialState(),confirmedDetails:'all'}, {...initialState(),discussionFindingOpen:'yes'}];
  for (const bad of badStates) assert.deepEqual(normalizeState(bad), initialState());
  assert.deepEqual(normalizeState({...initialState(),confirmedDetails:['deadline','deadline']}), {...initialState(),confirmedDetails:['deadline']});
  for (const action of [null, {}, {type:'stage',value:'other'}, {type:'perspective',value:'other'}, {type:'confirm',detail:'other',confirmed:true}, {type:'confirm',detail:'deadline',confirmed:'yes'}]) assert.deepEqual(transition(complete,action), complete);

  const uiSource = readFileSync(new URL('../web/explorer.js', import.meta.url), 'utf8');
  assert(!/\bfetch\s*\(|XMLHttpRequest|WebSocket|\/api\//.test(uiSource), 'The public demonstration must not call an API or model.');
  return {passed:true, confirmationPerspectiveCombinations:combinations, undoAcrossRoles:12, stagePersistenceChecks:STAGES.length, invalidStateChecks:badStates.length, scenarioId:authored.id};
}
