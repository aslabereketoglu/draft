"""Privacy, consent, and truthful-export boundaries of the custom local API."""
from dataclasses import asdict

import pytest
from starlette.testclient import TestClient

from app import web_api
from app.organizational.analyzer import analyze_csv
from app.tool1.judge import JudgeResult


@pytest.fixture
def client():
    with TestClient(web_api.create_app(), base_url="http://127.0.0.1") as browser:
        yield browser


def test_diagnostic_uses_existing_scores_and_exports_only_the_selected_team(client):
    reports = analyze_csv(web_api.SAMPLE_PATH)
    listing = client.get("/api/teams").json()
    assert listing == {
        "teams": [{"team_id": r.team_id, "period": r.period, "suppressed": r.suppressed} for r in reports],
        "minimum_responses": 5,
    }
    report = reports[1]
    response = client.get("/api/diagnostic", params={"team_id": report.team_id})
    assert response.status_code == 200
    payload = response.json()
    assert payload["grand_mean"] == report.grand_mean
    assert payload["hierarchy_scores"] == report.hierarchy_scores
    assert payload["strengths"] == [asdict(record) for record in report.strengths]
    assert payload["opportunities"] == [asdict(record) for record in report.opportunities]
    assert payload["communication_signals"] == [
        {**asdict(signal), "manager_questions": list(signal.manager_questions)}
        for signal in report.communication_signals
    ]
    assert report.team_id in payload["download_text"]
    assert all(other.team_id not in payload["download_text"] for other in reports if other.team_id != report.team_id)
    assert web_api.SYNTHETIC_LABEL in payload["download_text"]
    assert "No causal inference is performed." in payload["download_text"]
    assert "Missing items are not imputed" in payload["download_text"]
    assert len(payload["evidence"]) == 9
    assert response.headers["cache-control"] == "no-store"


def test_suppression_whitelists_metadata_and_never_returns_diagnostics_or_exports(client):
    response = client.get("/api/diagnostic?minimum_responses=10000")
    assert response.status_code == 200
    payload = response.json()
    assert set(payload) == {"team_id", "period", "suppressed", "minimum_responses", "limitations", "synthetic"}
    assert payload["suppressed"] is True
    assert payload["minimum_responses"] == 10000
    assert any("suppressed" in message for message in payload["limitations"])
    assert "download_text" not in payload
    assert "communication_signals" not in payload


@pytest.mark.parametrize("threshold", ["0", "-1", "1.5", "NaN", "true", "1000001", "9" * 100])
def test_invalid_reporting_thresholds_are_rejected(client, threshold):
    response = client.get("/api/diagnostic", params={"minimum_responses": threshold})
    assert response.status_code == 400
    assert set(response.json()) == {"error"}


@pytest.mark.parametrize("change", [
    {"consent": False}, {"consent": "true"}, {"draft": "  "}, {"draft": None},
    {"kind": "invented"}, {"kind": []},
])
def test_review_and_rescore_never_invoke_model_without_valid_explicit_consent(client, monkeypatch, change):
    def forbidden(*args, **kwargs):
        raise AssertionError("No settings or model work is allowed for invalid input")
    monkeypatch.setattr(web_api, "perform_message_request", forbidden)
    data = {"draft": "Please submit your report by Friday.", "kind": "task_instruction", "consent": True}
    data.update(change)
    for path in ("/api/message/review", "/api/message/rescore"):
        response = client.post(path, json=data)
        assert response.status_code == 400
        assert set(response.json()) == {"error"}


def test_missing_configuration_is_actionable_and_does_not_leak_settings(client, monkeypatch):
    from app.tool1 import config
    def missing():
        raise RuntimeError("SECRET_ENDPOINT_AND_KEY")
    monkeypatch.setattr(config, "load_settings", missing)
    response = client.post("/api/message/review", json={
        "draft": "Please submit your report by Friday.", "kind": "task_instruction", "consent": True,
    })
    assert response.status_code == 503
    assert "GW Azure settings are missing" in response.json()["error"]
    assert "SECRET_ENDPOINT_AND_KEY" not in response.text


def test_successful_reviews_return_the_existing_pipeline_and_rescore_outputs(client, monkeypatch):
    from app.tool1 import config, pipeline
    monkeypatch.setattr(config, "load_settings", lambda: None)
    judgment = JudgeResult("task_instruction", "task_instruction_v1.2", True, False, None,
                           {}, "borderline", None, "low", "Test fixture only")
    calls = []
    def run(draft, kind):
        calls.append((draft, kind))
        return pipeline.PipelineResult(judgment, None, None)
    monkeypatch.setattr(pipeline, "run", run)
    monkeypatch.setattr(pipeline, "rescore", lambda draft, kind: judgment)
    data = {"draft": "Please submit the report by Friday.\nThank you.", "kind": "task_instruction", "consent": True}
    response = client.post("/api/message/review", json=data)
    assert response.status_code == 200
    assert response.json() == {
        "draft": data["draft"], "kind": data["kind"], "result": asdict(judgment),
        "rewrite": None, "after": None,
    }
    assert calls == [(data["draft"], data["kind"])]
    assert client.post("/api/message/rescore", json=data).json() == asdict(judgment)


def test_upstream_error_has_no_secret_details_or_substituted_result(client, monkeypatch):
    from app.tool1 import config, pipeline
    monkeypatch.setattr(config, "load_settings", lambda: None)
    def fail(*args):
        raise RuntimeError("SECRET_ENDPOINT_AND_KEY")
    monkeypatch.setattr(pipeline, "run", fail)
    response = client.post("/api/message/review", json={
        "draft": "Please submit your report by Friday.", "kind": "task_instruction", "consent": True,
    })
    assert response.status_code == 502
    assert set(response.json()) == {"error"}
    assert "SECRET_ENDPOINT_AND_KEY" not in response.text
    assert "No result has been substituted" in response.json()["error"]


def test_json_and_draft_size_bounds_are_enforced_before_model_work(client, monkeypatch):
    monkeypatch.setattr(web_api, "perform_message_request", lambda *args, **kwargs: pytest.fail("Unexpected model work"))
    assert client.post("/api/message/review", content="not JSON", headers={"content-type": "application/json"}).status_code == 400
    assert client.post("/api/message/review", data={"consent": "true"}).status_code == 415
    assert client.post("/api/message/review", content="x" * (web_api.MAX_JSON_BYTES + 1),
                       headers={"content-type": "application/json"}).status_code == 413
    assert client.post("/api/message/review", json={
        "draft": "x" * (web_api.MAX_DRAFT_CHARACTERS + 1), "kind": "task_instruction", "consent": True,
    }).status_code == 413


def test_discussion_export_preserves_saved_notes_separation_and_suppression(client):
    report = analyze_csv(web_api.SAMPLE_PATH)[0]
    item = report.communication_signals[0].source_q12_item
    data = {
        "team_id": report.team_id, "period": report.period, "minimum_responses": 5, "item": item,
        "notes": {"observations": "TEAM INPUT", "reflection": "MANAGER VIEW", "decision": "No action for now"},
    }
    response = client.post("/api/discussion/export", json=data)
    assert response.status_code == 200
    text = response.json()["text"]
    assert text.index("Employee observations") < text.index("TEAM INPUT") < text.index("Manager reflection") < text.index("MANAGER VIEW")
    assert "No action for now" in text
    assert "not verified by the tool" in text
    assert "No next-step details recorded." in text
    # Requests do not persist notes on the backend.
    assert "TEAM INPUT" not in client.post("/api/discussion/export", json={**data, "notes": {}}).json()["text"]
    suppressed = client.post("/api/discussion/export", json={**data, "minimum_responses": 10000})
    assert suppressed.status_code == 403
    assert set(suppressed.json()) == {"error"}
    assert "TEAM INPUT" not in suppressed.text
    assert client.post("/api/discussion/export", json={**data, "notes": {"decision": "Invented"}}).status_code == 400
    assert client.post("/api/discussion/export", json={**data, "item": "Q00"}).status_code == 400


def test_local_host_and_origin_are_required_and_cors_is_not_enabled(client):
    assert client.get("/api/teams", headers={"host": "example.com"}).status_code == 403
    assert client.get("/api/teams", headers={"origin": "https://example.com"}).status_code == 403
    blocked = client.post("/api/message/review", json={}, headers={"sec-fetch-site": "cross-site"})
    assert blocked.status_code == 403
    valid = client.get("/api/health", headers={"origin": "http://127.0.0.1"})
    assert valid.status_code == 200
    assert "access-control-allow-origin" not in valid.headers


def test_spa_routes_and_assets_are_served_without_exposing_project_files(client, monkeypatch, tmp_path):
    monkeypatch.setattr(web_api, "WEB_ROOT", tmp_path)
    (tmp_path / "index.html").write_text("<!doctype html><title>CommsAlign</title>")
    (tmp_path / "app.js").write_text("console.log('CommsAlign');")
    for path in ("/workspace", "/workspace/message-coach", "/workspace/team-diagnostic"):
        response = client.get(path)
        assert response.status_code == 200 and "<title>CommsAlign</title>" in response.text
    for path in ("/message-coach", "/team-diagnostic"):
        response = client.get(path, follow_redirects=False)
        assert response.status_code == 307 and response.headers["location"] == "/workspace" + path
    assert client.get("/app.js").status_code == 200
    assert client.get("/.env").status_code == 404
    assert client.get("/requirements-web.txt").status_code == 404
    assert client.get("/api/diagnostic?team_id=unknown").status_code == 404
