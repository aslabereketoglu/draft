@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto use_python
py -3 launch.py
goto finished
:use_python
where python >nul 2>nul
if errorlevel 1 goto missing_python
python launch.py
goto finished
:missing_python
echo Install Python 3.11 or newer and enable Add Python to PATH. See START_HERE.md.
pause
exit /b 1
:finished
if errorlevel 1 pause
