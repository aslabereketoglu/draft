"""Run the separate custom CommsAlign interface on this computer only."""
import argparse

import uvicorn

from app.web_api import app


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8502, help="Local port (default: 8502)")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("Port must be between 1 and 65535.")
    uvicorn.run(app, host="127.0.0.1", port=args.port, access_log=False, log_level="warning")
