"""Prepare and launch a portable local copy of CommsAlign v2."""
from __future__ import annotations

import hashlib
from pathlib import Path
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import venv
import webbrowser

ROOT = Path(__file__).resolve().parent
URL = "http://127.0.0.1:8502/"


def main() -> int:
    if sys.version_info < (3, 11):
        print("Please install Python 3.11 or newer, then try again.")
        return 1
    with socket.socket() as probe:
        if probe.connect_ex(("127.0.0.1", 8502)) == 0:
            print("Port 8502 is already in use. Stop the other preview and try again.")
            return 1

    environment = ROOT / ".venv"
    executable = environment / ("Scripts/python.exe" if sys.platform == "win32" else "bin/python")
    if not executable.is_file():
        print("Preparing your local Python environment…", flush=True)
        venv.EnvBuilder(with_pip=True).create(environment)
    requirements = ROOT / "requirements-web.txt"
    fingerprint = hashlib.sha256(requirements.read_bytes()).hexdigest()
    marker = environment / ".commsalign-requirements"
    if not marker.is_file() or marker.read_text().strip() != fingerprint:
        print("Installing the required packages. First setup needs internet access…", flush=True)
        subprocess.run([str(executable), "-m", "pip", "install", "-r", str(requirements)], cwd=ROOT, check=True)
        marker.write_text(fingerprint)

    print(f"CommsAlign v2: {URL}\nKeep this window open. Press Ctrl+C to stop.", flush=True)
    server = subprocess.Popen([str(executable), "server.py", "--port", "8502"], cwd=ROOT)

    def open_when_ready() -> None:
        for _ in range(60):
            if server.poll() is not None:
                return
            try:
                with urllib.request.urlopen(URL, timeout=1) as response:
                    if response.status == 200:
                        webbrowser.open(URL)
                        return
            except (OSError, urllib.error.URLError):
                pass
            time.sleep(0.5)

    threading.Thread(target=open_when_ready, daemon=True).start()
    try:
        return server.wait()
    except KeyboardInterrupt:
        server.terminate()
        try:
            server.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server.kill()
            server.wait()
        return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, subprocess.CalledProcessError) as error:
        print(f"Setup could not finish: {error}\nSee START_HERE.md for manual instructions.")
        raise SystemExit(1)
