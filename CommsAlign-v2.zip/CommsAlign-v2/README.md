# CommsAlign v2

This folder is CommsAlign v2: a public marketing website, a fictional interactive
example, and the existing tools under **Workspace**. See [PREVIEW.md](PREVIEW.md)
for local addresses and restart instructions. The original source remains in `../urmom`.

The homepage follows the supplied website brief, retained in
`docs/imported-implementation-brief.md`. Public pages cover the approach, an
Alignment Explorer demo, proposed pilot audiences, research, pricing enquiries,
and a preview-only pilot form. The form sends and saves nothing. This is a local,
unpublished preview, marked noindex. See [README_V2.md](README_V2.md) for the
current feature guide and manual GitHub upload instructions.

A shared workplace communication prototype with **Tool 1 — Message Coach** and
**Tool 2 — Team Diagnostic**. Survey interpretations and message ratings are
provisional, not validated diagnoses. Tool 2 currently uses synthetic inputs.

## Run v2 locally

```sh
python3 -m venv .venv
.venv/bin/pip install -r requirements-web.txt
.venv/bin/python server.py --port 8502
```

Use Python 3.11 for a new hosted environment. Tool 2 needs no API credentials.
Tool 1 requires the GW Azure settings in a local `.env` file (see `.env.example`)
or private deployment secrets. Never commit credentials. No real model request
is made until a user submits a draft with consent. The current v2 source supports
suggested revisions and re-scoring when configured; live model operation was not
validated during this website work. The cross-tool handoff remains manual.

Open http://127.0.0.1:8502 for the marketing homepage. The working tools are at
`/workspace/message-coach` and `/workspace/team-diagnostic`; `/workspace` is their
overview. The older `/message-coach` and `/team-diagnostic` addresses redirect.

## Review and collaboration

See [sharing and deployment](docs/SHARING.md),
[integration notes](docs/TOOL1_TOOL2_INTEGRATION.md),
[Tool 2 demo guide](docs/TOOL2_DEMO_GUIDE.md), and
[evidence limitations](data/organizational/evidence_review_followup.md).

Run tests with `.venv/bin/python -m pytest -q`. Work on a separate branch and
submit a pull request; do not upload credentials, identifiable discussion notes,
or private survey data. The README below describes the earlier standalone local
personal-use engine, which is separate from the imported Tool 1 judge.

---

# AlignAgent personal-use prototype

A local, rule-based minimum viable prototype for workplace communication review.
All six dimensions and scoring rules are **provisional, configurable, and not
scientifically validated**. There are no research citations, LLM calls, external
services, or organizational-agent features. Inputs are not saved by the program.

## Run

Use Python 3.9 or later. Open this standalone project folder:

```sh
cd /Users/velaphi/Documents/alignagent
python3 -m app.main
```

Enter a multiline message, finish with a blank line, then optionally supply the
audience and purpose. For a reproducible noninteractive example:

```sh
python3 -m app.main --text "Please review the proposal and send your feedback by Friday. Thanks." --audience "Project team" --purpose "Review the proposal"
```

The report includes each dimension, a 1–5 score, explanation, improvement
suggestion, overall summary, and a suggested revised communication template.
The revision preserves the original wording and adds editable placeholders; it
does not invent owners, deadlines, facts, or a semantic rewrite.

## Architecture

`main.py` collects input → `agents/personal_agent.py` orchestrates review →
`evaluation/rubric.py` runs configurable scoring functions →
`reports/report_generator.py` formats results and the revision template.

`rag/retriever.py` reserves a boundary for future retrieval-augmented generation
(RAG). Calling it currently raises `NotImplementedError`; it is not part of the
prototype execution path. `data/research/` is reserved for permitted, verified
research sources. No evidence has been loaded.

## Temporary rubric

| Dimension | Placeholder signals |
| --- | --- |
| Clarity | Sentence length, vague tokens, extremely short text. |
| Consistency | Selected opposing-term pairs; no logical reasoning. |
| Audience alignment | Neutral 3; audience suitability is not assessed. |
| Purpose alignment | Keyword overlap with author-provided purpose. |
| Actionability | Action terms, owner pronouns, timing terms. |
| Tone appropriateness | Courtesy words, flagged insults, uppercase emphasis. |

Missing context uses a neutral 3 and an explicit explanation. The overall score
is a weighted mean, not an empirical measure. Token rules can misread quotations,
negation, acronyms, context, and informational messages. A high score does not
establish quality or safety; author review remains necessary.

Configure dimensions in Python by passing `Dimension(name, scorer, weight)`
objects to `Rubric(dimensions=...)`, then pass the rubric to `PersonalAgent`.
Each scorer receives text and `CommunicationContext`, and returns an integer
score from 1 to 5, explanation, and suggestion. Weights must be finite and
positive. Dimensions can be replaced or removed without changing the agent or
report renderer. A future evidence matrix should determine the final rules.

## Tests

The runtime needs no third-party packages. Install pytest in a virtual
environment inside this folder if needed:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m pytest -q -p no:cacheprovider
```

Or use an existing interpreter with pytest installed:

```sh
python3 -m pytest -q -p no:cacheprovider
```

## Next development steps

1. Curate verified sources and an evidence matrix linking dimensions to evidence.
2. Define scoring anchors, applicability rules, and explicit unknown scores.
3. Create consented examples and independent human labels; evaluate agreement
   and failure cases on held-out communications.
4. Replace placeholder rules with evidence-supported scoring and implement
   traceable retrieval only after source permissions and quality are reviewed.
5. Improve revisions while preserving author intent; evaluate before considering
   an LLM integration. Keep organizational-agent development outside this MVP.
