#!/bin/zsh
cd -- "${0:A:h}" || exit 1
if ! command -v python3 >/dev/null 2>&1; then
  echo "Install Python 3.11 or newer, then open this file again. See START_HERE.md."
  read -r "reply?Press Return to close."
  exit 1
fi
python3 launch.py
result=$?
if [ "$result" -ne 0 ]; then
  read -r "reply?Press Return to close."
fi
exit "$result"
