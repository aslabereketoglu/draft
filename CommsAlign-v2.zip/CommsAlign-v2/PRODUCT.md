# CommsAlign

<!-- impeccable:product-schema 1 -->

## Platform

web

## Product Purpose

CommsAlign is a workplace communication prototype with Message Coach and Team Diagnostic. Its public website introduces the approach through an authored fictional example. The separate Workspace retains the working tools. The active v2 preview uses custom HTML/CSS/JavaScript and a Python ASGI API, reusing the existing analysis and review engines.

## Users

The Workspace serves managers and team members reviewing drafts or exploring aggregate survey signals. The supplied marketing brief proposes People and HR leaders, managers, and operational teams as pilot audiences; these are intended audiences, not verified customers.

## Operating Context

The active v2 preview runs from server.py at http://127.0.0.1:8502. The user confirmed a marketing homepage with the existing tools under a Workspace link. Public routes are /, /how-it-works, /demo, /solutions, /research, /pricing and /request-pilot. The tools live at /workspace, /workspace/message-coach and /workspace/team-diagnostic. Earlier tool URLs redirect to the new locations. No published deployment is verified. Work remains in the separate urmom-v2 source copy; the original ../urmom application is unchanged.

## Capabilities and Constraints

- Message Coach supports task instructions and performance feedback. Evaluation requires explicit consent and configured GW Azure settings. It can produce a suggested revision, re-score, and export results. Model requests stay behind the existing submission flow.
- Team Diagnostic uses bundled synthetic aggregate survey data. Reporting thresholds suppress entire team/period reports when an item fails. Notes stay within the current session and remain scoped to team, period, and signal.
- Scores, mappings, and interpretations are provisional. Survey results do not establish causes. No real customer data, validated outcomes, pricing, testimonials, accounts, or collaboration infrastructure may be implied by the redesign.
- Retain functional navigation, downloads, reporting rules, missing-data explanations, evidence disclosures, and keyboard-accessible native controls.
- Alignment Explorer uses one authored fictional fixture. Its four stages, role assumptions, reversible fact confirmations and assembled brief make no API or model calls. Only fictional choices are stored in sessionStorage.
- The pilot form validates locally. It sends and saves nothing; an enquiry destination and operating process remain unconfigured. Public pages are marked noindex while this remains a local preview.
- The diagnostic-to-coaching handoff is manual. Longitudinal measurement is proposed, not implemented or validated.

## Brand Commitments

Keep the CommsAlign name and the two existing tools. The user requested comfortable colors and supplied a detailed marketing brief: warm off-white, navy, restrained teal and editorial serif headings. Preserve the separate sage/forest Workspace design. No competitor reference is binding.

## Evidence on Hand

Existing product content and rubric implementations in app/tool1; synthetic team survey data in data/organizational/sample_q12_results.csv; evidence limitations and sharing guidance in docs and data. There are no verified commercial claims or live usage metrics.

The imported implementation brief is retained at docs/imported-implementation-brief.md. Its older assertion that rewriting was unimplemented is superseded by the current v2 conditional revision and re-scoring source. Live model operation was not validated during the marketing work.

## Product Principles

- Make the next task clear.
- Show real app capabilities and label demonstration data.
- Keep evidence and privacy limitations understandable.
- Preserve consent and reporting behavior.
