# Run CommsAlign v2 on your computer

1. Install **Python 3.11 or newer** if it is not already installed. Python 3.13 was used to test this app. On Windows, enable **Add Python to PATH** during installation.
2. Extract the entire ZIP. Keep the files and folders together.
3. On Mac, open `start.command`. On Windows, open `start.bat`.
4. The first launch creates a local Python environment and downloads the required packages. Internet access is needed for this setup.
5. Your browser opens **http://127.0.0.1:8502/** when the website is ready. Keep the terminal window open. Press **Ctrl+C** in that window to stop it.

If your computer does not open the launcher, open a terminal in this folder and run:

```sh
python3 launch.py
```

On Windows, use `py -3 launch.py` instead. Follow any operating-system security instructions yourself; you can use the terminal command above without opening the shortcut file.

The homepage, fictional interactive example and Team Diagnostic work without API credentials. Live Message Coach reviews need your own GW Azure connection. Copy `.env.example` to `.env` and enter your own settings if you have access. This package does not include anyone's credentials.

This is a local preview. The pilot form does not send or save enquiries. Each person runs their own copy; the `127.0.0.1` address works only on the computer running the app.

If port 8502 is already in use, stop the other preview and try again. After setup, an alternative is `.venv/bin/python server.py --port 8503` on Mac/Linux or `.venv\Scripts\python.exe server.py --port 8503` on Windows, then open http://127.0.0.1:8503/.

For source details and configuration, see `README_V2.md`.
