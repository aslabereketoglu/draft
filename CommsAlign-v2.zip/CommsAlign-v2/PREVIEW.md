# CommsAlign v2

This is a separate source copy. The original application in `../urmom` is unchanged.

## Open the preview

Open http://127.0.0.1:8502 while the local server is running. This preview uses a custom HTML/CSS/JavaScript interface and a Python API. It does not run Streamlit.

- Homepage: http://127.0.0.1:8502/
- Interactive fictional example: http://127.0.0.1:8502/demo
- Working tools: http://127.0.0.1:8502/workspace

The public website also includes How it works, Solutions, Research, Pricing and Request a pilot pages. The pilot form is a local preview: entries are validated but neither sent nor saved. No public deployment has been made; pages remain marked noindex.

Restart it from a terminal:

```sh
cd "/Users/aslibereketoglu/Documents/ChatGPT/dnsc project/urmom-v2"
"../urmom/.venv/bin/python" server.py --port 8502
```

For a separate Python environment, create `.venv` and install `requirements-web.txt`, then run `.venv/bin/python server.py`.

## Edit the copy

- `server.py`: local server entry point
- `app/marketing_site.py` and `app/marketing_content.py`: public pages and reviewed copy
- `web/marketing.css` and `web/marketing.js`: public design, navigation and preview form
- `web/explorer.js`, `web/alignment-data.js`, `web/alignment-scenario.json`: fictional example
- `app/web_api.py`: API around the existing Python analysis and review engines
- `web/index.html`: app shell
- `web/app.css`: custom design system and responsive layouts
- `web/app.js`: overview, diagnostics, discussion notes, and navigation
- `web/coach.js`: message editor, evaluation, revision, and export
- `web/helpers.js`: shared browser helpers

The earlier Streamlit preview files are retained as development references and are not served by the custom website. The custom runtime dependencies are listed separately in `requirements-web.txt`.

## Behavior

Team Diagnostic uses the existing synthetic demonstration data. Reporting thresholds hide scores, rankings, prompts, and exports for suppressed teams. Previously held notes for newly suppressed teams are cleared.

Message Coach retains the explicit consent-based evaluation and rescore flow. Live evaluation requires locally configured GW Azure settings. Credentials and Git history were not copied. No model request occurs just by opening a page.

Drafts, reviews, and notes are held in the page’s memory and are lost on reload. Notes must be saved in the session before they are included in a discussion download. No server-side note storage was added.

The public Alignment Explorer is deterministic and independent of the tools. It uses authored fictional facts, makes no API/model requests, and retains only fictional choices in tab session storage. Its evaluation stage is proposed, and the handoff between the real tools remains manual.

This is a local preview, not a published service. The Pricing page invites a pilot conversation without invented prices, availability guarantees, customer claims, sign-in or fake activity.
